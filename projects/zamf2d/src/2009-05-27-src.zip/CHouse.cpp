#include "CHouse.h"
#include "CGameWindow.h"
#include "CActorFactory.h"

#include "tinyxml.h"
#include "utils.h"

#include <fstream>

using namespace ZAMF;
using namespace std;

CHouse *CHouse::mInstance = NULL;

CHouse::CHouse()
: mEnableActorDrawing(true)
{
	mInstance = this;
}

CHouse::~CHouse(void)
{
	mInstance = NULL;
}

void CHouse::Build(string house)
{
	string filename="../../resource/houseplan/" + house + ".xml";

	TiXmlDocument doc(filename.c_str());
	bool ok = doc.LoadFile();
	if (!ok) 
	{
		const char *desc = doc.ErrorDesc();
		throw(desc);
	}

	float x,y,w,h;
	TiXmlElement *el=NULL;
	TiXmlElement *root = doc.FirstChildElement("house");

	//dimensions
	el = root->FirstChildElement("dimensions");
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "x", &x ) );
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "y", &y ) );
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "w", &w ) );
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "h", &h ) );
	BuildHouseFrame(x,y,w,h);

	//structures
	el = root->FirstChildElement("structures");
	if (el != NULL)
		el = el->FirstChildElement("box");
	while (el != NULL)
	{
		ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "x", &x ) );
		ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "y", &y ) );
		ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "w", &w ) );
		ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "h", &h ) );
		
		AddStructure(x, y, w, h);
		
		el = el->NextSiblingElement("box");
	}

	//fridge
	el = root->FirstChildElement("fridge");
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "x", &x ) );
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "y", &y ) );
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "w", &w ) );
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "h", &h ) );
	CActorFactory::Get()->CreateFridge(x,y,w,h);

	//player
	el = root->FirstChildElement("player");
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "x", &x ) );
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "y", &y ) );
	CActorFactory::Get()->CreatePlayer(x, y);

	//spawners
	el = root->FirstChildElement("spawners");
	if (el != NULL)
		el = el->FirstChildElement("spawner");
	float delay;
	while (el != NULL)
	{
		ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "x", &x ) );
		ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "y", &y ) );
		ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "delay", &delay ) );
		CActorFactory::Get()->CreateSpawner(x, y, delay);
		
		el = el->NextSiblingElement("spawner");
	}

#ifdef _DEBUG
	mEnableActorDrawing = true;
#else
	mEnableDebugDrawing = false;
#endif
	return;
}

void CHouse::Wreck()
{
	std::list< CActor* >::iterator it = mActors.begin();
	while(it != mActors.end())
	{
		CActor *die = *it;
		it = mActors.erase(it);
		delete die;
	}

	delete mPhysicsWorld;
	mPhysicsWorld = NULL;
}

void CHouse::BuildHouseFrame(float x, float y, float w, float h)
{
	//set up the physics world
	//make the AABB world twice as large as the region, for safety sake
	b2AABB worldAABB;
	worldAABB.lowerBound.Set(x - w, y - 2*h);
	worldAABB.upperBound.Set(x + 2*h, y + 2*h);
	b2Vec2 gravity(0.0f, -9.8f);
	bool doSleep = true;
	mPhysicsWorld = new b2World(worldAABB, gravity, doSleep);
	mPhysicsWorld->SetContactListener(this);
	
	//set up static bodies (walls)
	b2PolygonDef horiShapeDef, vertShapeDef;
	horiShapeDef.SetAsBox(w, 0.5f);
	vertShapeDef.SetAsBox(0.5f, h);
	horiShapeDef.filter.categoryBits = CActor::ACTOR_STATIONARY;
	vertShapeDef.filter.categoryBits = CActor::ACTOR_STATIONARY;

	b2BodyDef def;
	b2Body *body;

	//floor
	def.position.Set(x + 0.5f*w, y - 0.5f);
	body = mPhysicsWorld->CreateBody(&def);
	body->CreateShape(&horiShapeDef);
	//roof
	def.position.Set(x + 0.5f*w, y + h + 0.5f);
	body = mPhysicsWorld->CreateBody(&def);
	body->CreateShape(&horiShapeDef);
	
	//left
	def.position.Set(x - 0.5f, y + 0.5f*h);
	body = mPhysicsWorld->CreateBody(&def);
	body->CreateShape(&vertShapeDef);
	//right
	def.position.Set(x + w + 0.5f, y + 0.5f*h);
	body = mPhysicsWorld->CreateBody(&def);
	body->CreateShape(&vertShapeDef);

#ifdef _DEBUG
	mPhysicsWorld->SetDebugDraw(&mDebugDraw);
#endif
	mDebugDraw.SetFlags(~0);
	
#ifdef _DEBUG
	mBox.x = x-2;
	mBox.y = y-2;
	mBox.w = w+4;
	mBox.h = h+4;
#else
	mBox.x = x;
	mBox.y = y;
	mBox.w = w;
	mBox.h = h;
#endif

	//opengl
	glClearColor(0.5f,0.5f,0.8f,0.0f);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
#ifdef _DEBUG
	glOrtho(x-2, x+w+2, y-2, y+h+2, -1, 1);
#else
	glOrtho(x, x+w, y, y+h, -1, 1);
#endif
	//reset model view matrix (just in case, should be fine anyway)
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void CHouse::AddStructure(float x, float y, float w, float h)
{
	b2PolygonDef shapeDef;
	shapeDef.SetAsBox(w, h);
	shapeDef.filter.categoryBits = CActor::ACTOR_STATIONARY;

	
	b2BodyDef def;
	def.position.Set(x,y);

	b2Body *body;
	body = mPhysicsWorld->CreateBody(&def);
	body->CreateShape(&shapeDef);
	mStaticBodies.push_back(body);

	Box b = {x,y,w,h};
	mStructures.push_back(b);

}

void CHouse::RegisterActor(CActor *actor)
{
	mActors.push_back(actor);
}

void CHouse::UnregisterActor(CActor *actor)
{
	if (mInstance == NULL) return;
	std::list<CActor *>::iterator it;
	for (it=mActors.begin(); it!=mActors.end(); it++)
	{
		if (actor == *it)
		{
			mActors.erase(it);
			break;
		}
	}
}

b2Vec2 CHouse::PixelToWorld(int x, int y)
{
	int width = CGameWindow::Get()->GetWidth();
	int height = CGameWindow::Get()->GetHeight();

	b2Vec2 pos( mBox.x + x*(mBox.w-mBox.x) / width, mBox.y + (height-y)*(mBox.h-mBox.y) / height );
	return pos;
}

void CHouse::WorldToPixel(const b2Vec2 &pos, int *x, int *y)
{
	int width = CGameWindow::Get()->GetWidth();
	int height = CGameWindow::Get()->GetHeight();

	*x = (int)(pos.x * width / mBox.w);
	*y = height - (int)(pos.y * height / mBox.h);
}

void CHouse::HandleEvents(const SDL_Event &e)
{
	//enable / disable debug drawing
	if (e.type == SDL_KEYDOWN)
	{
		switch (e.key.keysym.sym)
		{
		case SDLK_F3:
			mEnableDebugDrawing = !mEnableDebugDrawing;
			if (mEnableDebugDrawing)
				mPhysicsWorld->SetDebugDraw(&mDebugDraw);
			else
				mPhysicsWorld->SetDebugDraw(NULL);
			break;
		case SDLK_F4:
			mEnableActorDrawing = !mEnableActorDrawing;
			break;
		default:
			;
		}
	}


	//handle events on all actors
	std::list< CActor* >::iterator it;
	for(it = mActors.begin(); it != mActors.end(); ++it)
	{
		(*it)->HandleEvents(e);
	}
}

bool CHouse::Update(float dt)
{
	//update all actors
	std::list< CActor* >::iterator it;
	for(it = mActors.begin(); it != mActors.end(); ++it)
	{
		(*it)->Update(dt);
	}

	//kill any dead objects
	it = mActors.begin();
	while(it != mActors.end())
	{
		if ((*it)->GetDying())
		{
			CActor *die = *it;
			it = mActors.erase(it);
			delete die;
		}
		else
		{
			++it;
		}
	}

	mCollisions.clear();
	//if (dt > B2_FLT_EPSILON)
	mPhysicsWorld->Step(dt, 15);

	//collide the objects
	for (std::list<std::pair<CActor*,CActor*> >::iterator it=mCollisions.begin(); it != mCollisions.end(); it++)
	{
		if (it->first != NULL)
			it->first->Collide(it->second);	
		if (it->second != NULL)
			it->second->Collide(it->first);
	}

	return true;
}

void CHouse::Draw()
{
	if (!mEnableActorDrawing) return;

	//draw the structures
	glDisable(GL_TEXTURE_2D);
	glColor3f(0.8,0.8,0.8);
	glPushMatrix();
	for (std::list<Box>::iterator it=mStructures.begin(); it!=mStructures.end(); ++it)
	{
		glLoadIdentity();
		glTranslatef(it->x, it->y, 0);
		glBegin(GL_QUADS);
			glVertex3f( -it->w, -it->h, 0 );
			glVertex3f(  it->w, -it->h, 0 ); 
			glVertex3f(  it->w, it->h, 0 ); 
			glVertex3f( -it->w, it->h, 0 ); 
		glEnd();
	}
	glPopMatrix();
	glEnable(GL_TEXTURE_2D);

	//draw all actors
	std::list< CActor* >::iterator it;
	for(it = mActors.begin(); it != mActors.end(); ++it)
	{
		(*it)->Draw();
	}

	return;
}

void CHouse::Add(const b2ContactPoint *point)
{
	b2Shape *shape1 = point->shape1;
	b2Shape *shape2 = point->shape2;

	CActor *actor1 = static_cast<CActor*>(shape1->GetUserData());
	CActor *actor2 = static_cast<CActor*>(shape2->GetUserData());
	
	mCollisions.push_back(make_pair(actor1, actor2));
}