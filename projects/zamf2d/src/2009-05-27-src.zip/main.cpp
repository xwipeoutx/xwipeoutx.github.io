#include "SDL.h" 

//standard example
//#define RUN_EXAMPLE mStartSDLExample
//zamf 2d
#define RUN_EXAMPLE StartZAMF2D

int RUN_EXAMPLE( int argc, char* args[] );

int main( int argc, char* args[] ) 
{ 
	return RUN_EXAMPLE( argc, args );
} 