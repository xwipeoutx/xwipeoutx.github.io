#include "CPhysicsDebugDraw.h"
#include "sdlinc.h"
CPhysicsDebugDraw::CPhysicsDebugDraw(void)
{
}

CPhysicsDebugDraw::~CPhysicsDebugDraw(void)
{
}

/// Draw a closed polygon provided in CCW order.
void CPhysicsDebugDraw::DrawPolygon(const b2Vec2* vertices, int32 vertexCount, const b2Color& color)
{
	glDisable(GL_TEXTURE_2D);
	glColor3f(color.r, color.g, color.b);
	glPushMatrix();
	glLoadIdentity();
	glBegin(GL_LINE_LOOP);
	for (int i=0; i< vertexCount; i++)
	{
		glVertex3f(vertices[i].x, vertices[i].y, 0);
	}
	glEnd();
	glPopMatrix();
	glEnable(GL_TEXTURE_2D);
}

/// Draw a solid closed polygon provided in CCW order.
void CPhysicsDebugDraw::DrawSolidPolygon(const b2Vec2* vertices, int32 vertexCount, const b2Color& color)
{
	glDisable(GL_TEXTURE_2D);
	glColor3f(color.r, color.g, color.b);
	glPushMatrix();
	glLoadIdentity();
	glBegin(GL_TRIANGLE_FAN);
	for (int i=0; i< vertexCount; i++)
	{
		glVertex3f(vertices[i].x, vertices[i].y, 0);
	}
	glEnd();
	glPopMatrix();
	glEnable(GL_TEXTURE_2D);
}

/// Draw a circle.
void CPhysicsDebugDraw::DrawCircle(const b2Vec2& center, float32 radius, const b2Color& color)
{
	glDisable(GL_TEXTURE_2D);
	glPushMatrix();
	glLoadIdentity();
	const float32 k_segments = 16.0f;
	const float32 k_increment = 2.0f * b2_pi / k_segments;
	float32 theta = 0.0f;
	glColor3f(color.r, color.g, color.b);
	glBegin(GL_LINE_LOOP);
	for (int32 i = 0; i < k_segments; ++i)
	{
		b2Vec2 v = center + radius * b2Vec2(cosf(theta), sinf(theta));
		glVertex2f(v.x, v.y);
		theta += k_increment;
	}
	glEnd();
	glPopMatrix();
	glEnable(GL_TEXTURE_2D);
}

/// Draw a solid circle.
void CPhysicsDebugDraw::DrawSolidCircle(const b2Vec2& center, float32 radius, const b2Vec2& axis, const b2Color& color)
{
	glDisable(GL_TEXTURE_2D);
	glPushMatrix();
	glLoadIdentity();
	const float32 k_segments = 16.0f;
	const float32 k_increment = 2.0f * b2_pi / k_segments;
	float32 theta = 0.0f;
	glColor3f(color.r, color.g, color.b);
	glBegin(GL_TRIANGLE_FAN);
	for (int32 i = 0; i < k_segments; ++i)
	{
		b2Vec2 v = center + radius * b2Vec2(cosf(theta), sinf(theta));
		glVertex2f(v.x, v.y);
		theta += k_increment;
	}
	glEnd();
	glPopMatrix();
	glEnable(GL_TEXTURE_2D);
}

/// Draw a line segment.
void CPhysicsDebugDraw::DrawSegment(const b2Vec2& p1, const b2Vec2& p2, const b2Color& color)
{
	glDisable(GL_TEXTURE_2D);
	glColor3f(color.r, color.g, color.b);
	glPushMatrix();
	glLoadIdentity();
	glBegin(GL_LINE_STRIP);
		glVertex3f(p1.x, p1.y, 0);
		glVertex3f(p2.x, p2.y, 0);
	glEnd();
	glPopMatrix();
	glEnable(GL_TEXTURE_2D);
}

/// Draw a transform. Choose your own length scale.
/// @param xf a transform.
void CPhysicsDebugDraw::DrawXForm(const b2XForm& xf)
{
	glDisable(GL_TEXTURE_2D);
	glPushMatrix();
	glLoadIdentity();
	b2Vec2 p1 = xf.position, p2;
	const float32 k_axisScale = 0.4f;
	glBegin(GL_LINES);
	
	glColor3f(1.0f, 0.0f, 0.0f);
	glVertex2f(p1.x, p1.y);
	p2 = p1 + k_axisScale * xf.R.col1;
	glVertex2f(p2.x, p2.y);

	glColor3f(0.0f, 1.0f, 0.0f);
	glVertex2f(p1.x, p1.y);
	p2 = p1 + k_axisScale * xf.R.col2;
	glVertex2f(p2.x, p2.y);

	glEnd();
	
	glPopMatrix();
	glEnable(GL_TEXTURE_2D);
}
