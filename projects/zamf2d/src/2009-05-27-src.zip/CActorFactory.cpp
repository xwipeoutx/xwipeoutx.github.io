#include "CActorFactory.h"

#include "CFridge.h"
#include "CZombie.h"
#include "CPlayer.h"
#include "CNail.h"
#include "CZombieSpawner.h"

using namespace ZAMF;

ZAMF::CActorFactory *ZAMF::CActorFactory::mInstance=NULL;

CActorFactory::CActorFactory(void)
{

	mInstance = this;
}

CActorFactory::~CActorFactory(void)
{

	mInstance = NULL;
}

bool CActorFactory::Load(const std::string type)
{
	CActorDef *def=NULL;
	TiXmlDocument *doc = NULL;
	if (type == "zombie")
	{
		def = new CZombieDef();
		doc = new TiXmlDocument("../../resource/defs/zombie.xml");
	}
	else if (type == "player")
	{
		def = new CPlayerDef();
		doc = new TiXmlDocument("../../resource/defs/player.xml");
	}
	else if (type == "fridge")
	{
		def = new CFridgeDef();
		doc = new TiXmlDocument("../../resource/defs/fridge.xml");
	}
	else if (type == "nail")
	{
		def = new CNailDef();
		doc = new TiXmlDocument("../../resource/defs/nail.xml");
	}
	else if (type == "spawner")
	{
		def = new CZombieSpawnerDef();
		doc = new TiXmlDocument("../../resource/defs/spawner.xml");
	}

	if (doc != NULL)
	{
		bool ok = doc->LoadFile();
		if (!ok) 
		{
			const char *desc = doc->ErrorDesc();
			throw(desc);
		}
		TiXmlElement *el = doc->FirstChildElement("actor");
		def->Load(el);

		delete doc;
		doc = NULL;
	}

	if (def != NULL)
	{
		mActorDefs[type] = def;
	}
	return def != NULL;
}

CActor *CActorFactory::CreateZombie(float x, float y)
{
	CZombieDef *def=NULL;
	std::map<const std::string, CActorDef*>::iterator it = mActorDefs.find("zombie");
	if (it == mActorDefs.end())
	{
		if (Load("zombie"))
			def = dynamic_cast<CZombieDef*>(mActorDefs.find("zombie")->second);
		else
			throw("Failed loading zombie");
	}
	else
	{
		def = dynamic_cast<CZombieDef*>(it->second);
	}

	CActor *zombie = new CZombie(def, x, y);
	return zombie;
}

CActor *CActorFactory::CreatePlayer(float x, float y)
{
	CPlayerDef *def=NULL;
	std::map<const std::string, CActorDef*>::iterator it = mActorDefs.find("player");
	if (it == mActorDefs.end())
	{
		if (Load("player"))
			def = dynamic_cast<CPlayerDef*>(mActorDefs.find("player")->second);
		else
			throw("Failed loading player");
	}
	else
	{
		def = dynamic_cast<CPlayerDef*>(it->second);
	}

	CActor *player = new CPlayer(def, x, y);
	return player;
}

CActor *CActorFactory::CreateNail(b2Vec2 playerPos, b2Vec2 dir)
{
	CNailDef *def=NULL;
	std::map<const std::string, CActorDef*>::iterator it = mActorDefs.find("nail");
	if (it == mActorDefs.end())
	{
		if (Load("nail"))
			def = dynamic_cast<CNailDef*>(mActorDefs.find("nail")->second);
		else
			throw("Failed loading nail");
	}
	else
	{
		def = dynamic_cast<CNailDef*>(it->second);
	}

	CNail *nail = new CNail(def, playerPos, dir);
	return nail;
}


CActor *CActorFactory::CreateFridge(float x, float y, float w, float h)
{
	CFridgeDef *def=NULL;
	std::map<const std::string, CActorDef*>::iterator it = mActorDefs.find("fridge");
	if (it == mActorDefs.end())
	{
		if (Load("fridge"))
			def = dynamic_cast<CFridgeDef*>(mActorDefs.find("fridge")->second);
		else
			throw("Failed loading fridge");
	}
	else
	{
		def = dynamic_cast<CFridgeDef*>(it->second);
	}

	CFridge *fridge = new CFridge(def, x, y, w, h);
	return fridge;

}

CActor *CActorFactory::CreateSpawner(float x, float y, float delay)
{
	CZombieSpawnerDef *def=NULL;
	std::map<const std::string, CActorDef*>::iterator it = mActorDefs.find("spawner");
	if (it == mActorDefs.end())
	{
		if (Load("spawner"))
			def = dynamic_cast<CZombieSpawnerDef*>(mActorDefs.find("spawner")->second);
		else
			throw("Failed loading spawner");
	}
	else
	{
		def = dynamic_cast<CZombieSpawnerDef*>(it->second);
	}

	CZombieSpawner *spawner = new CZombieSpawner(def, x, y, delay);
	return spawner;

}