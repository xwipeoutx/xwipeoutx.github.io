#include "CZombieSpawner.h"

#include "CActorFactory.h"

using namespace ZAMF;

CZombieSpawnerDef::CZombieSpawnerDef()
{
}

bool CZombieSpawnerDef::Load(TiXmlElement *root)
{
	TiXmlElement *el=NULL;
	el = root->FirstChildElement("name");
	mName = std::string(el->GetText());

	mLoaded = true;
	return true;
}

CZombieSpawner::CZombieSpawner(CZombieSpawnerDef *def, float x, float y, float delay)
: CActor(def), mX(x), mY(y)
{
	mElapsed = (float)(rand())/RAND_MAX;
	mDelay = delay;

	mFlags = ACTOR_FRIDGE;
	mSprite = NULL;
}

CZombieSpawner::~CZombieSpawner(void)
{

}

bool CZombieSpawner::Update(float dt)
{
	mElapsed += dt;
	if (mElapsed > 1)
	{
		mElapsed = 0;

		CActorFactory::Get()->CreateZombie(mX, mY);
	}

	return true;
}