#pragma once

#include "CActor.h"

namespace ZAMF
{
	#define PLAYER_JUMP_VEL 7.0f

	#define PLAYER_FACING_LEFT 0
	#define PLAYER_FACING_RIGHT 1

	class CPlayerDef : public CActorDef
	{
	public: 
		bool Load(TiXmlElement *root);

		float maxVel, accelForce, jumpForce;
		int initialDir;
		float density, friction, restitution;
	};

	class CPlayer :	public CActor
	{
	public:
		CPlayer(CPlayerDef *def, float x, float y);
		~CPlayer(void);

		virtual void HandleEvents(const SDL_Event &e);
		bool Update(float dt);
		void Draw();

	private:
		CPlayerDef mDef;

		float mVel;

		void FireNail();
	};
};