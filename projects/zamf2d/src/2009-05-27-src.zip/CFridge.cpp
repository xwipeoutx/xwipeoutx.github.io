#include "CFridge.h"
#include "CSpriteFactory.h"
#include "CHouse.h"
using namespace ZAMF;


CFridgeDef::CFridgeDef()
{

}

bool CFridgeDef::Load(TiXmlElement *root)
{
	TiXmlElement *el=NULL;
	el = root->FirstChildElement("name");
	mName = std::string(el->GetText());

	el = root->FirstChildElement("sprite");
	el = el->FirstChildElement("image");
	mSpriteFilename =  std::string(el->Attribute("filename"));

	mLoaded = true;
	return true;
}

CFridge::CFridge(CFridgeDef *def, float x, float y, float w, float h)
: CActor(def)
{
	mFlags = ACTOR_FRIDGE;

	mSprite = CSpriteFactory::Get()->Load(def->mName, def->mSpriteFilename, w, h);

	//fridge is a static body, yay
	b2BodyDef bodyDef;
	bodyDef.position.Set(x, y);
	mBody = CHouse::Get()->GetPhysicsWorld()->CreateBody(&bodyDef);

	b2PolygonDef shapeDef;
	shapeDef.SetAsBox(0.5f*mSprite->GetWidth(), 0.5f*mSprite->GetHeight());
	shapeDef.filter.categoryBits = ACTOR_FRIDGE;
	shapeDef.userData = this;
	mBody->CreateShape(&shapeDef);
}

CFridge::~CFridge(void)
{

}

void CFridge::Draw()
{
	b2Vec2 pos = mBody->GetPosition();

	glColor3f(1,1,1);
	glPushMatrix();
	glTranslatef(pos.x, pos.y, 0);
	mSprite->Draw();

	glPopMatrix();
}