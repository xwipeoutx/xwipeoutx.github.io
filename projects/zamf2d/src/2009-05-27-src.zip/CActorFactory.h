#pragma once

#include "CActor.h"
#include "tinyxml.h"
#include <string>
#include <map>

namespace ZAMF
{

	class CActorFactory
	{
	public:
		CActorFactory(void);
		~CActorFactory(void);

		bool Load(const std::string type);
		CActor *CreateZombie(float x, float y);
		CActor *CreatePlayer(float x, float y);
		CActor *CreateNail(b2Vec2 playerPos, b2Vec2 dir);
		CActor *CreateFridge(float x, float y, float w, float h);
		CActor *CreateSpawner(float x, float y, float delay);

		//singletonish stuff
		static CActorFactory *Get()
		{
			return mInstance;
		}
	private:
		std::map<const std::string, CActorDef*> mActorDefs;

		static CActorFactory *mInstance;
	};
};