#pragma once

#include "CActor.h"

namespace ZAMF
{
	class CZombieSpawnerDef : public CActorDef
	{
	public:
		CZombieSpawnerDef();
		bool Load(TiXmlElement *root);
	};

	class CZombieSpawner : public CActor
	{
	public:
		CZombieSpawner(CZombieSpawnerDef *def, float x, float y, float delay);
		~CZombieSpawner(void);

		bool Update(float dt);

	private:
		float mX, mY, mDelay;

		float mElapsed;
	};
};