#include "CPlayer.h"
#include "CHouse.h"
#include "CNail.h"
#include "CActorFactory.h"

#include <string>
#include <fstream>

#include "utils.h"
using namespace ZAMF;
using namespace std;

bool CPlayerDef::Load(TiXmlElement *root)
{
	CActorDef::Load(root);

	TiXmlElement *el=NULL;

	// block: behaviour
	TiXmlElement *behaviourRootNode = root->FirstChildElement("behaviour");
	
	//movement
	el = behaviourRootNode->FirstChildElement("movement");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("maxvel", &maxVel) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("accelforce", &accelForce) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("jumpforce", &jumpForce) );

	//physics
	el = behaviourRootNode->FirstChildElement("physics");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("density", &density) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("friction", &friction) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("restitution", &restitution) );

	return true;
}

CPlayer::CPlayer(CPlayerDef *def, float x, float y)
: CActor(def)
{
	mFlags = ACTOR_PLAYER;

	CPlayerDef def2 = *def;
	mDef = def2;

	//add to physics world
	b2BodyDef bodyDef;
	bodyDef.position.Set(x, y);
	bodyDef.fixedRotation = true;
	bodyDef.linearDamping = 0.0f;
	bodyDef.angularDamping = 0.0f;
	bodyDef.allowSleep = false;
	mBody = CHouse::Get()->GetPhysicsWorld()->CreateBody(&bodyDef);

	b2PolygonDef shapeDef;
	shapeDef.SetAsBox(0.5f*mSprite->GetWidth(), 0.5f*mSprite->GetHeight());
	shapeDef.density = mDef.density;
	shapeDef.friction = mDef.friction;
	shapeDef.restitution = mDef.restitution;
	shapeDef.filter.categoryBits = ACTOR_PLAYER;
	shapeDef.filter.maskBits = ACTOR_ENEMY | ACTOR_STATIONARY;
	shapeDef.userData = this;
	mBody->CreateShape(&shapeDef);
	mBody->SetMassFromShapes();
}

CPlayer::~CPlayer(void)
{
}

void CPlayer::HandleEvents(const SDL_Event &e)
{
	if (e.type == SDL_KEYDOWN)
	{
		switch (e.key.keysym.sym)
		{
		case SDLK_UP: 
		case SDLK_w:
		case SDLK_SPACE:
			mBody->ApplyImpulse(b2Vec2(0,mDef.jumpForce), b2Vec2_zero);
			break;
		case SDLK_e:
			FireNail();
			break;
		default:
			break;
		}
	}
	else if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == 1)
	{
		FireNail();
	}
}

bool CPlayer::Update(float dt)
{
	uint8 *keyState = SDL_GetKeyState(NULL);

	mVel = 0;
	if (keyState[SDLK_RIGHT] || keyState[SDLK_d])
	{
		mVel = mDef.maxVel;
	}
	if (keyState[SDLK_LEFT] || keyState[SDLK_a])
	{
		mVel = -mDef.maxVel;
	}

	b2Vec2 linVel = mBody->GetLinearVelocity();
	linVel.x = mVel;
	mBody->SetLinearVelocity(linVel);

	mSprite->AdvanceFrame(abs(linVel.x) / mDef.maxVel * dt);

	if (linVel.x > 0) mSprite->SetState(PLAYER_FACING_RIGHT);
	else if (linVel.x < 0) mSprite->SetState(PLAYER_FACING_LEFT);
	if (linVel.x < 0.0001 && linVel.x > -0.0001) mSprite->ResetFrame();

	return true;
}

void CPlayer::Draw()
{
	glPushMatrix();
	b2Vec2 pos = mBody->GetPosition();
	float angle = mBody->GetAngle();

	glTranslatef(pos.x, pos.y, 0);
	glRotatef(angle*180/3.14159f, 0,0,1);
	mSprite->Draw();
	glPopMatrix();
}

void CPlayer::FireNail()
{
	int x, y;
	SDL_GetMouseState(&x, &y);
	b2Vec2 playerPos = mBody->GetPosition();
	b2Vec2 dir = CHouse::Get()->PixelToWorld(x, y) - playerPos;
	CActorFactory::Get()->CreateNail(playerPos, dir);
	//new CNail(playerPos, dir);
}