#pragma once

#include "common.h"
#include "CSingleton.h"

namespace ZAMF
{
	class CSprite;

	class CHud : public CSingleton<CHud>
	{
	public:
		CHud(void);
		~CHud(void);

		void UpdateScore();
		void UpdateInventory();
		void UpdateHP(float hp, float maxHP);
		void DrawBgSprite(CSprite *sprite);
		void SetProjToGUI();

	private:
		GLuint mEmptyBagDisplayList;
		GLuint mFullBagDisplayList;
	};
}
