#include "CSpriteFactory.h"

#include "utils.h"
#include "tinyxml.h"
#include "CConfig.h"

using namespace ZAMF;

CSpriteFactory::CSpriteFactory(void)
{
}

CSpriteFactory::~CSpriteFactory(void)
{
}


CSprite *CSpriteFactory::Load(std::string type, std::string name, std::string filename,
					   float width, float height, int columns, int rows,
//					   int numStates, int framesPerState, float fps, int initialState)
						int numStates, int initialState, CSprite::SpriteFrameInfo *states)
{
	//check it doesn't already exist
	//std::map<std::string, CSprite* >::iterator it;
	SpritesMapCfg::iterator it;
	std::string key = type + "," + name;
	it = mSprites.find(key);
	if (it != mSprites.end())
		return it->second;

	std::string realFilename = ZAMF_CFG_GET_PATH("sprite") + type + "/" + filename;
	//CSprite *sprite = new CSprite(filename, width, height, numStates, framesPerState, fps, initialState);
	CSprite *sprite = new CSprite(realFilename, width, height, columns, rows, numStates, initialState, states);
	mSprites[key] = sprite;
	return sprite;
}

CSprite *CSpriteFactory::Load(std::string type, std::string name, TiXmlElement *spriteNode)
{
	//check it doesn't already exist
	SpritesMapCfg::iterator it;
	std::string key = type + "," + name;
	it = mSprites.find(key);
	if (it != mSprites.end())
		return it->second;

	//load it
	float w=0, h=0;
	int columns, rows, initialState;
	float fps=0;
	TiXmlElement *el;

	//dimensions (in all sprites)
	CheckXMLSuccessAttribute( spriteNode->QueryFloatAttribute("width", &w) );
	CheckXMLSuccessAttribute( spriteNode->QueryFloatAttribute("height", &h) );
	el = spriteNode->FirstChildElement("image");
	std::string filename(el->Attribute("filename"));

	//animation (not in all sprites)

	el = spriteNode->FirstChildElement("animation");
	if (el)
	{
		CheckXMLSuccessAttribute( el->QueryIntAttribute("columns", &columns) );
		CheckXMLSuccessAttribute( el->QueryIntAttribute("rows", &rows) );
		CheckXMLSuccessAttribute( el->QueryIntAttribute("initialstate", &initialState) );

		//count number of states
		int numStates = 0;
		TiXmlElement *child = el->FirstChildElement("state");
		while (child != NULL)
		{
			numStates++;
			child = child->NextSiblingElement("state");
		}

		CSprite::SpriteFrameInfo *states = new CSprite::SpriteFrameInfo[numStates];
		int index;
		child = el->FirstChildElement("state");
		while (child != NULL)
		{
			CheckXMLSuccessAttribute( child->QueryIntAttribute("index", &index) );
			if (index >= numStates)
			{
				throw("Index must be less than the number of states");
			}

			//states[index].index = index;
			CheckXMLSuccessAttribute( child->QueryFloatAttribute("x", &states[index].x) );
			CheckXMLSuccessAttribute( child->QueryFloatAttribute("y", &states[index].y) );
			CheckXMLSuccessAttribute( child->QueryFloatAttribute("w", &states[index].w) );
			CheckXMLSuccessAttribute( child->QueryFloatAttribute("h", &states[index].h) );
			CheckXMLSuccessAttribute( child->QueryFloatAttribute("srcw", &states[index].srcw) );
			CheckXMLSuccessAttribute( child->QueryFloatAttribute("srch", &states[index].srch) );
			CheckXMLSuccessAttribute( child->QueryIntAttribute("frames", &states[index].frames) );
			CheckXMLSuccessAttribute( child->QueryFloatAttribute("fps", &states[index].fps) );
			//CheckXMLSuccessAttribute( child->QueryIntAttribute("startframe", &states[index].startFrame) );

			states[index].name = std::string(child->GetText());

			child = child->NextSiblingElement("state");
		}

		return Load(type, name, filename, w, h, columns, rows, numStates, initialState, states);
		//return Load(name, filename, w, h, rows, columns, fps, initialState);
	}
	else
	{
		//load without animation
		return Load(type, name, filename, w, h);
	}
}

CSprite *CSpriteFactory::Get(std::string type, std::string name)
{
	//check it doesn't already exist
	SpritesMapCfg::iterator it;
	std::string key = type + "," + name;
	it = mSprites.find(key);
	if (it == mSprites.end())
		return NULL;

	//make a copy
	return new CSprite(it->second);
}
