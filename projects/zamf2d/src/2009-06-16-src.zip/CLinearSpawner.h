#pragma once

#include "CActor.h"
#include <string>

namespace ZAMF
{
	class CLinearSpawnerCfg : public CActorCfg
	{
	public:
		CLinearSpawnerCfg();
		bool Load(TiXmlElement *root);
	};

	class CPositionNameTypeDelayDef;

	class CLinearSpawner : public CActor
	{
	public:
		CLinearSpawner(const CLinearSpawnerCfg *cfg, const CPositionNameTypeDelayDef *def);
		~CLinearSpawner(void);

		bool Update(float dt);

	private:
		float mX, mY, mDelay;
		std::string mActorType;
		std::string mActorName;

		float mElapsed;
	};
};