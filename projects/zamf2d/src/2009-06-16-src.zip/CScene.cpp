#include "CScene.h"
#include "CHud.h"
#include "CGameWindow.h"
#include "CActorFactory.h"
#include "CSpriteFactory.h"
#include "CPhysicsManager.h"
#include "CConfig.h"

#include "tinyxml.h"
#include "utils.h"

#include <fstream>

using namespace ZAMF;
using namespace std;
CScene::CScene(void)
{
	new CPhysicsManager();
}

CScene::~CScene(void)
{
	delete CPhysicsManager::GetSingletonPtr();
}


void CScene::Create(string scene)
{
	mScore = 0;
	string filename = ZAMF_CFG_GET_PATH("def") + "scene/" + scene + ".xml";

	TiXmlDocument doc(filename.c_str());
	bool ok = doc.LoadFile();
	if (!ok)
	{
		const char *desc = doc.ErrorDesc();
		throw(desc);
	}

	float x=0,y=0,w=0,h=0;
	TiXmlElement *el=NULL;
	TiXmlElement *root = doc.FirstChildElement("scene");

	//bounds
	el = root->FirstChildElement("bounds");
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "x", &mBox.x ) );
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "y", &mBox.y ) );
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "w", &mBox.w ) );
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "h", &mBox.h ) );
	CPhysicsManager::GetSingleton().SetupWorld(mBox);

	//camera
	el = root->FirstChildElement("camera");
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "w", &mCamera.w ) );
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "h", &mCamera.h ) );
	
	//fridge
	el = root->FirstChildElement("fridge");
	CPositionSizeDef fridgeDef;
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "x", &fridgeDef.x ) );
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "y", &fridgeDef.y ) );
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "w", &fridgeDef.w ) );
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "h", &fridgeDef.h ) );
	CActorFactory::GetSingleton().Create("base", "fridge",&fridgeDef);

	//player
	el = root->FirstChildElement("player");
	CPositionDef playerDef;
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "x", &playerDef.x ) );
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "y", &playerDef.y ) );
	mPlayer = static_cast<CPlayer*>(CActorFactory::GetSingleton().Create("base", "player", &playerDef));

	//Background
	el = root->FirstChildElement("background");
	std::string bgFilename(el->Attribute("image"));
	mBackground = CSpriteFactory::GetSingleton().Load("background", "scenebg", 
		bgFilename, 1, 1);

	//structures
	el = root->FirstChildElement("geometry");
	if (el != NULL)
		el = el->FirstChildElement("box");
	while (el != NULL)
	{
		ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "x", &x ) );
		ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "y", &y ) );
		ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "w", &w ) );
		ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "h", &h ) );

		AddStructure(x, y, w, h);

		el = el->NextSiblingElement("box");
	}

	//spawners
	CPositionNameTypeDelayDef spawnerDef;
	el = root->FirstChildElement("spawners");
	if (el != NULL)
		el = el->FirstChildElement("spawner");
	float delay=0;
	while (el != NULL)
	{
		ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "x", &spawnerDef.x ) );
		ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "y", &spawnerDef.y ) );
		ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "delay", &spawnerDef.delay ) );
		std::string type = el->Attribute("type");
		spawnerDef.type = el->Attribute("actortype");
		spawnerDef.name = el->Attribute("actorname");

		CActorFactory::GetSingleton().Create("spawner", type, &spawnerDef);

		el = el->NextSiblingElement("spawner");
	}

	//items
	CPositionDef itemDef;
	el = root->FirstChildElement("items");
	if (el != NULL)
		el = el->FirstChildElement("item");
	while (el != NULL)
	{
		ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "x", &itemDef.x ) );
		ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "y", &itemDef.y ) );
		std::string name = el->Attribute("name");
		CActorFactory::GetSingleton().Create("item", name, &itemDef);

		el = el->NextSiblingElement("item");
	}

	mEnableActorDrawing = true;
	return;
}

void CScene::Rapture()
{
	std::list< CActor* >::iterator it = mActors.begin();
	while(it != mActors.end())
	{
		CActor *die = *it;
		it = mActors.erase(it);
		delete die;
	}

	CPhysicsManager::GetSingleton().DestroyWorld();
}

void CScene::SetupCamera()
{
	//opengl
//	glClearColor(0.5f,0.5f,0.8f,0.0f);

//	SetProjToCamera();
}

void CScene::AddStructure(float x, float y, float w, float h)
{
	b2PolygonDef shapeDef;
	shapeDef.SetAsBox(w, h);
	shapeDef.filter.categoryBits = CActor::ACTOR_STATIONARY;

	b2BodyDef def;
	def.position.Set(x,y);

	b2Body *body;
	body = CPhysicsManager::GetSingleton().GetPhysicsWorld()->CreateBody(&def);
	body->CreateShape(&shapeDef);
	mStaticBodies.push_back(body);

	Box b = {x,y,w,h};
	mStructures.push_back(b);

}

void CScene::RegisterActor(CActor *actor)
{
	mActors.push_back(actor);
}

void CScene::UnregisterActor(CActor *actor)
{
	std::list<CActor *>::iterator it;
	for (it=mActors.begin(); it!=mActors.end(); it++)
	{
		if (actor == *it)
		{
			mActors.erase(it);
			break;
		}
	}
}

b2Vec2 CScene::PixelToWorld(int x, int y)
{
	int width = CGameWindow::GetSingleton().GetWidth();
	int height = CGameWindow::GetSingleton().GetHeight();

	b2Vec2 pos( 
		mCamera.x + x*(mCamera.w) / width, 
		mCamera.y + (height-y)*(mCamera.h) / height 
	);
	return pos;
}

void CScene::WorldToPixel(const b2Vec2 &pos, int *x, int *y)
{
	int width = CGameWindow::GetSingleton().GetWidth();
	int height = CGameWindow::GetSingleton().GetHeight();

	*x = (int)(pos.x * width / mBox.w);
	*y = height - (int)(pos.y * height / mBox.h);
}


void CScene::HandleEvent(const SDL_Event &e)
{
	//enable / disable debug drawign
	if (e.type == SDL_KEYDOWN)
	{
		switch (e.key.keysym.sym)
		{
		case SDLK_F3:
			CPhysicsManager::GetSingleton().ToggleDebug();
			break;
		case SDLK_F4:
			mEnableActorDrawing = !mEnableActorDrawing;
			break;
		case SDLK_MINUS:
			mCamera.w *= 2;
			mCamera.h *= 2;
			SetupCamera();
			break;
		case SDLK_EQUALS:
			mCamera.w /= 2;
			mCamera.h /= 2;
			SetupCamera();
			break;
		default:
			;
		}
	}


	//handle events on all actors
	std::list< CActor* >::iterator it;
	for(it = mActors.begin(); it != mActors.end(); ++it)
	{
		(*it)->HandleEvent(e);
	}
}

bool CScene::Update(float dt)
{
	//update all actors
	std::list< CActor* >::iterator it;
	for(it = mActors.begin(); it != mActors.end(); ++it)
	{
		(*it)->Update(dt);
	}

	//kill any dead objects
	it = mActors.begin();
	while(it != mActors.end())
	{
		if ((*it)->GetDying())
		{
			CActor *die = *it;
			it = mActors.erase(it);
			delete die;
		}
		else
		{
			++it;
		}
	}
	
	CPhysicsManager::GetSingleton().Update(dt);

	return true;
}

void CScene::Draw()
{

	CHud::GetSingleton().DrawBgSprite(mBackground);

	SnapCameraToPlayer();
	SetProjToCamera();

	//draw physics
	CPhysicsManager::GetSingleton().RenderDebug();

	//draw the structures stuff
	glDisable(GL_TEXTURE_2D);
	glColor3f(0.9f,0.8f,0.8f);
	glPushMatrix();
	for (std::list<Box>::iterator it=mStructures.begin(); it!=mStructures.end(); ++it)
	{
		glTranslatef(it->x, it->y, 0);
		glBegin(GL_QUADS);
			glVertex3f( -it->w, -it->h, 0 );
			glVertex3f(  it->w, -it->h, 0 );
			glVertex3f(  it->w, it->h, 0 );
			glVertex3f( -it->w, it->h, 0 );
		glEnd();
		glTranslatef(-it->x, -it->y, 0);
	}
	glPopMatrix();
	glEnable(GL_TEXTURE_2D);

	//draw the actors
	if (mEnableActorDrawing)
	{
		std::list< CActor* >::iterator it;
		for(it = mActors.begin(); it != mActors.end(); ++it)
		{
			(*it)->Draw();
		}
	}

}

void CScene::SnapCameraToPlayer()
{
	b2Vec2 pos = mPlayer->GetPosition();

	//x bounds
	if (mCamera.w <= mBox.w)
	{
		mCamera.x = pos.x - mCamera.w/2;
		if (mCamera.x < 0) mCamera.x = 0;
		if (mCamera.x + mCamera.w > mBox.x+mBox.w) mCamera.x = mBox.x+mBox.w - mCamera.w;
	}
	else
	{
		mCamera.x = mBox.w/2 - mCamera.w/2;
	}

	//y bounds
	if (mCamera.h <= mBox.h)
	{
		mCamera.y = pos.y - mCamera.h/2;
		if (mCamera.y < 0) mCamera.y = 0;
		if (mCamera.y + mCamera.h > mBox.y+mBox.h) mCamera.y = mBox.y+mBox.h - mCamera.h;
	}
	else
	{
		mCamera.y = mBox.h/2 - mCamera.h/2;
	}


}

void CScene::SetProjToCamera() 
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	glOrtho(mCamera.x, mCamera.x+mCamera.w, mCamera.y, mCamera.y+mCamera.h, -1, 1);

	//reset model view matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
}
