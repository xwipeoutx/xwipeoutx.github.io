#pragma once
#include "CActor.h"

namespace ZAMF
{
	class CFridgeCfg : public CActorCfg
	{
	public:
		CFridgeCfg();
		bool Load(TiXmlElement *root);

		std::string mSpriteFilename;
	};

	class CPositionSizeDef;

	class CFridge :	public CActor
	{
	public:

		CFridge(const CFridgeCfg *cfg, const CPositionSizeDef *def);
		~CFridge(void);

		void Hit();

		void Draw();
	};
};