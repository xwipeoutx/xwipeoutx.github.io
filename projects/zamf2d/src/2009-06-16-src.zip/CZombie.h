#pragma once

#include "CActor.h"

namespace ZAMF
{
	enum ZOMBIE_STATE
	{
		ZOMBIE_WALKING = 0,
		ZOMBIE_ATTACKING = 1
	};
	class CZombieCfg : public CActorCfg
	{
	public:
		bool Load(TiXmlElement *root);

		float mMaxHP;
		float xVel, seekPlayerDistance, accelForce;
		int initialDir;
		float density, friction, restitution;

		float meleeDamage, meleeRange, meleeAnimationTime, meleeHitTime;
	};
	class CPositionDef;

	class CZombie :	public CActor
	{
	public:
		CZombie(const CZombieCfg *cfg, const CPositionDef *def);
		~CZombie(void);

		bool Update(float dt);
		void Draw();
		void Collide(CActor *other, const CPhysicsManager::ContactPoint &cp, int pos);

		void Hit(float dmg);

	private:
		CZombieCfg mCfg;
		float mDirection;

		ZOMBIE_STATE mState;

		float mAnimationCountdown;
		float mHitCountdown;
		float mHP;
	};
};
