#include "CNail.h"
#include "CPhysicsManager.h"

#include "CZombie.h"
#include "CScene.h"

#include "ActorDefs.h"

#include <fstream>

#include "tinyxml.h"
#include "utils.h"

using namespace ZAMF;
using namespace std;


bool CNailCfg::Load(TiXmlElement *root)
{
	CActorCfg::Load(root);

	TiXmlElement *el=NULL;

	// block: sprite
	TiXmlElement *spriteRootNode = root->FirstChildElement("sprite");
	CheckXMLSuccessAttribute( spriteRootNode->QueryFloatAttribute("width", &w) );
	CheckXMLSuccessAttribute( spriteRootNode->QueryFloatAttribute("height", &h) );

	// block: behaviour
	TiXmlElement *behaviourRootNode = root->FirstChildElement("behaviour");

	//stats
	el = behaviourRootNode->FirstChildElement("stats");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("damage", &damage) );
	
	//movement
	el = behaviourRootNode->FirstChildElement("movement");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("initialvel", &initialVel) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("initialdisplacement", &initialDisplacement) );

	//physics
	el = behaviourRootNode->FirstChildElement("physics");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("density", &density) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("friction", &friction) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("restitution", &restitution) );
	return true;
}

//CNail::CNail(CNailCfg *def, b2Vec2 pos, b2Vec2 initialDir)
CNail::CNail(const CNailCfg *cfg, const CPositionDirectionDef *def)
: CActor(cfg, def), mDestroyed(false)
{
	mFlags = ACTOR_PROJECTILE;

	mCfg = *cfg;

	b2Vec2 pos(def->x, def->y);
	b2Vec2 initialDir(def->xdir, def->ydir);

	initialDir.Normalize();

	//add to physics world
	b2BodyDef bodyDef;
	bodyDef.position = pos + mCfg.initialDisplacement*initialDir;
	bodyDef.fixedRotation = false;
	bodyDef.linearDamping = 0.0f;
	bodyDef.angularDamping = 0.0f;
	bodyDef.isBullet = true;
	bodyDef.angle = atan(initialDir.y/initialDir.x);
	mBody = CPhysicsManager::GetSingleton().GetPhysicsWorld()->CreateBody(&bodyDef);

	b2PolygonDef shapeDef;
	shapeDef.SetAsBox(0.5f*mSprite->GetWidth(), 0.5f*mSprite->GetHeight());
	shapeDef.density = mCfg.density;
	shapeDef.friction = mCfg.friction;
	shapeDef.restitution = mCfg.restitution;
	shapeDef.filter.categoryBits = ACTOR_PROJECTILE;
	shapeDef.filter.maskBits = ACTOR_ENEMY | ACTOR_PROJECTILE | ACTOR_STATIONARY;
	shapeDef.userData = this;
	mBody->CreateShape(&shapeDef);
	mBody->SetMassFromShapes();

	mBody->SetLinearVelocity(mCfg.initialVel* initialDir);
}

CNail::~CNail(void)
{
	CPhysicsManager::GetSingleton().GetPhysicsWorld()->DestroyBody(mBody);
	mBody = NULL;
	delete mSprite;
}

void CNail::Draw()
{
	glColor3f(1,1,1);
	glPushMatrix();
	b2Vec2 pos = mBody->GetPosition();
	float angle = mBody->GetAngle();
	glTranslatef(pos.x, pos.y, 0);
	glRotatef(angle*180/b2_pi, 0,0,1);
	mSprite->Draw();
	glPopMatrix();

}

void CNail::Collide(ZAMF::CActor *other, const CPhysicsManager::ContactPoint &cp, int pos)
{
	if (other != NULL && !(other->GetFlags()&ACTOR_PROJECTILE))
	{
		
		if (other->GetFlags() & ACTOR_ENEMY)
		{
			if (!mDestroyed)
			{
				CZombie *zomb = static_cast<CZombie*>(other);
				if (zomb)
				{
					zomb->Hit(mCfg.damage);
				}
				mDestroyed = true;
			}
			mDying = true;
		}
	}
	else
	{
		mDestroyed = true;
	}
}
