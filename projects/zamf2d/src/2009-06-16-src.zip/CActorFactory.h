#pragma once

#include "ActorDefs.h"
#include "CActor.h"
#include "CSingleton.h"
#include "tinyxml.h"
#include <string>
#include "common.h"
namespace ZAMF
{

	class CActorFactory : public CSingleton<CActorFactory>
	{
	public:
		CActorFactory(void);
		~CActorFactory(void);

		CActorCfg *Load(const std::string type, const std::string &name);

		//CActor *Create(const std::string &type, const std::string &name, float a1, float a2);
		//CActor *Create(const std::string &type, const std::string &name, const std::string &a1, const std::string &a2, float a3, float a4, float a5);
		//CActor *Create(const std::string &type, const std::string &name, float a1, float a2, float a3, float a4);
		//CActor *Create(const std::string &type, const std::string &name, b2Vec2 a1, b2Vec2 a2);

		//template<class _T1, class _T2>
		//CActor *Create(const std::string &type, const std::string &name, const _T1 &a1, const _T2 &a2);
		
		//template<class _T1, class _T2, class _T3, class _T4>
		//CActor *Create(const std::string &type, const std::string &name, const _T1 &a1, const _T2 &a2, const _T3 &a3, const _T4 &a4);
		
		//template<class _T1, class _T2, class _T3, class _T4, class _T5>
		//CActor *Create(const std::string &type, const std::string &name, const _T1 &a1, const _T2 &a2, const _T3 &a3, const _T4 &a4, const _T5 &a5);
		CActor *Create(const std::string &type, const std::string &name, const CActorDef *def);
	private:

#ifdef _WIN32
		typedef stdext::hash_map<std::string, CActorCfg* > ActorsCfgMap;
#else
		typedef std::unordered_map<std::string, CActorCfg* > ActorsCfgMap;
#endif
		CActorCfg *CreateOrLoadCfg(const std::string &type, const std::string &name);
		ActorsCfgMap mActorCfgs;
	};
};
