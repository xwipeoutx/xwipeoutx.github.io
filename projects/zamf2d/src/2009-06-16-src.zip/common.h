#pragma once

#ifdef _WIN32
#include "SDL.h"
#include "SDL_opengl.h"
#include "SDL_image.h"
#include "SDL_ttf.h"
#include "SDL_mixer.h"
#include <hash_map>
#else
#include "SDL/SDL.h"
#include "SDL/SDL_opengl.h"
#include "SDL/SDL_image.h"
#include "SDL/SDL_ttf.h"
#include "SDL/SDL_mixer.h"
#include <unordered_map>
#endif

#include "GL/glu.h"
#include "CEGUI.h"
#include "CEGUIDefaultResourceProvider.h"
#include "RendererModules/OpenGLGUIRenderer/openglrenderer.h"
