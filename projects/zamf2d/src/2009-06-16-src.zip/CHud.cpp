#include "CHud.h"
#include "utils.h"
#include "common.h"

#include "CScene.h"
#include "CPlayer.h"
#include "CItem.h"
#include "CSprite.h"

#include "CConfig.h"

//CEGUI
#include "CEGUI.h"

using namespace ZAMF;
using namespace CEGUI;
CHud::CHud(void)
{
	mEmptyBagDisplayList = glGenLists(1);
	glNewList(mEmptyBagDisplayList, GL_COMPILE);
	glBegin(GL_QUADS);
	{
		glVertex3f( 0,  0.05f, 0 );
		glVertex3f(  0.05f,   0.05f, 0 );
		glVertex3f(  0.05f,  0, 0 );
		glVertex3f( 0, 0, 0 );
	}
	glEnd();
	glEndList();
}

CHud::~CHud(void)
{
	glDeleteLists(mEmptyBagDisplayList, 1);
}

void CHud::UpdateScore()
{
	//score
	std::string str = "Score: " + ZAMF::ToString( CScene::GetSingleton().GetScore() );
	WindowManager::getSingleton().getWindow("Play/HUD/Score")->setText(str);
}

void CHud::UpdateHP(float hp, float maxHP)
{
	std::string str = "HP: " + ZAMF::ToString( hp ) + "/" + ZAMF::ToString( maxHP );
	WindowManager::getSingleton().getWindow("Play/HUD/HPBar")->setText(str);
	WindowManager::getSingleton().getWindow("Play/HUD/CurrentHP")->setText(str);

	float hpPercent = hp / maxHP;
	UDim width = WindowManager::getSingleton().getWindow("Play/HUD/HPBar")->getWidth();
	width.d_scale *= hpPercent;
	width.d_offset *= hpPercent;
	WindowManager::getSingleton().getWindow("Play/HUD/CurrentHP")->setWidth(width);
}

void CHud::UpdateInventory()
{
	//inventory
	const CPlayer *p = CScene::GetSingleton().GetPlayer();
	int bagCapacity = p->GetBagCapacity();
	for (int i=0; i<bagCapacity; i++)
	{
		std::string bagImage;
		std::string windowName = "Play/HUD/Inventory/Position" + ZAMF::ToString(i);
		Window *window = WindowManager::getSingleton().getWindow(windowName);
		CItem *item = p->GetItemFromBag(i);
		if (item != NULL)
		{
			std::string name = item->GetName();
			window->setProperty("Image", "set:Inventory image:"+name);
		}
		else
			window->setProperty("Image", "set:Inventory image:Empty");
	}
}
void CHud::DrawBgSprite(CSprite *sprite)
{
	//draw the background
	SetProjToGUI();
	glTranslatef(0.5f, 0.5f, 0);
	sprite->Draw();
}

void CHud::SetProjToGUI()
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	glOrtho(0, 1, 0, 1, -1, 1);

	//reset model view matrix
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

}
