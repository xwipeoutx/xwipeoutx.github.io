#pragma once

#include "CActor.h"
#include <string>

namespace ZAMF
{
	class CItemCfg : public CActorCfg
	{
	public:
		bool Load(TiXmlElement *root);
		int points;
	};
	class CPositionDef;
	class CItem : public CActor
	{
	public:
		enum ItemState
		{
			ITEM_IN_WORLD,
			ITEM_IN_INVENTORY,
			ITEM_IN_FRIDGE
		};
		CItem(const CItemCfg *cfg, const CPositionDef *def);
		~CItem(void);

		void PickUp();
		void PutInFridge();
		ItemState GetState(){return mState;}
		const std::string &GetType(){return mCfg.mType;}
		const std::string &GetSubType(){return mCfg.mSubType;}
		const std::string &GetName(){return mCfg.mName;}

		int GetPoints(){return mCfg.points;}

		bool Update(float dt);
		void Draw();

	protected:
		CItemCfg mCfg;

		ItemState mState;
		float mX, mY;
		b2Body *mBody;
	};
};
