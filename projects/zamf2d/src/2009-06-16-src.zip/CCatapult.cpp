#include "CCatapult.h"

#include "CActorFactory.h"
#include "ActorDefs.h"
#include "utils.h"

using namespace ZAMF;

bool CCatapultCfg::Load(TiXmlElement *root)
{
	CActorCfg::Load(root);

	TiXmlElement *el = root->FirstChildElement("firing");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("recoverytime", &mRecoveryTime) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("animationtime", &mAnimationTime) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("firingtime", &mFiringTime) );

	return true;
}

CCatapult::CCatapult(const CCatapultCfg *cfg, const CPositionDirectionDef *def)
: CActor(cfg, def)
{
	mCfg = *cfg;
	mX = def->x;
	mY = def->y;
	mDirection = (int)(def->xdir);
	
	mSprite->SetState(CATAPULT_FIRING);
	mState = CATAPULT_FIRING;
	mAnimationCountdown = mCfg.mAnimationTime;
	mFiringCountdown = mCfg.mFiringTime;
}

CCatapult::~CCatapult(void)
{
}

void CCatapult::HandleEvent(const SDL_Event &e)
{
	if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_v)
	{
		mState = CATAPULT_DYING;
		mSprite->SetState(2);
		mSprite->ResetFrame();
		mAnimationCountdown = 1;
	}
}

void CCatapult::Draw()
{
	glPushMatrix();
	glTranslatef(mX, mY, 0);
	if (mDirection < 0) glScalef(-1,1,1);
	mSprite->Draw();
	glPopMatrix();

}

bool CCatapult::Update(float dt)
{
	switch (mState)
	{
	case CATAPULT_IDLE:
		//idle - do nothing
		break;

	case CATAPULT_FIRING:
		mFiringCountdown -= dt;
		mAnimationCountdown -= dt;
		mSprite->AdvanceFrame(dt, false);
		if (mFiringCountdown < 0)
		{
			//FIRE
			CPositionDirectionDef mothballDef;
			mothballDef.x = mX; 
			mothballDef.y = mY + 0.5f; 
			mothballDef.xdir = (float)(mDirection);
			mothballDef.ydir = 1.f;
			CActorFactory::GetSingleton().Create("projectile", "mothball", &mothballDef);
			if (mAnimationCountdown < 0) 
			{
				mState = CATAPULT_RECOVERING;
				mRecoveryCountdown = mCfg.mRecoveryTime;
			}
			else
			{
				mState = CATAPULT_FINISHING;
			}
		}

		break;

	case CATAPULT_FINISHING:
		mAnimationCountdown -= dt;
		mSprite->AdvanceFrame(dt, false);
		if (mAnimationCountdown < 0) 
		{
			mState = CATAPULT_RECOVERING;
			mRecoveryCountdown = mCfg.mRecoveryTime;
		}
		break;

	case CATAPULT_RECOVERING:
		mRecoveryCountdown -= dt;
		mSprite->AdvanceFrame(-dt, false);
		if (mRecoveryCountdown < 0)
		{
			mState = CATAPULT_FIRING;
			//mSprite->SetState(CATAPULT_FIRING);
			mAnimationCountdown = mCfg.mAnimationTime;
			mFiringCountdown = mCfg.mFiringTime;
		}
		break;
	case CATAPULT_DYING:
		mAnimationCountdown -= dt;
		mSprite->AdvanceFrame(dt, false);
		if (mAnimationCountdown < 0)
		{
			mState = CATAPULT_DEAD;
			mSprite->SetState(3);
		}
		break;
	default:
		mSprite->AdvanceFrame(dt, false);
		break;
	}

	return true;
}