#pragma once
#include "CActor.h"

namespace ZAMF
{
	class CNailCfg : public CActorCfg
	{
	public:
		bool Load(TiXmlElement *root);

		float damage;
		float w, h;
		float initialVel, initialDisplacement;
		float density, friction, restitution;
	};

	class CPositionDirectionDef;

	class CNail : public ZAMF::CActor
	{
	public:

		//CNail(CNailCfg *def, b2Vec2 pos, b2Vec2 initialDir);
		CNail(const CNailCfg *cfg, const CPositionDirectionDef *def);
		~CNail(void);

		void Draw();
		void Collide(CActor *other, const CPhysicsManager::ContactPoint &cp, int pos);

		bool GetDestroyed(){return mDestroyed;}

	private:
		bool mDestroyed;
		CNailCfg mCfg;
	};
};