#pragma once

#include <string>

namespace ZAMF
{
	class CActorDef	{}; //implement in sub classes

	class CPositionDef  : public CActorDef
	{
	public:
		float x, y;
	};

	class CPositionDirectionDef : public CActorDef
	{
	public:
		float x,y,xdir,ydir;
	};
	
	class CPositionSizeDef : public CActorDef
	{
	public:
		float x,y,w,h;
	};

	class CPositionNameTypeDelayDef : public CActorDef
	{
	public:
		std::string type, name;
		float x, y, delay;
	};
};