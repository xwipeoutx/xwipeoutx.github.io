#include "common.h"

#define RUN_EXAMPLE_ID 1

#if RUN_EXAMPLE_ID == 1
#define RUN_EXAMPLE StartZAMF2D
#else
#if RUN_EXAMPLE_ID == 2
#define RUN_EXAMPLE mStartSDLExample
#endif
#endif
//standard example
//#define RUN_EXAMPLE mStartSDLExample
//zamf 2d
//#define RUN_EXAMPLE StartZAMF2D

int RUN_EXAMPLE( int argc, char* args[] );

int main( int argc, char* args[] )
{
	return RUN_EXAMPLE( argc, args );
}
