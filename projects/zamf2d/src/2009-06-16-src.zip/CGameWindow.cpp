#include "CGameWindow.h"
#include "CGameManager.h"

#include "CTimer.h"
#include "common.h" 
#include <sstream>

using namespace ZAMF;
CGameWindow::CGameWindow(void)
: mFPS(0)
{
	mWidth = SCREEN_WIDTH;
	mHeight = SCREEN_HEIGHT;
	mScreen = SDL_SetVideoMode(
		mWidth, mHeight, 
		SCREEN_BPP, 
		SDL_OPENGL | SDL_RESIZABLE | SDL_GL_ACCELERATED_VISUAL);

	if (mScreen == NULL)
	{
		mWindowOK = false;
		return;
	}
	mWindowOK = true;
	
	SDL_WM_SetCaption("ZAMF 2D", NULL);
	mWindowed = true;

	mFPSTimer.Start();
	mFrame = 0;
}

CGameWindow::~CGameWindow(void)
{
	SDL_FreeSurface(mScreen);
}

void CGameWindow::HandleEvent(const SDL_Event &e)
{
	if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_RETURN)
	{
		//this->ToggleFullScreen();
	}
	if (e.type == SDL_QUIT)
		CGameManager::GetSingleton().Shutdown();
}

void CGameWindow::ToggleFullScreen()
{
	if (mWindowed)
	{
		mScreen = SDL_SetVideoMode(mWidth, mHeight, SCREEN_BPP, SDL_OPENGL | SDL_RESIZABLE | SDL_FULLSCREEN);
		if (mScreen == NULL)
		{
			mWindowOK = false;
			return;
		}
		mWindowed = false;
	}
	else
	{	
		mScreen = SDL_SetVideoMode(mWidth, mHeight, SCREEN_BPP, SDL_OPENGL | SDL_RESIZABLE);

		if (mScreen == NULL)
		{
			mWindowOK = false;
			return;
		}
		mWindowed = true;
	}
}

void CGameWindow::StartFrame()
{
	glClear(GL_COLOR_BUFFER_BIT);	
}

void CGameWindow::EndFrame()
{
	//glFinish();
	SDL_GL_SwapBuffers();

	//framerate
	mFrame++;
	if (mFPSTimer.GetTicks() > 1000)
	{
		float mFPS = 1000.0f*mFrame/mFPSTimer.GetTicks();
		mFrame = 0;
		mFPSTimer.Start();

		//put in window
		std::ostringstream strFPS;
		strFPS << "ZAMF 2D FPS: " << mFPS;
		SDL_WM_SetCaption(strFPS.str().c_str(), NULL);

	}

}