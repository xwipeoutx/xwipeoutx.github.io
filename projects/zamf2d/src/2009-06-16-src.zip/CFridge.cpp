#include "CFridge.h"
#include "CSpriteFactory.h"
#include "CScene.h"
#include "CPhysicsManager.h"
#include "ActorDefs.h"
#include "CDeadState.h"
using namespace ZAMF;


CFridgeCfg::CFridgeCfg()
{

}

bool CFridgeCfg::Load(TiXmlElement *root)

	{
	mType = root->Attribute("type");
	mSubType = root->Attribute("subtype");
	mName = std::string(root->FirstChildElement("name")->GetText());

	TiXmlElement *el=NULL;
	el = root->FirstChildElement("sprite");
	el = el->FirstChildElement("image");
	mSpriteFilename =  std::string(el->Attribute("filename"));

	mLoaded = true;
	return true;
}

CFridge::CFridge(const CFridgeCfg *cfg, const CPositionSizeDef *def)
: CActor(cfg, def)
{
	mFlags = ACTOR_FRIDGE;

	mSprite = CSpriteFactory::GetSingleton().Load(cfg->mType, cfg->mName, cfg->mSpriteFilename, def->w, def->h);

	//fridge is a static body, yay
	b2BodyDef bodyDef;
	bodyDef.position.Set(def->x, def->y);
	mBody = CPhysicsManager::GetSingleton().GetPhysicsWorld()->CreateBody(&bodyDef);

	b2PolygonDef shapeDef;
	shapeDef.SetAsBox(0.5f*mSprite->GetWidth(), 0.5f*mSprite->GetHeight());
	shapeDef.filter.categoryBits = ACTOR_FRIDGE;
	shapeDef.filter.maskBits = ACTOR_PLAYER | ACTOR_ENEMY;
	shapeDef.userData = this;
	shapeDef.isSensor = true;
	mBody->CreateShape(&shapeDef);
}

CFridge::~CFridge(void)
{
	CPhysicsManager::GetSingleton().GetPhysicsWorld()->DestroyBody(mBody);
	mBody = NULL;
}

void CFridge::Draw()
{
	b2Vec2 pos = mBody->GetPosition();

	glPushMatrix();
	glTranslatef(pos.x, pos.y, 0);
	mSprite->Draw();

	glPopMatrix();
}

void CFridge::Hit()
{
	if (!this->GetDying())
	{
		CGameManager::GetSingleton().PushState(new CDeadState());
		this->SetDying(true);
	}
}