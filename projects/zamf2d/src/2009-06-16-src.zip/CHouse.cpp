#include "CHouse.h"
#include "CGameWindow.h"
#include "CActorFactory.h"

#include "tinyxml.h"
#include "utils.h"

#include <fstream>

using namespace ZAMF;
using namespace std;

CHouse::CHouse()
{
}

CHouse::~CHouse(void)
{
}

void CHouse::Build(string house)
{
	return;
	/*TODO: Load House
	string filename="../../resource/houseplan/" + house + ".xml";

	TiXmlDocument doc(filename.c_str());
	bool ok = doc.LoadFile();
	if (!ok)
	{
		const char *desc = doc.ErrorDesc();
		throw(desc);
	}

	float x=0,y=0,w=0,h=0;
	TiXmlElement *el=NULL;
	TiXmlElement *root = doc.FirstChildElement("house");

	//dimensions
	el = root->FirstChildElement("dimensions");
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "x", &x ) );
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "y", &y ) );
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "w", &w ) );
	ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "h", &h ) );
	BuildHouseFrame(x,y,w,h);

	//structures
	el = root->FirstChildElement("structures");
	if (el != NULL)
		el = el->FirstChildElement("box");
	while (el != NULL)
	{
		ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "x", &x ) );
		ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "y", &y ) );
		ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "w", &w ) );
		ZAMF::CheckXMLSuccessAttribute( el->QueryFloatAttribute( "h", &h ) );

		AddStructure(x, y, w, h);

		el = el->NextSiblingElement("box");
	}



#ifdef _DEBUG
	mEnableActorDrawing = true;
#else
	mEnableDebugDrawing = false;
#endif
	return;
	*/
}
