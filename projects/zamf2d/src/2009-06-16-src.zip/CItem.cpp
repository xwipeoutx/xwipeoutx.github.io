#include "CItem.h"
#include "CScene.h"
#include "utils.h"
#include "CPhysicsManager.h"
#include "ActorDefs.h"

using namespace ZAMF;

bool CItemCfg::Load(TiXmlElement *root)
{
	CActorCfg::Load(root);
	
	
	TiXmlElement *el = root->FirstChildElement("stats");
	CheckXMLSuccessAttribute( el->QueryIntAttribute("points", &points) );

	return true;
}

CItem::CItem(const CItemCfg *cfg, const CPositionDef *def)
: CActor(cfg, def)
{
	mX = def->x;
	mY = def->y;
	mCfg = *cfg;
	mFlags = ACTOR_ITEM;
	mState = ITEM_IN_WORLD;

	//create a sensor for it	//add to physics world
	b2BodyDef bodyDef;
	bodyDef.position.Set(mX, mY);
	mBody = CPhysicsManager::GetSingleton().GetPhysicsWorld()->CreateBody(&bodyDef);

	b2PolygonDef bodyShape;
	bodyShape.SetAsBox(0.5f*mSprite->GetWidth(), 0.5f*mSprite->GetHeight());
	bodyShape.filter.categoryBits = ACTOR_ITEM;
	bodyShape.filter.maskBits = ACTOR_PLAYER | ACTOR_STATIONARY;
	bodyShape.userData = this;
	bodyShape.isSensor = true;
	mBody->CreateShape(&bodyShape);
}

CItem::~CItem(void)
{
	if (mBody != NULL)
	{
		CPhysicsManager::GetSingleton().GetPhysicsWorld()->DestroyBody(mBody);
		mBody = NULL;
	}

}

bool CItem::Update(float dt)
{
	if (mBody != NULL && mState != ITEM_IN_WORLD)
	{
		CPhysicsManager::GetSingleton().GetPhysicsWorld()->DestroyBody(mBody);
		mBody = NULL;
	}
	return true;
}

void CItem::Draw()
{
	if (mState == ITEM_IN_WORLD)
	{
		glPushMatrix();
		glTranslatef(mBody->GetPosition().x, mBody->GetPosition().y, 0);
		mSprite->Draw();
		glPopMatrix();
	}
}

void CItem::PickUp()
{
	mState = ITEM_IN_INVENTORY;
}

void CItem::PutInFridge()
{
	mState = ITEM_IN_FRIDGE;
}