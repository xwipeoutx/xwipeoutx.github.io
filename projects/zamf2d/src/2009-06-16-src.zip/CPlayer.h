#pragma once

#include "CActor.h"
#include "CItem.h"
#include "sdlinc.h"
#include <vector>

namespace ZAMF
{
	#define PLAYER_JUMP_VEL 7.0f

	#define PLAYER_FACING_RIGHT 0
	#define PLAYER_FACING_LEFT 1

	class CPlayerCfg : public CActorCfg
	{
	public: 
		bool Load(TiXmlElement *root);

		float maxHP;
		float maxVel, accelForce, jumpForce;
		int initialDir;
		float density, friction, restitution;

		int bagCapacity;
	};

	class CPositionDef;

	class CPlayer :	public CActor
	{
	public:
		CPlayer(const CPlayerCfg *cfg, const CPositionDef *def);
		~CPlayer(void);

		virtual void HandleEvent(const SDL_Event &e);
		bool Update(float dt);
		void Draw();
		
		bool AddItemToBag(CItem *item);

		int GetFirstOccupiedItemPosition(int start=0) const;
		int GetFirstFreeBagPosition(int start=0) const;
		CItem *GetItemFromBag(int position) const;
		bool RemoveItemFromBag(int position);

		b2Vec2 GetPosition() const;
		int GetBagCapacity() const{return mCfg.bagCapacity;}

		void Collide(CActor *other, const CPhysicsManager::ContactPoint &cp, int pos);

		void Hit(float dmg);

		float GetHP(){return mHP;}
		float GetMaxHP(){return mCfg.maxHP;}

	private:

		void FireNail();
		void Jump();

		CPlayerCfg mCfg;
		float mVel;
		bool mOnGround;

		float mHP;

		Mix_Chunk *mOofSound;

		//Inventory stuff
		std::vector<CItem*> mBag;
		//CMeleeWeapon *mMeleeWeapon;
		//CRangedWeapon *mRangedWeapon;
		//CArmour *mArmour;

	};
};