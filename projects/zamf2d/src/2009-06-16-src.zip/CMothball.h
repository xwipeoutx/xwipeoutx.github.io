#pragma once
#include "CActor.h"

namespace ZAMF
{
	class CMothballCfg : public CActorCfg
	{
	public:
		bool Load(TiXmlElement *root);

		float baseDamage, damageMultiplier;
		float w, h;
		float initialVel, initialDisplacement;
		float density, friction, restitution;
		float linearDamping, angularDamping;
	};

	class CPositionDirectionDef;

	class CMothball : public ZAMF::CActor
	{
	public:
		CMothball(const CMothballCfg *cfg, const CPositionDirectionDef *def);
		~CMothball(void);

		void Draw();
		bool Update(float dt);
		void Collide(CActor *other, const CPhysicsManager::ContactPoint &cp, int pos);

		bool GetDestroyed(){return mDestroyed;}

	private:
		bool mDestroyed;
		float mCountdown;
		CMothballCfg mCfg;
	};
};