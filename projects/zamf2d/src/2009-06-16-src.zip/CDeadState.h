#pragma once

#include "IGameState.h"

namespace ZAMF
{
	class CDeadState : public IGameState
	{
	public:
		CDeadState(void);
		~CDeadState(void);

		virtual void Enter();
		virtual void Exit();

		virtual void Pause();
		virtual void Resume();
		
		virtual void HandleEvent(const SDL_Event &e);
		virtual void Draw();
		
		inline virtual const std::string GetStateName(){return "DeadState";}
	};
}