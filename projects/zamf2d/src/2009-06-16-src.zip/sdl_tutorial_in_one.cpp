#include "common.h"

#include <string>
#include <sstream>
#include <fstream>

#define SDLT1_RES_BASE "../../resource"

const int SCREEN_WIDTH = 640;
const int SCREEN_HEIGHT = 480;
const int SCREEN_BPP = 32;
const int FRAMES_PER_SECOND = 60;

const int LEVEL_WIDTH = 1280;
const int LEVEL_HEIGHT = 960;

//The button states in the sprite sheet
const int CLIP_MOUSEOVER = 0;
const int CLIP_MOUSEOUT = 1;
const int CLIP_MOUSEDOWN = 2;
const int CLIP_MOUSEUP = 3;

const int PLAYER_YSPEED = 1800;
const int PLAYER_XSPEED = 400;
const int PLAYER_GRAVITY = 6400;
const int PLAYER_HEIGHT = 64;
const int PLAYER_WIDTH = 32;
const int TOTAL_PARTICLES = 200;

const int PLAYER_LEFT = 0;
const int PLAYER_RIGHT = 1;
const int NUM_PLAYER_ANIMATION_FRAMES = 4;
const int PLAYER_ANIMATION_FPS = 24;

//Tile constants
const int TILE_WIDTH = 80;
const int TILE_HEIGHT = 80;
const int TOTAL_TILES = 192;
const int TILE_SPRITES = 12;

//The different tile sprites
const int TILE_RED = 0;
const int TILE_GREEN = 1;
const int TILE_BLUE = 2;
const int TILE_CENTER = 3;
const int TILE_TOP = 4;
const int TILE_TOPRIGHT = 5;
const int TILE_RIGHT = 6;
const int TILE_BOTTOMRIGHT = 7;
const int TILE_BOTTOM = 8;
const int TILE_BOTTOMLEFT = 9;
const int TILE_LEFT = 10;
const int TILE_TOPLEFT = 11;

SDL_Rect wall;

SDL_Surface *background = NULL;
SDL_Surface *person = NULL;
SDL_Surface *personFlipped = NULL;
SDL_Surface *clips = NULL;
SDL_Surface *screen = NULL;

SDL_Surface *shimmer = NULL;
SDL_Surface *red = NULL;
SDL_Surface *green = NULL;
SDL_Surface *blue = NULL;

//sounds
Mix_Music *music = NULL;
Mix_Chunk *scratch = NULL;
Mix_Chunk *low = NULL;
Mix_Chunk *med = NULL;
Mix_Chunk *high = NULL;

//The surfaces
SDL_Surface *buttonSheet = NULL;
SDL_Surface *message = NULL;
SDL_Surface *upMessage = NULL;
SDL_Surface *downMessage = NULL;
SDL_Surface *leftMessage = NULL;
SDL_Surface *rightMessage = NULL;
SDL_Surface *tileSheet = NULL;

TTF_Font *font = NULL;

SDL_Color textColor = { 255, 255, 255 };
SDL_Rect camera = {0, 0, SCREEN_WIDTH, SCREEN_HEIGHT};

SDL_Rect clip[4];
//The clip regions of the sprite sheet
SDL_Rect tileClips[TOTAL_TILES];
SDL_Rect buttonClips[4];
SDL_Rect personClipsLeft[NUM_PLAYER_ANIMATION_FRAMES];
SDL_Rect personClipsRight[NUM_PLAYER_ANIMATION_FRAMES];

SDL_Event event;

//The button
class Tile
{
private:
	SDL_Rect box;
	int type;
public:
	Tile(int x, int y, int tileType);
	void Show();
	int GetType(){return type;}
	SDL_Rect GetBox(){return box;}
};
class Button
{
    private:
    //The attributes of the button
    SDL_Rect box;

    //The part of the button sprite sheet that will be shown
    SDL_Rect *clip;

    public:
    //Initialize the variables
    Button( int x, int y, int w, int h );

    //Handles events and set the button's sprite region
    void handle_events();

    //Shows the button on the screen
    void show();
};


class Timer
{
private:
	int mStartTicks;
	int mPausedTicks;

	bool mPaused;
	bool mStarted;
public:
	Timer();
	void Start();
	void Stop();
	void Pause();
	void Unpause();
	int GetTicks();
	bool IsStarted(){return mStarted;}
	bool IsPaused(){return mPaused;}

};

class Particle
{
private:
	int x, y;
	Timer timer;
	int msToLive;
	SDL_Surface *type;
public:
	Particle(int x, int y);
	void Show();
	bool IsDead();

};
class Player
{
private:
	float x;
	float y;
	SDL_Rect box;
	int xVel, yVel;

	float frame;
	int status;

	Particle *particles[ TOTAL_PARTICLES ];

public:
	Player();
	~Player();
	void handle_input();
	void move(Uint32 deltaTicks, Tile *tiles[]);
	void show();
	void SetCamera();
	void ShowParticles();

	float GetX(){return x;}
	float GetY(){return y;}
	void SetX(float _x){x = _x;}
	void SetY(float _y){y = _y;}
};
Uint32 get_pixel32(SDL_Surface *surface, int x, int y)
{
	Uint32 *pixels = (Uint32 *)surface->pixels;
	return pixels[(y*surface->w)+x];
}
void put_pixel32(SDL_Surface *surface, int x, int y, Uint32 pixel)
{
	Uint32 *pixels = (Uint32 *)surface->pixels;
	pixels[(y*surface->w)+x] = pixel;
}
SDL_Surface *LoadImage( std::string filename )
{
	SDL_Surface *loadedImage = NULL;
	SDL_Surface *optimizedImage = NULL;
	loadedImage = IMG_Load( filename.c_str() );

	if (loadedImage != NULL)
	{
		optimizedImage = SDL_DisplayFormat( loadedImage );
		SDL_FreeSurface( loadedImage );
	}

	if (optimizedImage != NULL)
	{
		Uint32 colorkey = SDL_MapRGB( optimizedImage->format, 0, 0xFF, 0xFF);
		SDL_SetColorKey( optimizedImage, SDL_SRCCOLORKEY, colorkey);
	}

	return optimizedImage;
}

void ApplySurface(int x, int y, SDL_Surface *source, SDL_Surface *destination, SDL_Rect *clip = NULL)
{
	SDL_Rect offset;
	offset.x = x;
	offset.y = y;
	SDL_BlitSurface(source, clip, destination, &offset);
}

bool Init()
{
	//Start SDL
	if ( SDL_Init( SDL_INIT_VIDEO ) == -1 )	return false;

	screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_BPP, SDL_SWSURFACE );

	if (screen == NULL)	return false;

	if (TTF_Init() == -1) return false;

	if (Mix_OpenAudio(22050, MIX_DEFAULT_FORMAT, 2, 4096) == -1 ) return false;

	SDL_WM_SetCaption("Event Test", NULL);

	srand(SDL_GetTicks());

	return true;
}

bool LoadFiles(Player &player)
{
	person = LoadImage("../../resource/sprite/player.png");
	if (person == NULL) return false;

	//flip the person
	if (person->flags & SDL_SRCCOLORKEY)
	{
		personFlipped = SDL_CreateRGBSurface( SDL_SWSURFACE, person->w, person->h, person->format->BitsPerPixel, person->format->Rmask, person->format->Gmask, person->format->Bmask, 0);
		SDL_SetColorKey( personFlipped, SDL_SRCCOLORKEY, person->format->colorkey);
	}
	else
	{
		personFlipped = SDL_CreateRGBSurface( SDL_SWSURFACE, person->w, person->h, person->format->BitsPerPixel, person->format->Rmask, person->format->Gmask, person->format->Bmask, person->format->Amask);
	}


	if (SDL_MUSTLOCK(person))
		SDL_LockSurface(person);
	for (int x=0, rx=personFlipped->w - 1; x < personFlipped->w; x++, rx--)
	{
		for (int y=0, ry=personFlipped->h - 1; y < personFlipped->h; y++, ry--)
		{
			Uint32 pixel = get_pixel32(person, x, y);
			put_pixel32(personFlipped, rx, ry, pixel);
		}
	}
	if (SDL_MUSTLOCK(person))
		SDL_UnlockSurface(person);

	background = LoadImage("../../resource/sprites/background.jpg");
	if (background == NULL) return false;
	clips = LoadImage("../../resource/sprites/sprites.jpg");
	if (clips == NULL) return false;
	buttonSheet = LoadImage("../../resource/sprites/button.png");
	if (buttonSheet == NULL) return false;


	red = LoadImage("../../resource/sprites/red.bmp");
	if (red == NULL) return false;
	green = LoadImage("../../resource/sprites/green.bmp");
	if (green == NULL) return false;
	blue = LoadImage("../../resource/sprites/blue.bmp");
	if (blue == NULL) return false;
	shimmer = LoadImage("../../resource/sprites/shimmer.bmp");
	if (shimmer == NULL) return false;

	tileSheet = LoadImage("../../resource/sprites/tiles.png");
	if (tileSheet == NULL) return false;

	music = Mix_LoadMUS("../../resource/sounds/beat.wav");
	if (music == NULL) return false;

	scratch = Mix_LoadWAV("../../resource/sounds/scratch.wav");
	high = Mix_LoadWAV("../../resource/sounds/low.wav");
	med = Mix_LoadWAV("../../resource/sounds/medium.wav");
	low = Mix_LoadWAV("../../resource/sounds/high.wav");
	if( ( scratch == NULL ) || ( high == NULL ) || ( med == NULL ) || ( low == NULL ) )
		return false;

	font = TTF_OpenFont("../../resource/lazy.ttf", 28);

	//load save game
	std::ifstream load("game_save");
	if (load != NULL)
	{
		float offset;
		load >> offset;
		player.SetX(offset);
		load >> offset;
		player.SetY(offset);
		load.close();
	}
	return true;
}

void CleanUp(Player &player)
{
	//save file
	std::ofstream save("game_save");
	save << player.GetX() << " " << player.GetY();
	save.close();

	SDL_FreeSurface(person);
	SDL_FreeSurface(background);
	SDL_FreeSurface(clips);
	SDL_FreeSurface(message);
	SDL_FreeSurface(buttonSheet);

	Mix_FreeMusic(music);
	Mix_FreeChunk(scratch);
	Mix_FreeChunk(high);
	Mix_FreeChunk(med);
	Mix_FreeChunk(low);

	TTF_CloseFont(font);
	Mix_CloseAudio();

	TTF_Quit();

	SDL_Quit();
}


void set_clips()
{
    //Clip the sprite sheet
    buttonClips[ CLIP_MOUSEOVER ].x = 0;
    buttonClips[ CLIP_MOUSEOVER ].y = 0;
    buttonClips[ CLIP_MOUSEOVER ].w = 80;
    buttonClips[ CLIP_MOUSEOVER ].h = 60;

    buttonClips[ CLIP_MOUSEOUT ].x = 80;
    buttonClips[ CLIP_MOUSEOUT ].y = 0;
    buttonClips[ CLIP_MOUSEOUT ].w = 80;
    buttonClips[ CLIP_MOUSEOUT ].h = 60;

    buttonClips[ CLIP_MOUSEDOWN ].x = 0;
    buttonClips[ CLIP_MOUSEDOWN ].y = 60;
    buttonClips[ CLIP_MOUSEDOWN ].w = 80;
    buttonClips[ CLIP_MOUSEDOWN ].h = 60;

    buttonClips[ CLIP_MOUSEUP ].x = 80;
    buttonClips[ CLIP_MOUSEUP ].y = 60;
    buttonClips[ CLIP_MOUSEUP ].w = 80;
    buttonClips[ CLIP_MOUSEUP ].h = 60;

	for (int i=0;i<NUM_PLAYER_ANIMATION_FRAMES; i++)
	{
		personClipsRight[i].x = i*PLAYER_WIDTH;
		personClipsRight[i].y = 0;
		personClipsRight[i].w = PLAYER_WIDTH;
		personClipsRight[i].h = PLAYER_HEIGHT;

		personClipsLeft[i].x = i*PLAYER_WIDTH;
		personClipsLeft[i].y = PLAYER_HEIGHT;
		personClipsLeft[i].w = PLAYER_WIDTH;
		personClipsLeft[i].h = PLAYER_HEIGHT;
	}

	for (int i=0; i<TILE_SPRITES; i++)
	{
		int index = TILE_RED;
		if (i == 0) index = TILE_RED;
		if (i == 1) index = TILE_GREEN;
		if (i == 2) index = TILE_BLUE;
		if (i == 3) index = TILE_TOPLEFT;
		if (i == 4) index = TILE_LEFT;
		if (i == 5) index = TILE_BOTTOMLEFT;
		if (i == 6) index = TILE_TOP;
		if (i == 7) index = TILE_CENTER;
		if (i == 8) index = TILE_BOTTOM;
		if (i == 9) index = TILE_TOPRIGHT;
		if (i == 10) index = TILE_RIGHT;
		if (i == 11) index = TILE_BOTTOMRIGHT;
		//Clip the sprite sheet
		tileClips[ index ].x = TILE_WIDTH*((int)(i/3));
		tileClips[ index ].y = TILE_HEIGHT*(i % 3);
		tileClips[ index ].w = TILE_WIDTH;
		tileClips[ index ].h = TILE_HEIGHT;
	}
}

bool set_tiles( Tile *tiles[] )
{
	int x=0, y=0;

	std::ifstream map("../../resource/lazy.map");
	if (map == NULL) return false;

	for (int t=0; t < TOTAL_TILES; t++)
	{
		int tileType = -1;
		map >> tileType;

		if (map.fail() == true)
		{
			map.close();
			return false;
		}

		if (tileType >= 0 && tileType < TILE_SPRITES)
		{
			tiles[t] = new Tile(x, y, tileType);
		}
		else
		{
			map.close();
			return false;
		}

		x+= TILE_WIDTH;
		if (x >= LEVEL_WIDTH)
		{
			x = 0;
			y += TILE_HEIGHT;
		}
	}
	map.close();
	return true;
}
bool check_collision(const SDL_Rect &A, const SDL_Rect &B)
{
	int leftA, leftB, rightA, rightB, topA, topB, bottomA, bottomB;

	leftA = A.x;
	rightA = A.x + A.w;
	topA = A.y;
	bottomA = A.y + A.h;

	leftB = B.x;
	rightB = B.x + B.w;
	topB = B.y;
	bottomB = B.y + B.h;

	if (bottomA <= topB) return false;
	if (topA >= bottomB) return false;
	if (rightA <= leftB) return false;
	if (leftA >= rightB) return false;
	return true;
}
bool touches_wall(SDL_Rect &box, Tile *tiles[])
{
	for (int t=0; t < TOTAL_TILES; t++)
	{
		if (tiles[t]->GetType() >= TILE_CENTER && tiles[t]->GetType() <= TILE_TOPLEFT)
		{
			if (check_collision(box, tiles[t]->GetBox()) == true)
			{
				return true;
			}
		}
	}
	return false;
}
Tile::Tile(int x, int y, int tileType)
{
	box.x = x;
	box.y = y;
	box.w = TILE_WIDTH;
	box.h = TILE_HEIGHT;

	type = tileType;
}
void Tile::Show()
{
	if ( check_collision(camera, box) )
	{
		ApplySurface( box.x - camera.x, box.y - camera.y, tileSheet, screen, &tileClips[ type ]);
	}
}
Button::Button( int x, int y, int w, int h )
{
    //Set the button's attributes
    box.x = x;
    box.y = y;
    box.w = w;
    box.h = h;

    //Set the default sprite
    clip = &buttonClips[ CLIP_MOUSEOUT ];
}

void Button::handle_events()
{
    //The mouse offsets
    int x = 0, y = 0;

    //If the mouse moved
    if( event.type == SDL_MOUSEMOTION )
    {
        //Get the mouse offsets
        x = event.motion.x;
        y = event.motion.y;

        //If the mouse is over the button
        if( ( x > box.x ) && ( x < box.x + box.w ) && ( y > box.y ) && ( y < box.y + box.h ) )
        {
            //Set the button sprite
			this->clip = &buttonClips[ CLIP_MOUSEOVER ];
        }
        //If not
        else
        {
            //Set the button sprite
            clip = &buttonClips[ CLIP_MOUSEOUT ];
        }
    }
    //If a mouse button was pressed
    if( event.type == SDL_MOUSEBUTTONDOWN )
    {
        //If the left mouse button was pressed
        if( event.button.button == SDL_BUTTON_LEFT )
        {
            //Get the mouse offsets
            x = event.button.x;
            y = event.button.y;

            //If the mouse is over the button
            if( ( x > box.x ) && ( x < box.x + box.w ) && ( y > box.y ) && ( y < box.y + box.h ) )
            {
                //Set the button sprite
                clip = &buttonClips[ CLIP_MOUSEDOWN ];
            }
        }
    }
    //If a mouse button was released
    if( event.type == SDL_MOUSEBUTTONUP )
    {
        //If the left mouse button was released
        if( event.button.button == SDL_BUTTON_LEFT )
        {
            //Get the mouse offsets
            x = event.button.x;
            y = event.button.y;

            //If the mouse is over the button
            if( ( x > box.x ) && ( x < box.x + box.w ) && ( y > box.y ) && ( y < box.y + box.h ) )
            {
                //Set the button sprite
                clip = &buttonClips[ CLIP_MOUSEUP ];
            }
        }
    }
}

void Button::show()
{
	SDL_SetAlpha(buttonSheet, SDL_SRCALPHA, 128);
    //Show the button
	ApplySurface( box.x, box.y, buttonSheet, screen, this->clip );
}


Timer::Timer()
{
	mStartTicks = mPausedTicks = 0;
	mPaused = mStarted = 0;
}

void Timer::Start()
{
	mStarted = true;
	mPaused = false;
	mStartTicks = SDL_GetTicks();
}
void Timer::Stop()
{
	mStarted = mPaused = false;
}
int Timer::GetTicks()
{
	if (mStarted)
	{
		if (mPaused)
		{
			return mPausedTicks;
		}
		else
		{
			return SDL_GetTicks() - mStartTicks;
		}
	}
	return 0;
}
void Timer::Pause()
{
	if (mStarted && !mPaused)
	{
		mPaused = true;
		mPausedTicks = SDL_GetTicks() - mStartTicks;
	}
}

void Timer::Unpause()
{
	if (mPaused)
	{
		mPaused = false;
		mStartTicks = SDL_GetTicks() - mPausedTicks;
		mPausedTicks = 0;
	}
}

Particle::Particle(int x, int y)
{
	this->x = x - PLAYER_WIDTH/2 + 2*(rand()%PLAYER_WIDTH);
	this->y = y - PLAYER_HEIGHT/2 + 2*(rand()%PLAYER_HEIGHT);
	msToLive = rand()%2000;
	timer.Start();
	switch (rand()%3)
	{
	case 0: type = red; break;
	case 1: type = green; break;
	default: type = blue; break;
	}
}
void Particle::Show()
{
	ApplySurface(x-camera.x, y-camera.y, type, screen);

	if (rand() % 5 == 0)
		ApplySurface(x-camera.x, y-camera.y, shimmer, screen);
}
bool Particle::IsDead()
{
	return (timer.GetTicks() > msToLive);
}
Player::Player()
{
	x = 30;
	y = 400;
	box.x = box.y = 0;
	box.h = PLAYER_HEIGHT;
	box.w = PLAYER_WIDTH;
	xVel=yVel=0;
	frame = 0;
	status = PLAYER_RIGHT;

	for (int p = 0; p < TOTAL_PARTICLES; p++)
	{
		particles[p] = new Particle(box.x, box.y);
	}

}
Player::~Player()
{
	for (int p=0; p<TOTAL_PARTICLES; p++)
	{
		delete particles[p];
	}
}
void Player::handle_input()
{
	if (event.type == SDL_KEYDOWN)
	{
		switch (event.key.keysym.sym)
		{
		case SDLK_UP: if (abs(yVel) < 0.001) yVel -= PLAYER_YSPEED; break;
		//case SDLK_DOWN: yVel += PLAYER_YSPEED; break;
		case SDLK_LEFT: xVel -= PLAYER_XSPEED; break;
		case SDLK_RIGHT: xVel += PLAYER_XSPEED; break;
		default: ;
		}
	}
	else if (event.type == SDL_KEYUP)
	{
		switch (event.key.keysym.sym)
		{
		//case SDLK_UP: yVel += PLAYER_YSPEED; break;
		//case SDLK_DOWN: yVel -= PLAYER_YSPEED; break;
		case SDLK_LEFT: xVel += PLAYER_XSPEED; break;
		case SDLK_RIGHT: xVel -= PLAYER_XSPEED; break;
		default: ;
		}
	}
}
void Player::move(Uint32 deltaTicks, Tile *tiles[])
{

	float dt = 0.001f * deltaTicks;

	//x movement
	float xSpeed = xVel * dt;
	x += xSpeed;
	if (x < 0) x = 0;
	else if (x + PLAYER_WIDTH > LEVEL_WIDTH) x = LEVEL_WIDTH - PLAYER_WIDTH;
	box.x = (int)x;
	if (touches_wall(box, tiles))
		x -= xSpeed;
	box.x = (int)x;

	//y movement
	yVel += (int)(PLAYER_GRAVITY * dt);
	float ySpeed = yVel * dt;
	y += ySpeed;
	if (y < 0) y = 0;
	else if(y + PLAYER_HEIGHT > LEVEL_HEIGHT)
	{
		y = LEVEL_HEIGHT - PLAYER_HEIGHT;
		yVel = 0;
	}
	box.y = (int)y;
	if (touches_wall(box, tiles))
	{
		y -= ySpeed;
		yVel = 0;
	}
	box.y = (int)y;

	//frames
	frame += dt*PLAYER_ANIMATION_FPS;
	while (frame > NUM_PLAYER_ANIMATION_FRAMES)
		frame -= NUM_PLAYER_ANIMATION_FRAMES;


}
void Player::SetCamera()
{
	camera.x = (box.x + PLAYER_WIDTH/2) - SCREEN_WIDTH/2;
	camera.y = (box.y + PLAYER_HEIGHT/2) - SCREEN_HEIGHT/2;
	if (camera.x < 0) camera.x = 0;
	if (camera.y < 0) camera.y = 0;
	if (camera.x + camera.w > LEVEL_WIDTH) camera.x = LEVEL_WIDTH - camera.w;
	if (camera.y + camera.h > LEVEL_HEIGHT) camera.y = LEVEL_HEIGHT - camera.h;

}
void Player::show()
{
	int frameNum = (int)frame;
	if (xVel < 0)
	{
		status = PLAYER_LEFT;
	}
	else if (xVel > 0)
	{
		status = PLAYER_RIGHT;
	}
	else
	{
		frameNum = 0;
	}

	int displayx = box.x - camera.x;
	int displayy = box.y - camera.y;

	ShowParticles();
	SDL_Surface *playerDisplaySurface = person;
	if (yVel > 0) playerDisplaySurface = personFlipped;

	if (status == PLAYER_LEFT)
		ApplySurface(displayx, displayy, playerDisplaySurface, screen, &personClipsLeft[frameNum]);
	else if (status == PLAYER_RIGHT)
		ApplySurface(displayx, displayy, playerDisplaySurface, screen, &personClipsRight[frameNum]);
}
void Player::ShowParticles()
{
	for (int p=0; p<TOTAL_PARTICLES; p++)
	{
		if (particles[p]->IsDead())
		{
			delete particles[p];
			particles[p] = new Particle(box.x, box.y);
		}
		particles[p]->Show();
	}
}
int mStartSDLExample( int argc, char* args[] )
{
	bool quit = false;

	Timer myTimer;
	Player myPlayer;
	Tile *tiles[TOTAL_TILES];

	int frame=0;
	Timer fps;
	Timer updateFPS;
	Timer dt;

	if (!Init()) return 1;
	if (!LoadFiles(myPlayer)) return 1;
	if (!set_tiles(tiles)) return 1;

	myTimer.Start();
	fps.Start();
	updateFPS.Start();

	//Clip range for the top left
	clip[ 0 ].x = 0; clip[ 0 ].y = 0; clip[ 0 ].w = 100; clip[ 0 ].h = 100;
	//Clip range for the top right
	clip[ 1 ].x = 100; clip[ 1 ].y = 0; clip[ 1 ].w = 100; clip[ 1 ].h = 100;
	//Clip range for the bottom left
	clip[ 2 ].x = 0; clip[ 2 ].y = 100; clip[ 2 ].w = 100; clip[ 2 ].h = 100;
	//Clip range for the bottom right
	clip[ 3 ].x = 100; clip[ 3 ].y = 100; clip[ 3 ].w = 100; clip[ 3 ].h = 100;

	wall.x = 300;
	wall.y = 40;
	wall.w = 40;
	wall.h = 300;

	//Render the text
	message = TTF_RenderText_Solid(font, "The quick brown fox jumps over the lazy dog", textColor );
	upMessage = TTF_RenderText_Solid(font, "Up was pressed", textColor );
	downMessage = TTF_RenderText_Solid(font, "Down was pressed", textColor );
	leftMessage = TTF_RenderText_Solid(font, "Left was pressed", textColor );
	rightMessage = TTF_RenderText_Solid(font, "Right was pressed", textColor );
	if (message == NULL) return 1;

	set_clips();
	Button button(170, 420, 80, 60);

	dt.Start();
	while (!quit)
	{
		fps.Start();
		while( SDL_PollEvent( &event ) )
		{
			myPlayer.handle_input();
			if (event.type == SDL_QUIT)	quit = true;
			if (event.type == SDL_KEYDOWN)
			{
				switch (event.key.keysym.sym)
				{
					case SDLK_1:
						if (Mix_PlayChannel(-1, scratch, 0) == -1) return 1;
						break;
					case SDLK_2:
						if (Mix_PlayChannel(-1, low, 0) == -1) return 1;
						break;
					case SDLK_3:
						if (Mix_PlayChannel(-1, med, 0) == -1) return 1;
						break;
					case SDLK_4:
						if (Mix_PlayChannel(-1, high, 0) == -1) return 1;
						break;

					case SDLK_9:
						if (Mix_PlayingMusic() == 0)
						{
							if (Mix_PlayMusic(music, -1)) return 1;
						}
						else if (Mix_PausedMusic())
						{
							Mix_ResumeMusic();
						}
						else
						{
							Mix_PauseMusic();
						}
						break;
					case SDLK_0:
						Mix_HaltMusic();
						break;

					//timer
					case SDLK_s:
						if (myTimer.IsStarted()) myTimer.Stop();
						else myTimer.Start();
						break;
					case SDLK_p:
						if (myTimer.IsPaused()) myTimer.Unpause();
						else myTimer.Pause();
						break;

					case SDLK_ESCAPE: quit = true; break;
					default: ;
				}
			}
			button.handle_events();
		}

		myPlayer.move(dt.GetTicks(), tiles);
		dt.Start();
		myPlayer.SetCamera();
		std::stringstream time;
		time << "Timer: " << myTimer.GetTicks() / 1000.0f;
		if (updateFPS.GetTicks() > 1000)
		{
			std::stringstream caption;
			caption << "ZAMF2D - FPS: " << 1000.0f * frame / (updateFPS.GetTicks());
			SDL_WM_SetCaption(caption.str().c_str(), NULL);
			updateFPS.Start();
			//reset fps timer
			frame = 0;
		}
		message = TTF_RenderText_Solid(font, time.str().c_str(), textColor);

		SDL_FillRect( screen, &screen->clip_rect, SDL_MapRGB( screen->format, 0x00, 0x00, 0x00 ) );
		ApplySurface(0, 0, background, screen);

		for (int t=0; t < TOTAL_TILES; t++)
			tiles[t]->Show();

		//SDL_Rect newWall = {wall.x-camera.x, wall.y-camera.y, wall.w, wall.h};
		//wall rendering (such a hack...)
		//SDL_FillRect( screen, &newWall, SDL_MapRGB( screen->format, 0xFF, 0x00, 0x00 ) );
		//Apply the images to the screen

		//ApplySurface( 0, 0, clips, screen, &clip[ 0 ] );
		//ApplySurface( 540, 0, clips, screen, &clip[ 1 ] );
		//ApplySurface( 0, 380, clips, screen, &clip[ 2 ] );
		//ApplySurface( 540, 380, clips, screen, &clip[ 3 ] );


		ApplySurface( 200, 0, message, screen);
		myPlayer.show();
		button.show();


		if ( SDL_Flip( screen ) == -1 ) return 1;
		frame++;
	}

	CleanUp(myPlayer);

	return 0;
}
