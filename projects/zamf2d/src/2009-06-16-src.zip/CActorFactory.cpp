#include "CActorFactory.h"

#include "CFridge.h"
#include "CZombie.h"
#include "CPlayer.h"
#include "CNail.h"
#include "CLinearSpawner.h"
#include "CCatapult.h"
#include "CMothball.h"
#include "CConfig.h"

using namespace ZAMF;

CActorFactory::CActorFactory(void)
{

}

CActorFactory::~CActorFactory(void)
{
}

CActorCfg *CActorFactory::Load(const std::string type, const std::string &name)
{
	CActorCfg *def=NULL;
	TiXmlDocument *doc = NULL;
	std::string filename = ZAMF_CFG_GET_PATH("def") + "actor/" + type + "/" + name + ".xml";
	doc = new TiXmlDocument(filename.c_str());

	if (doc != NULL)
	{
		bool ok = doc->LoadFile();
		if (!ok)
		{
			const char *desc = doc->ErrorDesc();
			throw(desc);
		}
		TiXmlElement *el = doc->FirstChildElement("actor");

		std::string subType = el->Attribute("subtype");

		if (type == "enemy")
		{
			//if (subType == "zombie") 
			def = new CZombieCfg();
		}

		else if (type == "base")
		{
			if (subType == "player") def = new CPlayerCfg();
			else if (subType == "fridge") def = new CFridgeCfg();
		}

		else if (type == "projectile")
		{
			if (subType == "nail") def = new CNailCfg();
			else if (subType == "mothball") def = new CMothballCfg();
		}

		else if (type == "spawner")
		{
			if (subType == "zombie") def = new CLinearSpawnerCfg();
		}

		else if (type == "weapon")
		{
			if (subType == "catapult") def = new CCatapultCfg();
		}

		else if (type == "item")
		{
			def = new CItemCfg();
		}

		if (def == NULL)
			throw("Subtype not found");

		def->Load(el);

		delete doc;
		doc = NULL;
	} else {
		throw("Could not load xml file");
	}

	if (def != NULL)
	{
		const std::string key = type + "," + name;
		mActorCfgs[key] = def;
	}
	return def;
}

CActorCfg *CActorFactory::CreateOrLoadCfg(const std::string &type, const std::string &name)
{
	CActorCfg *def = NULL;
	const std::string key = type + "," + name;

	ActorsCfgMap::iterator it = mActorCfgs.find(key);
	if (it == mActorCfgs.end())
	{
		def = Load(type, name);
		if (def == NULL)
			throw("Failed loading actor");
	}
	else
	{
		def = it->second;
	}
	return def;
}

CActor *CActorFactory::Create(const std::string &type, const std::string &name, const CActorDef *def)
{
	CActorCfg *cfg = NULL;
	CActor *actor = NULL;

	cfg = CreateOrLoadCfg(type, name);
	if (cfg == NULL)
		return NULL;

	if (type == "enemy")
		actor = new CZombie(static_cast<CZombieCfg*>(cfg), static_cast<const CPositionDef*>(def));
	else if (type == "base" && name == "player")
		actor = new CPlayer(static_cast<CPlayerCfg*>(cfg), static_cast<const CPositionDef*>(def));
	else if (type == "weapon" && name == "catapult")
		actor = new CCatapult(static_cast<CCatapultCfg*>(cfg), static_cast<const CPositionDirectionDef*>(def));
	else if (type == "item")
		actor = new CItem(static_cast<CItemCfg*>(cfg), static_cast<const CPositionDef*>(def));

	if (type == "spawner" && name == "linear")
		actor = new CLinearSpawner(static_cast<CLinearSpawnerCfg*>(cfg), static_cast<const CPositionNameTypeDelayDef*>(def));

	if (type == "base" && name == "fridge")
		actor = new CFridge(static_cast<CFridgeCfg*>(cfg), static_cast<const CPositionSizeDef*>(def));
	else if (type == "projectile" && name == "nail")
		actor = new CNail(static_cast<CNailCfg*>(cfg), static_cast<const CPositionDirectionDef*>(def));
	else if (type == "projectile" && name == "mothball")
		actor = new CMothball(static_cast<CMothballCfg*>(cfg), static_cast<const CPositionDirectionDef*>(def));

	return actor;
}
