#include "CZombie.h"
#include "CScene.h"
#include "CPhysicsManager.h"
#include "CPlayer.h"
#include "CFridge.h"
#include "ActorDefs.h"

#include "tinyxml.h"
#include "utils.h"

#include <fstream>
#include <string>

using namespace ZAMF;
using namespace std;

bool CZombieCfg::Load(TiXmlElement *root)
{
	CActorCfg::Load(root);

	TiXmlElement *el=NULL;
	// block: behaviour
	TiXmlElement *behaviourRootNode = root->FirstChildElement("behaviour");

	//stats
	el = behaviourRootNode->FirstChildElement("stats");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("hp", &mMaxHP) );

	//movement
	el = behaviourRootNode->FirstChildElement("movement");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("xvel", &xVel) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("seekplayerdistance", &seekPlayerDistance) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("accelforce", &accelForce) );

	//physics
	el = behaviourRootNode->FirstChildElement("physics");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("density", &density) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("friction", &friction) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("restitution", &restitution) );

	//melee attack
	el = behaviourRootNode->FirstChildElement("melee");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("damage", &meleeDamage) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("range", &meleeRange) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("animationtime", &meleeAnimationTime) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("hittime", &meleeHitTime) );

	return true;
}

CZombie::CZombie(const CZombieCfg *cfg, const CPositionDef *def)
: CActor(cfg, def), mDirection(0), mState(ZOMBIE_WALKING)
{
	mFlags = ACTOR_ENEMY;

	mCfg = *cfg;

	mHP = mCfg.mMaxHP;

	//add to physics world
	b2BodyDef bodyDef;
	bodyDef.position.Set(def->x, def->y);
	bodyDef.fixedRotation = true;
	bodyDef.linearDamping = 0.0f;
	bodyDef.angularDamping = 0.0f;
	bodyDef.allowSleep = false;
	mBody = CPhysicsManager::GetSingleton().GetPhysicsWorld()->CreateBody(&bodyDef);

	float h = mSprite->GetHeight();
	float w = mSprite->GetWidth();
	float offset = 0.f;
	if (w < h) 
		offset = 0.5f*w;
	b2PolygonDef bodyShape;
	bodyShape.SetAsBox(0.5f*mSprite->GetWidth(), 0.5f*h - offset);
	bodyShape.density = cfg->density;
	bodyShape.friction = cfg->friction;
	bodyShape.restitution = cfg->restitution;
	bodyShape.filter.categoryBits = ACTOR_ENEMY;
	bodyShape.filter.maskBits = ACTOR_PLAYER | ACTOR_FRIDGE | ACTOR_PROJECTILE | ACTOR_STATIONARY;
	bodyShape.userData = this;
	mBody->CreateShape(&bodyShape);

	if (w < h)
	{
		b2CircleDef headShape;
		headShape.radius = 0.5f*mSprite->GetWidth();
		headShape.density = cfg->density;
		headShape.friction = cfg->friction;
		headShape.restitution = cfg->restitution;
		headShape.filter.categoryBits = ACTOR_ENEMY;
		headShape.filter.maskBits = ACTOR_PLAYER | ACTOR_FRIDGE | ACTOR_PROJECTILE | ACTOR_STATIONARY;
		headShape.userData = this;
		headShape.localPosition = b2Vec2(0, 0.5f*h - 0.5f*w);
		mBody->CreateShape(&headShape);
		headShape.localPosition = b2Vec2(0, -0.5f*h + 0.5f*w);
		mBody->CreateShape(&headShape);
	}
	
	mBody->SetMassFromShapes();
}

CZombie::~CZombie(void)
{
	CPhysicsManager::GetSingleton().GetPhysicsWorld()->DestroyBody(mBody);
	mBody = NULL;
	delete mSprite;
}

bool CZombie::Update(float dt)
{
	//well all we have to make sure about now is the zombie is moving...let's try it
	b2Vec2 linVel = mBody->GetLinearVelocity();

	CPlayer *p = CScene::GetSingleton().GetPlayer();
	float targetVelocity=mDirection;
	float dp = (p->GetPosition() - mBody->GetPosition()).LengthSquared();

	if (mState == ZOMBIE_WALKING)
	{
		
		if (dp < mCfg.meleeRange)
		{
			mState = ZOMBIE_ATTACKING;
			mSprite->SetState(ZOMBIE_ATTACKING);
			mSprite->ResetFrame();
			mAnimationCountdown = mCfg.meleeAnimationTime;
			mHitCountdown = mCfg.meleeHitTime;
		}
		else if (dp < mCfg.seekPlayerDistance)
		{
			//seek the player
			dp = p->GetPosition().x - mBody->GetPosition().x;
			targetVelocity = (dp > 0.f ? 1.f : -1.f);
		}
		else
		{
			//seek the fridge
			b2Body *b = CPhysicsManager::GetSingleton().GetPhysicsWorld()->GetBodyList();
			while (b != NULL)
			{
				b2Shape *s= b->GetShapeList();
				while (s != NULL)
				{
					if (s->GetFilterData().categoryBits & ACTOR_FRIDGE)
					{
						float ds = b->GetPosition().x - mBody->GetPosition().x;
						targetVelocity = ds > 0.f ? 1.f : -1.f;
					}
					s = s->GetNext();
				}
				b = b->GetNext();
			}
		}
		targetVelocity *= mCfg.xVel;
		mDirection = targetVelocity >= 0 ? 1.f : -1.f;
	}
	else if (mState == ZOMBIE_ATTACKING)
	{
		mHitCountdown -= dt;
		mAnimationCountdown -= dt;
		if (dp > mCfg.meleeRange) 
		{
			mState = ZOMBIE_WALKING;
			mSprite->SetState(ZOMBIE_WALKING);
			mSprite->ResetFrame();
		}
		if (mHitCountdown <= 0)
		{
			//ouch!
			p->Hit(mCfg.meleeDamage);
			mHitCountdown = mAnimationCountdown+1;
		}
		if (mAnimationCountdown <= 0)
		{
			mAnimationCountdown = mCfg.meleeAnimationTime;
			mHitCountdown = mCfg.meleeHitTime;
		}
		targetVelocity = 0;
	}

	//apply force to the zombie
	float d = targetVelocity - linVel.x;
	d *= mCfg.accelForce*mBody->GetMass()*dt;
	mBody->ApplyForce(b2Vec2(d, 0), mBody->GetPosition());
	mSprite->AdvanceFrame(dt);

	return true;
}
void CZombie::Draw()
{
	glPushMatrix();

	b2Vec2 pos = mBody->GetPosition();
	float angle = mBody->GetAngle();

	glTranslatef(pos.x, pos.y, 0);
	glRotatef(angle*180/3.14159f, 0,0,1);
	glScalef((float)mDirection, 1, 1);
	mSprite->Draw();
	glPopMatrix();
}

void CZombie::Hit(float dmg)
{
	mHP -= dmg;
	if (mHP <= 0)
		mDying = true;
}

//contact points
void CZombie::Collide(CActor *other, const CPhysicsManager::ContactPoint &cp, int pos)
{
	if (other != NULL && other->GetFlags() & ACTOR_FRIDGE)
	{
		CFridge *fridge = static_cast<CFridge*>(other);
		fridge->Hit();
	}
}
