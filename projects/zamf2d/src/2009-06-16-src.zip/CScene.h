#pragma once
#include <list>
#include <string>

#include "Box2D.h"
#include "common.h"

#include "CSingleton.h"
#include "CActor.h"
#include "CPlayer.h"
#include "CPhysicsDebugDraw.h"

namespace ZAMF
{

	class CScene : public CSingleton<CScene>
	{
	public:
		CScene(void);
		~CScene(void);

		void Create(std::string scene);
		void Rapture();
		void AddStructure(float x, float y, float w, float h);
		
		//actor stuff
		std::list<CActor *> GetActors(){return mActors;}
		void RegisterActor(CActor *actor);
		void UnregisterActor(CActor *actor);

		CPlayer *GetPlayer(){return mPlayer;}
		
		//xform stuff
		b2Vec2 PixelToWorld(int x, int y);
		void WorldToPixel(const b2Vec2 &pos, int *x, int *y);

		//event stuff
		virtual void HandleEvent(const SDL_Event &e);
		virtual bool Update(float dt);
		virtual void Draw();

		int GetScore(){return mScore;}
		void AddScore(int score){mScore += score;}

		Box GetCamera(){return mCamera;}
	protected:
		void SetupCamera();

		void SnapCameraToPlayer();
		void SetProjToCamera();

		void CentreCameraOnPlayer();

		Box mBox;
		Box mCamera;
		CPlayer *mPlayer;
		bool mEnableDebugDrawing;
		bool mEnableActorDrawing;

		std::list<CActor *> mActors;

		std::list<b2Body*> mStaticBodies;
		std::list<Box> mStructures;

		CSprite *mBackground;

		int mScore;

	};
}