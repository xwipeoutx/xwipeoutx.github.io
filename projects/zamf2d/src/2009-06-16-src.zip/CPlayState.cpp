#include "CPlayState.h"
#include "CMenuState.h"
#include "CDeadState.h"
#include "CGameManager.h"

#include "CActorFactory.h"
#include "CSpriteFactory.h"
#include "CScene.h"
#include "CHud.h"
#include "CEGUI.h"
#include "CConfig.h"

using namespace ZAMF;
using namespace CEGUI;
CPlayState::CPlayState(void)
: mScene(NULL)
{
}

CPlayState::~CPlayState(void)
{
}


void CPlayState::Enter()
{
	//load the inventory image set
	ImagesetManager::getSingleton().createImageset("inventory.imageset");

	//load the play layout
	Window* window = WindowManager::getSingleton().loadWindowLayout( "playlayout.xml" );
	System::getSingleton().setGUISheet( window );

	new CActorFactory();
	mScene = new CScene();
	mScene->Create("test");

	std::string filename = ZAMF_CFG_GET_PATH("sound") + "music/bg.ogg";
	const char *f = filename.c_str();
	mPlayMusic = Mix_LoadMUS(f);
	if (mPlayMusic == NULL)
		throw Mix_GetError();
	Mix_PlayMusic(mPlayMusic, -1);

}

void CPlayState::Exit()
{
	mScene->Rapture();
	delete mScene;
	mScene = NULL;
	delete CActorFactory::GetSingletonPtr();

	//destroy CEGUI stuff
	WindowManager::getSingleton().destroyWindow("Play");
	System::getSingleton().setGUISheet( NULL );
	ImagesetManager::getSingleton().destroyImageset("Inventory");

	Mix_FreeMusic(mPlayMusic);
	mPlayMusic = NULL;
}

void CPlayState::Pause()
{
	Mix_PauseMusic();
}

void CPlayState::Resume()
{
	Mix_ResumeMusic();
}

void CPlayState::HandleEvent(const SDL_Event &e)
{
	//escape - back to menu screen
	if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_ESCAPE)
	{
		CGameManager::GetSingleton().ChangeState(new CMenuState());
	}
	//dead - to dead state
	else if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_k)
	{
		CGameManager::GetSingleton().PushState(new CDeadState());
	}
	else
	{
		mScene->HandleEvent(e);
	}
}
void CPlayState::Draw()
{
	mScene->Draw();
}
bool CPlayState::Update(float dt)
{
	return mScene->Update(dt);
}
