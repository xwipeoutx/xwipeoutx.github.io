#include "CMothball.h"
#include "CPhysicsManager.h"

#include "CScene.h"
#include "CZombie.h"

#include "ActorDefs.h"

#include <fstream>

#include "tinyxml.h"
#include "utils.h"

using namespace ZAMF;
using namespace std;


bool CMothballCfg::Load(TiXmlElement *root)
{
	CActorCfg::Load(root);

	TiXmlElement *el=NULL;

	// block: sprite
	TiXmlElement *spriteRootNode = root->FirstChildElement("sprite");
	CheckXMLSuccessAttribute( spriteRootNode->QueryFloatAttribute("width", &w) );
	CheckXMLSuccessAttribute( spriteRootNode->QueryFloatAttribute("height", &h) );

	// block: behaviour
	TiXmlElement *behaviourRootNode = root->FirstChildElement("behaviour");

	//stats
	el = behaviourRootNode->FirstChildElement("stats");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("basedmg", &baseDamage) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("dmgmult", &damageMultiplier) );

	//movement
	el = behaviourRootNode->FirstChildElement("movement");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("initialvel", &initialVel) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("initialdisplacement", &initialDisplacement) );

	//physics
	el = behaviourRootNode->FirstChildElement("physics");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("density", &density) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("friction", &friction) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("restitution", &restitution) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("angulardamping", &angularDamping) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("lineardamping", &linearDamping) );
	return true;
}


CMothball::CMothball(const CMothballCfg *cfg, const CPositionDirectionDef *def)
: CActor(cfg, def), mDestroyed(false)
{
	mFlags = ACTOR_PROJECTILE;

	mCfg = *cfg;

	b2Vec2 pos(def->x, def->y);
	b2Vec2 initialDir(def->xdir, def->ydir);

	initialDir.Normalize();

	//add to physics world
	b2BodyDef bodyDef;
	bodyDef.position = pos + mCfg.initialDisplacement*initialDir;
	bodyDef.fixedRotation = false;
	bodyDef.linearDamping = mCfg.linearDamping;
		bodyDef.angularDamping = mCfg.angularDamping;
	bodyDef.isBullet = false;
	bodyDef.angle = atan(initialDir.y/initialDir.x);
	mBody = CPhysicsManager::GetSingleton().GetPhysicsWorld()->CreateBody(&bodyDef);

	b2CircleDef shapeDef;
	shapeDef.radius = (0.5f * mSprite->GetWidth());
	shapeDef.density = mCfg.density;
	shapeDef.friction = mCfg.friction;
	shapeDef.restitution = mCfg.restitution;
	shapeDef.filter.categoryBits = ACTOR_PROJECTILE;
	shapeDef.filter.maskBits = ACTOR_ENEMY | ACTOR_PROJECTILE | ACTOR_STATIONARY;
	shapeDef.userData = this;
	mBody->CreateShape(&shapeDef);
	mBody->SetMassFromShapes();

	mBody->SetLinearVelocity(mCfg.initialVel* initialDir);
}

CMothball::~CMothball(void)
{
	CPhysicsManager::GetSingleton().GetPhysicsWorld()->DestroyBody(mBody);
	mBody = NULL;
	delete mSprite;
}

void CMothball::Draw()
{
	glColor3f(1,1,1);
	glPushMatrix();
	b2Vec2 pos = mBody->GetPosition();
	//float angle = mBody->GetAngle();
	glTranslatef(pos.x, pos.y, 0);
	//glRotatef(angle*180/b2_pi, 0,0,1);
	mSprite->Draw();
	glPopMatrix();
}

bool CMothball::Update(float dt)
{
	if (mBody->GetLinearVelocity().LengthSquared() < 0.001)
	{
		if (!mDestroyed)
		{
			mCountdown -= dt;
			if (mCountdown < 0)
				mDying = true;
		}
		if (mDestroyed)
		{
			mCountdown = 0.5;
			mDestroyed = true;
		}
	}
	return true;
}

void CMothball::Collide(ZAMF::CActor *other, const CPhysicsManager::ContactPoint &cp, int pos)
{
	if (other != NULL && !(other->GetFlags()&ACTOR_PROJECTILE))
	{
		if (other->GetFlags() & ACTOR_ENEMY)
		{
			mDying = true;

			CZombie *zomb = static_cast<CZombie*>(other);
			if (zomb)
			{
				b2Vec2 vel = mBody->GetLinearVelocity();
				if (vel.LengthSquared() < 0.001)
					zomb->Hit(mCfg.baseDamage);
				else
					zomb->Hit(mCfg.baseDamage + mCfg.damageMultiplier*vel.Length());
			}
		}
	}
}
