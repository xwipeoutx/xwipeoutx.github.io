#include "CVictoryState.h"
#include "CScene.h"
#include "CMenuState.h"
#include "CHud.h"
#include "CEGUI.h"
#include "utils.h"

using namespace ZAMF;
using namespace CEGUI;

CVictoryState::CVictoryState(void)
{
}

CVictoryState::~CVictoryState(void)
{
}

void CVictoryState::Enter()
{
	//load the play layout
	Window* window = WindowManager::getSingleton().loadWindowLayout( "victorylayout.xml" );
	System::getSingleton().setGUISheet( window );
	
	//score
	std::string str = "Your score was: " + ZAMF::ToString( CScene::GetSingleton().GetScore() );
	WindowManager::getSingleton().getWindow("Victory/Score")->setText(str);
}

void CVictoryState::Exit()
{
	//destroy CEGUI stuff
	WindowManager::getSingleton().destroyWindow("Victory");
	System::getSingleton().setGUISheet( NULL );
}

void CVictoryState::Pause()
{
}

void CVictoryState::Resume()
{
}

void CVictoryState::HandleEvent(const SDL_Event &e)
{

	//escape - back to menu screen
	if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_ESCAPE)
	{
		CGameManager::GetSingleton().ChangeState(new CMenuState());
	}
}

void CVictoryState::Draw()
{
	CScene::GetSingleton().Draw();
}
