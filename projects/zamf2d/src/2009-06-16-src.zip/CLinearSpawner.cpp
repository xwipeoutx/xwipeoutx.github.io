#include "CLinearSpawner.h"

#include "CActorFactory.h"
#include "CPhysicsManager.h"
#include "ActorDefs.h"

using namespace ZAMF;

CLinearSpawnerCfg::CLinearSpawnerCfg()
{
}

bool CLinearSpawnerCfg::Load(TiXmlElement *root)
{
	TiXmlElement *el=NULL;
	el = root->FirstChildElement("name");
	mName = std::string(el->GetText());

	mLoaded = true;
	return true;
}

CLinearSpawner::CLinearSpawner(const CLinearSpawnerCfg *cfg, const CPositionNameTypeDelayDef *def)
: CActor(cfg,def)
{
	mX = def->x; mY = def->y;
	mDelay = def->delay;
	mElapsed = mDelay*(float)(rand())/RAND_MAX;

	mFlags = ACTOR_FRIDGE;
	mSprite = NULL;

	mActorType = def->type;
	mActorName = def->name;
}

CLinearSpawner::~CLinearSpawner(void)
{

}

bool CLinearSpawner::Update(float dt)
{
	mElapsed += dt;
	if (mElapsed > mDelay)
	{
		//only spawn if the world at that point is empty
		b2AABB a;
		a.lowerBound = b2Vec2(mX - 0.1f, mY - 0.1f);
		a.upperBound = b2Vec2(mX + 0.1f, mY + 0.1f);
		b2Shape**shapes = new b2Shape*[1];
		int numShapes = CPhysicsManager::GetSingleton().GetPhysicsWorld()->Query(a, shapes, 1);
		
		if (numShapes == 0)
		{
			mElapsed = 0;
			CPositionDef positionDef;
			positionDef.x = mX;
			positionDef.y = mY;
			CActorFactory::GetSingleton().Create(mActorType, mActorName, &positionDef);
		}
		else
		{
			mElapsed -= 1.f;
		}
	}

	return true;
}