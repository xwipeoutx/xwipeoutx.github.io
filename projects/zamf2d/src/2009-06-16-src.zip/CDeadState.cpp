#include "CDeadState.h"
#include "CScene.h"
#include "CMenuState.h"
#include "CHud.h"
#include "CEGUI.h"
#include "utils.h"

using namespace ZAMF;
using namespace CEGUI;

CDeadState::CDeadState(void)
{
}

CDeadState::~CDeadState(void)
{
}

void CDeadState::Enter()
{
	//load the play layout
	Window* window = WindowManager::getSingleton().loadWindowLayout( "deadlayout.xml" );
	System::getSingleton().setGUISheet( window );
	
	//score
	std::string str = "Your score was: " + ZAMF::ToString( CScene::GetSingleton().GetScore() );
	WindowManager::getSingleton().getWindow("Dead/Score")->setText(str);
}

void CDeadState::Exit()
{
	//destroy CEGUI stuff
	WindowManager::getSingleton().destroyWindow("Dead");
	System::getSingleton().setGUISheet( NULL );
}

void CDeadState::Pause()
{
}

void CDeadState::Resume()
{
}

void CDeadState::HandleEvent(const SDL_Event &e)
{

	//escape - back to menu screen
	if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_ESCAPE)
	{
		CGameManager::GetSingleton().ChangeState(new CMenuState());
	}
}

void CDeadState::Draw()
{
	CScene::GetSingleton().Draw();
}
