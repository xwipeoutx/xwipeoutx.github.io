#pragma once

#include "CActor.h"

namespace ZAMF
{

	#define PLAYER_FACING_LEFT 1

	class CCatapultCfg : public CActorCfg
	{
	public:
		bool Load(TiXmlElement *root);

		float mRecoveryTime, mAnimationTime, mFiringTime;
	};

	class CPositionDirectionDef;

	class CCatapult : public CActor
	{
	public:
		CCatapult(const CCatapultCfg *cfg, const CPositionDirectionDef *def);
		~CCatapult(void);

		void HandleEvent(const SDL_Event &e);
		void Draw();
		bool Update(float dt);

	private:
		CCatapultCfg mCfg;
		enum {
			CATAPULT_IDLE=0,
			CATAPULT_FIRING=1,
			CATAPULT_FINISHING=2,
			CATAPULT_RECOVERING=3,
			CATAPULT_DYING,
			CATAPULT_DEAD
		} mState;

		float mX, mY;
		int mDirection;

		float mRecoveryCountdown;
		float mAnimationCountdown;
		float mFiringCountdown;

	};

}