#include "CGUIManager.h"
#include "CConfig.h"

using namespace ZAMF;
CGUIManager::CGUIManager(void)
{
	mRenderer = NULL;
	mSystem = NULL;
}

CGUIManager::~CGUIManager(void)
{
	if (mRenderer) mRenderer = NULL;
	if (mSystem) mSystem = NULL;
}

void CGUIManager::Init(int width, int height)
{
	try 
	{

		mRenderer = new CEGUI::OpenGLRenderer(0, width, height);
		mSystem = new CEGUI::System(mRenderer);
		SDL_ShowCursor(SDL_DISABLE);
		SDL_EnableUNICODE(1);
		//SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY, SDL_DEFAULT_REPEAT_INTERVAL);

		CEGUI::DefaultResourceProvider *rp = static_cast<CEGUI::DefaultResourceProvider*>
			(mSystem->getResourceProvider());

		std::string guiPath = ZAMF_CFG_GET_PATH("gui");
		rp->setResourceGroupDirectory("schemes", guiPath + "schemes/");
		rp->setResourceGroupDirectory("imagesets", guiPath + "imagesets/");
		rp->setResourceGroupDirectory("fonts", guiPath + "fonts/");
		rp->setResourceGroupDirectory("layouts", guiPath + "layouts/");
		rp->setResourceGroupDirectory("looknfeels", guiPath + "looknfeels/");

		CEGUI::Scheme::setDefaultResourceGroup("schemes");
		CEGUI::Imageset::setDefaultResourceGroup("imagesets");
		CEGUI::Font::setDefaultResourceGroup("fonts");
		CEGUI::WindowManager::setDefaultResourceGroup("layouts");
		CEGUI::WidgetLookManager::setDefaultResourceGroup("looknfeels");

		CEGUI::SchemeManager::getSingleton().loadScheme( "VanillaSkin.scheme" );
		if(! CEGUI::FontManager::getSingleton().isFontPresent( "Chiller-18" ) )
			CEGUI::FontManager::getSingleton().createFont( "Chiller-18.font" );
		if(! CEGUI::FontManager::getSingleton().isFontPresent( "Chiller-72" ) )
			CEGUI::FontManager::getSingleton().createFont( "Chiller-72.font" );

		mSystem->setDefaultFont( "Chiller-18" );
		mSystem->setDefaultMouseCursor( "Vanilla-Images", "MouseArrow" );
		mSystem->setDefaultTooltip( "Vanilla/Tooltip" );


	} 
	catch (CEGUI::Exception &e)
	{
		throw e.getMessage().c_str();
	}
}

void CGUIManager::Destroy()
{
	delete mSystem;
	mSystem = NULL;
	delete mRenderer;
	mRenderer = NULL;
}

void CGUIManager::HandleEvent(SDL_Event &e)
{
	switch (e.type)
	{
	case SDL_MOUSEMOTION:
		mSystem->injectMousePosition(
			static_cast<float>(e.motion.x),
			static_cast<float>(e.motion.y) );
		break;
	case SDL_MOUSEBUTTONDOWN:
		HandleMouseButtonDown(e.button.button);
		break;
	case SDL_MOUSEBUTTONUP:
		HandleMouseButtonUp(e.button.button);
		break;
	default:
		break;
	}
}

void CGUIManager::Update(float dt)
{
	mSystem->injectTimePulse(dt);
}

void CGUIManager::Draw()
{
	mSystem->renderGUI();
}

void CGUIManager::HandleMouseButtonDown(Uint8 &button)
{
	switch (button)
	{
	case SDL_BUTTON_LEFT:
		mSystem->injectMouseButtonDown(CEGUI::LeftButton);
		break;
	case SDL_BUTTON_MIDDLE:
		mSystem->injectMouseButtonDown(CEGUI::MiddleButton);
		break;
	case SDL_BUTTON_RIGHT:
		mSystem->injectMouseButtonDown(CEGUI::RightButton);
		break;
		
	case SDL_BUTTON_WHEELDOWN:
		mSystem->injectMouseWheelChange( -1 );
		break;
	case SDL_BUTTON_WHEELUP:
		mSystem->injectMouseWheelChange( +1 );
		break;
	}
}

void CGUIManager::HandleMouseButtonUp(Uint8 &button)
{
	switch (button)
	{
	case SDL_BUTTON_LEFT:
		mSystem->injectMouseButtonUp(CEGUI::LeftButton);
		break;
	case SDL_BUTTON_MIDDLE:
		mSystem->injectMouseButtonUp(CEGUI::MiddleButton);
		break;
	case SDL_BUTTON_RIGHT:
		mSystem->injectMouseButtonUp(CEGUI::RightButton);
		break;
	}
}