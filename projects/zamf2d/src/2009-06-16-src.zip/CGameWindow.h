#pragma once

#include "CSingleton.h"
#include "CTimer.h"
#include "common.h" 

namespace ZAMF
{
	class CGameWindow : public CSingleton<CGameWindow>
	{
	public:
		CGameWindow(void);
		~CGameWindow(void);
		
		void HandleEvent(const SDL_Event &event);
		bool Update(float dt){return true;}
		void StartFrame();
		void EndFrame();


		//Accessors / Mutators
		bool IsWindowed(){return mWindowed;}
		void ToggleFullScreen();
		const SDL_Surface *GetScreen(){return mScreen;}

		int GetWidth(){return mWidth;}
		int GetHeight(){return mHeight;}

		float getFPS(){return mFPS;}
		
		static const int SCREEN_WIDTH = 640;
		static const int SCREEN_HEIGHT = 480;
		static const int SCREEN_BPP = 32;

	private:
		bool mWindowed;
		bool mWindowOK;
		SDL_Surface *mScreen;

		int mWidth;
		int mHeight;

		CTimer mFPSTimer;
		int mFrame;
		float mFPS;

	};
};