#include "CPlayer.h"
#include "CScene.h"
#include "CNail.h"
#include "CActorFactory.h"
#include "CPhysicsManager.h"
#include "CGameManager.h"
#include "CDeadState.h"
#include "CConfig.h"

#include <string>
#include <fstream>
#include "CHud.h"

#include "utils.h"
using namespace ZAMF;
using namespace std;

bool CPlayerCfg::Load(TiXmlElement *root)
{
	CActorCfg::Load(root);

	TiXmlElement *el=NULL;

	//block: stats
	el = root->FirstChildElement("stats");
	CheckXMLSuccessAttribute( el->QueryIntAttribute("bagcapacity", &bagCapacity ) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("maxhp", &maxHP ) );
	// block: behaviour
	TiXmlElement *behaviourRootNode = root->FirstChildElement("behaviour");

	//movement
	el = behaviourRootNode->FirstChildElement("movement");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("maxvel", &maxVel) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("accelforce", &accelForce) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("jumpforce", &jumpForce) );

	//physics
	el = behaviourRootNode->FirstChildElement("physics");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("density", &density) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("friction", &friction) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("restitution", &restitution) );

	return true;
}

CPlayer::CPlayer(const CPlayerCfg *cfg, const CPositionDef *def)
: CActor(cfg, def)
{
	mFlags = ACTOR_PLAYER;
	mVel = 0;
	mOnGround = false;
	
	mCfg = *cfg;

	mHP = mCfg.maxHP;

	//add to physics world
	b2BodyDef bodyDef;
	bodyDef.position.Set(def->x, def->y);
	bodyDef.fixedRotation = true;
	bodyDef.linearDamping = 0.0f;
	bodyDef.angularDamping = 0.0f;
	bodyDef.allowSleep = false;
	mBody = CPhysicsManager::GetSingleton().GetPhysicsWorld()->CreateBody(&bodyDef);

	float h = mSprite->GetHeight();
	float w = mSprite->GetWidth();
	float offset = 0.f;
	if (w < h)
		offset = 0.5f*w;
	b2PolygonDef bodyShape;
	bodyShape.SetAsBox(0.5f*w, 0.5f*h - offset);
	bodyShape.density = mCfg.density;
	bodyShape.friction = mCfg.friction;
	bodyShape.restitution = mCfg.restitution;
	bodyShape.filter.categoryBits = ACTOR_PLAYER;
	bodyShape.filter.maskBits = ACTOR_ENEMY | ACTOR_STATIONARY | ACTOR_ITEM;
	bodyShape.userData = this;
	mBody->CreateShape(&bodyShape);

	if (w < h)
	{
		b2CircleDef headShape;
		headShape.radius = 0.5f*mSprite->GetWidth();
		headShape.density = mCfg.density;
		headShape.friction = mCfg.friction;
		headShape.restitution = mCfg.restitution;
		headShape.filter.categoryBits = ACTOR_PLAYER;
		headShape.filter.maskBits = ACTOR_FRIDGE | ACTOR_ENEMY | ACTOR_STATIONARY;
		headShape.userData = this;
		headShape.localPosition = b2Vec2(0, 0.5f*h - 0.5f*w);
		mBody->CreateShape(&headShape);
		headShape.localPosition = b2Vec2(0, -0.5f*h + 0.5f*w);
		mBody->CreateShape(&headShape);
	}

	mBody->SetMassFromShapes();

	std::string filename = ZAMF_CFG_GET_PATH("sound") + "player/oof1.wav";
	const char *f = filename.c_str();
	mOofSound = Mix_LoadWAV(f);
	if (mOofSound == NULL)
		throw Mix_GetError();

	mBag = std::vector<CItem*>(mCfg.bagCapacity);
	CHud::GetSingleton().UpdateHP(mHP, mCfg.maxHP);
}

CPlayer::~CPlayer(void)
{
}
b2Vec2 CPlayer::GetPosition() const
{
	return mBody->GetPosition();
}

void CPlayer::HandleEvent(const SDL_Event &e)
{
	if (e.type == SDL_KEYDOWN)
	{
		b2Vec2 pos = mBody->GetPosition();
		switch (e.key.keysym.sym)
		{
		case SDLK_RIGHT:
		case SDLK_d:
			mVel += mCfg.maxVel;
			break;
		case SDLK_LEFT:
		case SDLK_a:
			mVel -= mCfg.maxVel;
			break;
		case SDLK_UP:
		case SDLK_w:
		case SDLK_SPACE:
			Jump();
			break;
		case SDLK_e:
			FireNail();
			break;
		case SDLK_c:
			if (mOnGround)
			{
				CPositionDirectionDef catapultDef;
				catapultDef.x = pos.x;
				catapultDef.y = pos.y;
				catapultDef.xdir = mSprite->GetState() == PLAYER_FACING_RIGHT ? 1.f : -1.f;
				CActorFactory::GetSingleton().Create("weapon", "catapult", &catapultDef);
			}
			break;
		default:
			break;
		}
	}
	else if (e.type == SDL_KEYUP)
	{
		switch (e.key.keysym.sym)
		{
		case SDLK_RIGHT:
		case SDLK_d:
			mVel -= mCfg.maxVel;
			break;
		case SDLK_LEFT:
		case SDLK_a:
			mVel += mCfg.maxVel;
			break;
		default:
			break;
		}
	}
	else if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == 1)
	{
		FireNail();
	}
}

bool CPlayer::Update(float dt)
{
	b2Vec2 linVel = mBody->GetLinearVelocity();
	//linVel.x = mVel;

	//accelerate player towards velocity
	float d = mVel - linVel.x;
	d *= mCfg.accelForce*mBody->GetMass()*dt;
	mBody->ApplyForce(b2Vec2(d, 0), mBody->GetPosition());

	mSprite->AdvanceFrame(abs(linVel.x) / mCfg.maxVel * dt);
	float v = mBody->GetLinearVelocity().x;
	if (v > 0) mSprite->SetState(PLAYER_FACING_RIGHT);
	else if (v < 0) mSprite->SetState(PLAYER_FACING_LEFT);

	return true;
}

void CPlayer::Draw()
{
	glPushMatrix();
	b2Vec2 pos = mBody->GetPosition();
	float angle = mBody->GetAngle();

	glTranslatef(pos.x, pos.y, 0);
	glRotatef(angle*180/3.14159f, 0,0,1);
	mSprite->Draw();
	glPopMatrix();
}

void CPlayer::FireNail()
{
	int x, y;
	SDL_GetMouseState(&x, &y);
	b2Vec2 playerPos = mBody->GetPosition();
	b2Vec2 dir = CScene::GetSingleton().PixelToWorld(x, y) - playerPos;

	CPositionDirectionDef nailDef;
	nailDef.x = playerPos.x;
	nailDef.y = playerPos.y;
	nailDef.xdir = dir.x;
	nailDef.ydir = dir.y;

	CActorFactory::GetSingleton().Create("projectile", "nail", &nailDef);
}

void CPlayer::Jump()
{
	if (mOnGround)
	{
		mBody->ApplyImpulse(b2Vec2(0,mCfg.jumpForce), b2Vec2_zero);
		mOnGround = false;
	}
}

void CPlayer::Collide(CActor *other, const CPhysicsManager::ContactPoint &cp, int pos)
{

	if (other==NULL) 
	{
		if (cp.normal.y > 0)
			mOnGround = true;
	}
	else if (other->GetFlags() & ACTOR_ITEM)
	{
		CItem *item = static_cast<CItem*>(other);
		if (item->GetState() == CItem::ITEM_IN_WORLD)
		{
			bool ok = this->AddItemToBag(item);
			if (ok)	item->PickUp();
			CHud::GetSingleton().UpdateInventory();
		}
	}
	else if (other->GetFlags() & ACTOR_FRIDGE)
	{
		//put the items in the fridge
		int pos;
		while ((pos = GetFirstOccupiedItemPosition()) != mCfg.bagCapacity)
		{
			CItem *item = GetItemFromBag(pos);
			bool ok = this->RemoveItemFromBag(pos);
			if (ok)
			{
				item->PutInFridge();
				CScene::GetSingleton().AddScore(item->GetPoints());
				CHud::GetSingleton().UpdateScore();
				CHud::GetSingleton().UpdateInventory();
			}
		}
	}
}

int CPlayer::GetFirstFreeBagPosition(int start) const
{
	for (int i=start; i<mCfg.bagCapacity; i++)
	{
		if (mBag[i] == NULL) return i;
	}
	return mCfg.bagCapacity;
}

bool CPlayer::AddItemToBag(CItem *item)
{
	int pos = GetFirstFreeBagPosition();

	if (pos == mCfg.bagCapacity)
		return false;

	mBag[pos] = item;
	return true;

}

bool CPlayer::RemoveItemFromBag(int pos)
{
	if (pos < 0 || pos >= mCfg.bagCapacity) return false;
	mBag[pos] = NULL;
	return true;
}

CItem *CPlayer::GetItemFromBag(int position) const
{
	return mBag[position];
}

int CPlayer::GetFirstOccupiedItemPosition(int start) const
{
	for (int i=start; i<mCfg.bagCapacity; i++)
	{
		if (mBag[i] != NULL) return i;
	}
	return mCfg.bagCapacity;
}


void CPlayer::Hit(float dmg)
{
	if (mHP > 0)
	{
		mHP -= dmg;
		if (Mix_PlayChannel(-1, mOofSound, 0) == -1)
		{
			//on failure, do nothing - "Best Effort" basis
		}
		if (mHP <= 0)
		{
			CGameManager::GetSingleton().PushState(new CDeadState());
			CHud::GetSingleton().UpdateHP(0, mCfg.maxHP);
		}
		else
		{
			CHud::GetSingleton().UpdateHP(mHP, mCfg.maxHP);
		}
	}
	else
	{
			CHud::GetSingleton().UpdateHP(0, mCfg.maxHP);
	}
}