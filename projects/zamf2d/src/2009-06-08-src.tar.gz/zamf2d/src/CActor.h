#pragma once

#include "CSprite.h"
#include "Box2D.h"

#include "common.h"
#include "structures.h"
#include "tinyxml.h"

namespace ZAMF
{
	class CActorDef
	{
	public:
		CActorDef();
		virtual bool Load(TiXmlElement *root);

		bool mLoaded;
		std::string mType;
		std::string mSubType;
		std::string mName;
	};

	class CActor
	{
	public:
		enum ActorFlags {
			ACTOR_NONE = 0,
			ACTOR_ALL = ~0,
			ACTOR_PLAYER = 1 << 1,
			ACTOR_ENEMY = 1 << 2,
			ACTOR_STATIONARY = 1 << 3,
			ACTOR_TRAP = 1 << 4,
			ACTOR_PROJECTILE = 1 << 5,
			ACTOR_FRIDGE = 1 << 6,
			ACTOR_ITEM = 1 << 7
		};

		CActor(CActorDef *def);
		virtual ~CActor(void);

		virtual void HandleEvent(const SDL_Event &e){}
		virtual bool Update(float dt){return true;}
		virtual void Draw(){}

		virtual void Collide(CActor *other){}

		inline bool GetDying(){return mDying;}
		inline void SetDying(bool dying){mDying=dying;}

		inline ActorFlags GetFlags() const {return mFlags;}
		inline void SetFlags(ActorFlags flags){mFlags = flags;}
		inline bool IsFlagged(ActorFlags flags) const {return (flags & mFlags) > 0;}

		void CheckSuccessAttribute(int success);
	protected:
		ActorFlags mFlags;
		bool mDying;

		CSprite *mSprite;
		b2Body *mBody;

	};
};
