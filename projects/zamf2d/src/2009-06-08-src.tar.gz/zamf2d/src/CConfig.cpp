#include "CConfig.h"
#include "tinyxml.h"

using namespace ZAMF;

CConfig::CConfig(void)
{
}

CConfig::~CConfig(void)
{
}

bool CConfig::Load(std::string filename)
{
	TiXmlDocument doc(filename.c_str());
	bool ok = doc.LoadFile();
	if (!ok)
	{
		const char *desc = doc.ErrorDesc();
		throw(desc);
	}

	float x=0,y=0,mode=0;
	std::string type, dir;
	TiXmlElement *el=NULL;
	TiXmlElement *root = doc.FirstChildElement("zamf");

	//resource directories
	el = root->FirstChildElement("resources");
	mPathToResources = el->Attribute("dir");
	el = el->FirstChildElement("resource");
	while (el != NULL)
	{
		type = el->Attribute("type");
		dir = el->Attribute("dir");
		mPaths[type] = dir;
		el = el->NextSiblingElement("resource");
	}

	return true;
}

std::string CConfig::GetFullPathTo(std::string resourceType)
{
	std::map<std::string, std::string>::iterator it;
	it = mPaths.find(resourceType);
	if (it == mPaths.end())
	{
		throw(("Resource " + resourceType + " does not exist.").c_str());
	}
	return mPathToResources + it->second;
}