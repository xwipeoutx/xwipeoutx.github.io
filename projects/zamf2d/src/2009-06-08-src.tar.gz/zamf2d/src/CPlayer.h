#pragma once

#include "CActor.h"
#include "CItem.h"
#include <vector>

namespace ZAMF
{
	#define PLAYER_JUMP_VEL 7.0f

	#define PLAYER_FACING_RIGHT 0
	#define PLAYER_FACING_LEFT 1

	class CPlayerDef : public CActorDef
	{
	public: 
		bool Load(TiXmlElement *root);

		float maxVel, accelForce, jumpForce;
		int initialDir;
		float density, friction, restitution;

		int bagCapacity;
	};

	class CPlayer :	public CActor
	{
	public:
		CPlayer(CPlayerDef *def, float x, float y);
		~CPlayer(void);

		virtual void HandleEvent(const SDL_Event &e);
		bool Update(float dt);
		void Draw();
		
		bool AddItemToBag(CItem *item);

		int GetFirstOccupiedItemPosition(int start=0) const;
		int GetFirstFreeBagPosition(int start=0) const;
		CItem *GetItemFromBag(int position) const;
		bool RemoveItemFromBag(int position);

		b2Vec2 GetPosition() const;
		int GetBagCapacity() const{return mDef.bagCapacity;}

		void Collide(CActor *other);

	private:

		void FireNail();
		void Jump();

		CPlayerDef mDef;
		float mVel;

		//Inventory stuff
		std::vector<CItem*> mBag;
		//CMeleeWeapon *mMeleeWeapon;
		//CRangedWeapon *mRangedWeapon;
		//CArmour *mArmour;

	};
};