#include "CActor.h"
#include "CScene.h"
#include "CSpriteFactory.h"

using namespace ZAMF;

CActor::CActor(CActorDef *def)
: mFlags(ACTOR_NONE), mDying(false)
{
	CScene::GetSingleton().RegisterActor(this);
	if(def != NULL)
		mSprite = CSpriteFactory::GetSingleton().Get(def->mType, def->mName);
}

CActor::~CActor(void)
{
	CScene::GetSingleton().UnregisterActor(this);
}

CActorDef::CActorDef()
 :mLoaded(false),mName("")
{
}

bool CActorDef::Load(TiXmlElement *root)
{
	mType = root->Attribute("type");
	mSubType = root->Attribute("subtype");
	mName = std::string(root->FirstChildElement("name")->GetText());
	CSpriteFactory::GetSingleton().Load(mType, mName, root->FirstChildElement("sprite"));

	mLoaded = true;
	return true;
}