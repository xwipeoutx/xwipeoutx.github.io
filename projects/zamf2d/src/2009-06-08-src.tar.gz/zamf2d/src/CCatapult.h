#pragma once

#include "CActor.h"

namespace ZAMF
{

	#define PLAYER_FACING_LEFT 1

	class CCatapultDef : public CActorDef
	{
	public:
		bool Load(TiXmlElement *root);

		float mRecoveryTime, mAnimationTime, mFiringTime;
	};

	class CCatapult : public CActor
	{
	public:
		CCatapult(CCatapultDef *def, float x, float y);
		~CCatapult(void);

		void Draw();
		bool Update(float dt);

	private:
		CCatapultDef mDef;
		enum {
			CATAPULT_IDLE=0,
			CATAPULT_FIRING=1,
			CATAPULT_FINISHING=2,
			CATAPULT_RECOVERING=3
		} mState;

		float mX, mY;

		float mRecoveryCountdown;
		float mAnimationCountdown;
		float mFiringCountdown;
	};

}