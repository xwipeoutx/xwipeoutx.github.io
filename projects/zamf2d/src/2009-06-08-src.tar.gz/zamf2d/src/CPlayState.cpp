#include "CPlayState.h"
#include "CMenuState.h"
#include "CDeadState.h"
#include "CGameManager.h"

#include "CActorFactory.h"
#include "CSpriteFactory.h"
#include "CScene.h"
#include "CHud.h"
#include "CEGUI.h"

using namespace ZAMF;
using namespace CEGUI;
CPlayState::CPlayState(void)
: mScene(NULL)
{
}

CPlayState::~CPlayState(void)
{
}


void CPlayState::Enter()
{
	new CActorFactory();

	mScene = new CScene();
	mScene->Create("test");

	//load the inventory image set
	ImagesetManager::getSingleton().createImageset("inventory.imageset");

	//load the play layout
	Window* window = WindowManager::getSingleton().loadWindowLayout( "playlayout.xml" );
	System::getSingleton().setGUISheet( window );

}

void CPlayState::Exit()
{
	mScene->Rapture();
	delete mScene;
	mScene = NULL;
	delete CActorFactory::GetSingletonPtr();

	//destroy CEGUI stuff
	WindowManager::getSingleton().destroyWindow("Play");
	System::getSingleton().setGUISheet( NULL );
	ImagesetManager::getSingleton().destroyImageset("Inventory");
}

void CPlayState::Pause()
{
}

void CPlayState::Resume()
{
}

void CPlayState::HandleEvent(const SDL_Event &e)
{
	//escape - back to menu screen
	if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_ESCAPE)
	{
		CGameManager::GetSingleton().ChangeState(new CMenuState());
	}
	//dead - to dead state
	else if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_k)
	{
		CGameManager::GetSingleton().PushState(new CDeadState());
	}
	else
	{
		mScene->HandleEvent(e);
	}
}
void CPlayState::Draw()
{
	mScene->Draw();
}
bool CPlayState::Update(float dt)
{
	return mScene->Update(dt);
}
