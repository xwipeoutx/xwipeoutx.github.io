#include "CActorFactory.h"

#include "CFridge.h"
#include "CZombie.h"
#include "CPlayer.h"
#include "CNail.h"
#include "CLinearSpawner.h"
#include "CCatapult.h"
#include "CMothball.h"
#include "CConfig.h"

using namespace ZAMF;

CActorFactory::CActorFactory(void)
{

}

CActorFactory::~CActorFactory(void)
{
}

CActorDef *CActorFactory::Load(const std::string type, const std::string &name)
{
	CActorDef *def=NULL;
	TiXmlDocument *doc = NULL;
	std::string filename = ZAMF_CFG_GET_PATH("def") + "actor/" + type + "/" + name + ".xml";
	doc = new TiXmlDocument(filename.c_str());

	if (doc != NULL)
	{
		bool ok = doc->LoadFile();
		if (!ok)
		{
			const char *desc = doc->ErrorDesc();
			throw(desc);
		}
		TiXmlElement *el = doc->FirstChildElement("actor");

		std::string subType = el->Attribute("subtype");

		if (type == "enemy")
		{
			if (subType == "zombie") def = new CZombieDef();
		}

		else if (type == "base")
		{
			if (subType == "player") def = new CPlayerDef();
			else if (subType == "fridge") def = new CFridgeDef();
		}

		else if (type == "projectile")
		{
			if (subType == "nail") def = new CNailDef();
			else if (subType == "mothball") def = new CMothballDef();
		}

		else if (type == "spawner")
		{
			if (subType == "zombie") def = new CLinearSpawnerDef();
		}

		else if (type == "weapon")
		{
			if (subType == "catapult") def = new CCatapultDef();
		}

		else if (type == "item")
		{
			def = new CItemDef();
		}

		if (def == NULL)
			throw("Subtype not found");

		def->Load(el);

		delete doc;
		doc = NULL;
	} else {
		throw("Could not load xml file");
	}

	if (def != NULL)
	{
		const std::string key = type + "," + name;
		mActorDefs[key] = def;
	}
	return def;
}

CActorDef *CActorFactory::CreateOrLoadDef(const std::string &type, const std::string &name)
{
	CActorDef *def = NULL;
	const std::string key = type + "," + name;

	ActorsDefMap::iterator it = mActorDefs.find(key);
	if (it == mActorDefs.end())
	{
		def = Load(type, name);
		if (def == NULL)
			throw("Failed loading actor");
	}
	else
	{
		def = it->second;
	}
	return def;
}

CActor *CActorFactory::Create(const std::string &type, const std::string &name, float a1, float a2)
{
	CActorDef *def = NULL;
	CActor *actor = NULL;

	def = CreateOrLoadDef(type, name);
	if (def == NULL)
		return NULL;

	if (type == "enemy" && name == "zombie")
		actor = new CZombie(static_cast<CZombieDef*>(def), a1, a2);
	else if (type == "base" && name == "player")
		actor = new CPlayer(static_cast<CPlayerDef*>(def), a1, a2);
	else if (type == "weapon" && name == "catapult")
		actor = new CCatapult(static_cast<CCatapultDef*>(def), a1, a2);
	else if (type == "item")
		actor = new CItem(static_cast<CItemDef*>(def),a1,a2);

	return actor;
}

CActor *CActorFactory::Create(const std::string &type, const std::string &name, const std::string &a1, const std::string &a2, float a3, float a4, float a5)
{
	CActorDef *def = NULL;
	CActor *actor = NULL;

	def = CreateOrLoadDef(type, name);
	if (def == NULL)
		return NULL;

	if (type == "spawner" && name == "linear")
	{
		actor = new CLinearSpawner(static_cast<CLinearSpawnerDef*>(def), a1, a2, a3, a4, a5);

	}
	return actor;
}

CActor *CActorFactory::Create(const std::string &type, const std::string &name, float a1, float a2, float a3, float a4)
{
	CActorDef *def = NULL;
	CActor *actor = NULL;

	def = CreateOrLoadDef(type, name);
	if (def == NULL)
		return NULL;

	if (type == "base" && name == "fridge")
		actor = new CFridge(static_cast<CFridgeDef*>(def), a1, a2, a3, a4);
	else if (type == "projectile" && name == "nail")
		actor = new CNail(static_cast<CNailDef*>(def), a1, a2, a3, a4);
	else if (type == "projectile" && name == "mothball")
		actor = new CMothball(static_cast<CMothballDef*>(def), a1, a2, a3, a4);

	return actor;
}
