#include "CGameManager.h"
#include "IGameState.h"

#include "CScene.h"
#include "CActorFactory.h"
#include "CSpriteFactory.h"
#include "CTimer.h"
#include "CGameWindow.h"
#include "CHud.h"
#include "CConfig.h"


using namespace ZAMF;

CGameManager::CGameManager()
: mRunning(true), mGUIManager(0)
{
}

CGameManager::~CGameManager()
{
	
}

void CGameManager::Start(IGameState* state)
{
	(new CConfig())->Load("config.xml");
	new CHud();
	new CSpriteFactory();
	mGUIManager = new CGUIManager();
	mGUIManager->Init(640, 480);
	ChangeState(state);
}

void CGameManager::Stop()
{	
	// clean up all the states
	while (!mStates.empty()) {
		mStates.back()->Exit();
		mStates.pop_back();
	}
	delete CSpriteFactory::GetSingletonPtr();
	delete CHud::GetSingletonPtr();
	mGUIManager->Destroy();
	delete mGUIManager;
	mGUIManager = 0;
}

void CGameManager::Run()
{
	CGameWindow *window = CGameWindow::GetSingletonPtr();

	CTimer deltaTimer;
	deltaTimer.Start();

	while (mRunning)
	{
		SDL_Event e;

		//handle any events
		while (SDL_PollEvent(&e))
		{
			window->HandleEvent(e);
			mGUIManager->HandleEvent(e);
			mStates.back()->HandleEvent(e);
		}
		
		//update timer
		int numTicks = deltaTimer.GetTicks();
		deltaTimer.Start();
		float dt = 0.001f * numTicks;
		
		//update window and current state
		window->Update(dt);
		mGUIManager->Update(dt);
		mRunning = mRunning & mStates.back()->Update(dt);

		//draw
		window->StartFrame();
		mStates.back()->Draw();
		mGUIManager->Draw();
		window->EndFrame();
	}
}

void CGameManager::Shutdown()
{
	mRunning = false;
}

void CGameManager::ChangeState(IGameState *state)
{
	// clean up all the current states
	while ( !mStates.empty() ) {
		mStates.back()->Exit();
		mStates.pop_back();
	}

	// store and init the new state
	mStates.push_back(state);
	mStates.back()->Enter();
}

void CGameManager::PushState(IGameState* state)
{
	// pause current state
	if ( !mStates.empty() ) {
		mStates.back()->Pause();
	}

	// store and init the new state
	mStates.push_back(state);
	mStates.back()->Enter();
}

void CGameManager::PopState()
{
	// cleanup the current state
	if ( !mStates.empty() ) {
		mStates.back()->Exit();
		mStates.pop_back();
	}

	// resume previous state
	if ( !mStates.empty() ) {
		mStates.back()->Resume();
	}
}