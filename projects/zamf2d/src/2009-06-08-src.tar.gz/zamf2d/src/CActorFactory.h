#pragma once

#include "CActor.h"
#include "CSingleton.h"
#include "tinyxml.h"
#include <string>
#include "common.h"
namespace ZAMF
{

	class CActorFactory : public CSingleton<CActorFactory>
	{
	public:
		CActorFactory(void);
		~CActorFactory(void);

		CActorDef *Load(const std::string type, const std::string &name);

		CActor *Create(const std::string &type, const std::string &name, float a1, float a2);
		CActor *Create(const std::string &type, const std::string &name, const std::string &a1, const std::string &a2, float a3, float a4, float a5);
		CActor *Create(const std::string &type, const std::string &name, float a1, float a2, float a3, float a4);
		CActor *Create(const std::string &type, const std::string &name, b2Vec2 a1, b2Vec2 a2);

	private:

#ifdef _WIN32
		typedef stdext::hash_map<std::string, CActorDef* > ActorsDefMap;
#else
		typedef std::unordered_map<std::string, CActorDef* > ActorsDefMap;
#endif
		CActorDef *CreateOrLoadDef(const std::string &type, const std::string &name);
		ActorsDefMap mActorDefs;
	};
};
