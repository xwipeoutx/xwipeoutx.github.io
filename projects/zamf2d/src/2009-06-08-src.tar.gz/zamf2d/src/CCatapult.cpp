#include "CCatapult.h"

#include "CActorFactory.h"
#include "utils.h"

using namespace ZAMF;

bool CCatapultDef::Load(TiXmlElement *root)
{
	CActorDef::Load(root);

	TiXmlElement *el = root->FirstChildElement("firing");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("recoverytime", &mRecoveryTime) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("animationtime", &mAnimationTime) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("firingtime", &mFiringTime) );

	return true;
}

CCatapult::CCatapult(CCatapultDef *def, float x, float y)
: CActor(def), mX(x), mY(y)
{
	CCatapultDef def2 = *def;
	mDef = def2;

	
	mSprite->SetState(CATAPULT_FIRING);
	mState = CATAPULT_FIRING;
	mAnimationCountdown = mDef.mAnimationTime;
	mFiringCountdown = mDef.mFiringTime;

	//hi
}

CCatapult::~CCatapult(void)
{
}

void CCatapult::Draw()
{
	glPushMatrix();
	glTranslatef(mX, mY, 0);
	mSprite->Draw();
	glPopMatrix();

}

bool CCatapult::Update(float dt)
{
	switch (mState)
	{
	case CATAPULT_IDLE:
		//idle - do nothing
		break;

	case CATAPULT_FIRING:
		mFiringCountdown -= dt;
		mAnimationCountdown -= dt;
		mSprite->AdvanceFrame(dt, false);
		if (mFiringCountdown < 0)
		{
			//FIRE
			CActorFactory::GetSingleton().Create("projectile", "mothball", mX, mY+0.5f, 1, 1);
			if (mAnimationCountdown < 0) 
			{
				mState = CATAPULT_RECOVERING;
				mRecoveryCountdown = mDef.mRecoveryTime;
			}
			else
			{
				mState = CATAPULT_FINISHING;
			}
		}

		break;

	case CATAPULT_FINISHING:
		mAnimationCountdown -= dt;
		mSprite->AdvanceFrame(dt, false);
		if (mAnimationCountdown < 0) 
		{
			mState = CATAPULT_RECOVERING;
			mRecoveryCountdown = mDef.mRecoveryTime;
		}
		break;

	case CATAPULT_RECOVERING:
		mRecoveryCountdown -= dt;
		mSprite->AdvanceFrame(-dt, false);
		if (mRecoveryCountdown < 0)
		{
			mState = CATAPULT_FIRING;
			//mSprite->SetState(CATAPULT_FIRING);
			mAnimationCountdown = mDef.mAnimationTime;
			mFiringCountdown = mDef.mFiringTime;
		}
		break;
	}

	return true;
}