#pragma once

#include "IGameState.h"

namespace ZAMF
{
	class CScene;

	class CPlayState : public IGameState
	{
	public:
		CPlayState(void);
		~CPlayState(void);
		
		virtual void Enter();
		virtual void Exit();

		virtual void Pause();
		virtual void Resume();
		
		virtual void HandleEvent(const SDL_Event &e);
		virtual void Draw();
		virtual bool Update(float dt);
		
		inline virtual const std::string GetStateName(){return "PlayState";}

	protected:
		CScene *mScene;
	};
}