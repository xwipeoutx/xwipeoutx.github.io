#pragma once
#include <list>
#include <string>
#include "Box2D.h"

#include "CSingleton.h"
#include "CActor.h"
#include "CPhysicsDebugDraw.h"
#include "common.h"

namespace ZAMF
{
	class CHouse : public b2ContactListener, public CSingleton<CHouse>
	{
	public:
		//construction stuff
		CHouse();
		~CHouse(void);

		void Build(std::string house);

		bool CollidesWith(const CActor *actor, CActor::ActorFlags flags=CActor::ACTOR_ALL);



	private:
	};

};
