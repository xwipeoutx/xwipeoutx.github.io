#include "CSprite.h"

#include "utils.h"
#include "common.h"

using namespace ZAMF;

CSprite::CSprite(std::string filename, 
			  float width, float height, int columns, int rows,
//			  int numStates, int framesPerState, float fps, int initialState)
			  int numStates, int initialState, SpriteFrameInfo *frames)
: mWidth(width), mHeight(height), 
mNumStates(numStates),  mState(initialState), mFrame(0)
{
	//Create a surface for the image
	SDL_Surface *surface = ZAMF::ImageLoad(filename);
	if (surface == NULL) throw("Could not load sprite image");
	mTexId = SDL_GL_SurfaceToTexture(surface);
	SDL_FreeSurface(surface);

	GLuint numFrames=0;

	if (frames == NULL)
	{
		mFrames = new SpriteFrameInfo[1];
		mFrames[0].fps = 0;
		mFrames[0].frames = 1;
		mFrames[0].index = 0;
		mFrames[0].name = std::string("Still");
		mFrames[0].startFrame = 0;
		numFrames = 1;
	}
	else
	{
		mFrames = new SpriteFrameInfo[numStates];
		for (int i=0; i<numStates; i++)
		{
			mFrames[i].fps = frames[i].fps;
			mFrames[i].frames = frames[i].frames;
			mFrames[i].index = frames[i].index;
			mFrames[i].name = frames[i].name;
			mFrames[i].startFrame = frames[i].startFrame;
			numFrames += mFrames[i].frames;
		}
	}

	//generate display lists
	int displayListId = glGenLists(numFrames);

	float dx = 1.f / columns;
	float dy = 1.f / rows;

	float xd = 0.5f*mWidth;
	float yd = 0.5f*mHeight;

	for (int i=0; i<numStates; i++)
	{
		mFrames[i].displayListId = displayListId;
		int ix = mFrames[i].startFrame % columns;
		int iy = mFrames[i].startFrame / columns;

		for (int j=0; j<mFrames[i].frames; j++)
		{
			float x = ix * dx;
			float y = 1-iy * dy;
			glNewList(displayListId++, GL_COMPILE);
			{
				glBegin(GL_QUADS);
				{
					glTexCoord2f(x, y-dy);
					glVertex3f( -xd, -yd, 0 );

					glTexCoord2f(x+dx,y-dy);
					glVertex3f(  xd,  -yd, 0 ); 

					glTexCoord2f(x+dx,y);
					glVertex3f(  xd,   yd, 0 ); 

					glTexCoord2f(x,y);
					glVertex3f( -xd,  yd, 0 ); 
				}
				glEnd(); 
			}
			glEndList();
			checkGLError("Creating Lists");

			if (ix == columns-1) 
				iy++;
			ix = ((ix + 1) % columns);
		}
	}
}

CSprite::CSprite(CSprite *other)
{
	mTexId = other->mTexId;
	mWidth = other->mWidth;
	mHeight = other->mHeight;
	mNumStates = other->mNumStates;
	mFrame = other->mFrame;
	mState = other->mState;
	mFrames = other->mFrames;
}

CSprite::~CSprite(void)
{
	return;
	/*TODO: Check Sprite Allocations
	std::map<std::string, std::pair<int, GLuint> >::iterator it;
	it = sSpriteAllocations.find(mFilename);
	if (it != sSpriteAllocations.end())
	{
		if(--it->second.first == 0)
		{
			//delete the texture and iterator
			glDeleteTextures(1, &mTexId);
			sSpriteAllocations.erase(it);
		}
	}
	*/
}


void CSprite::AdvanceFrame(float dt, bool loop)
{
	mFrame += dt*mFrames[mState].fps;
	if  (loop)
	{
		if (mFrame > mFrames[mState].frames-0.01f) mFrame = 0;
		else if ( mFrame < 0) mFrame = (float)mFrames[mState].frames-0.01f;
	}
	else
	{
		if (mFrame > mFrames[mState].frames-0.01f) mFrame = (float)mFrames[mState].frames-0.01f;
		else if ( mFrame < 0) mFrame = 0;
	}
}

void CSprite::Draw()
{
	glColor3f(1,1,1);
	glBindTexture(GL_TEXTURE_2D,mTexId);

	GLuint offset = mFrames[mState].displayListId + (GLuint)(mFrame);

	glCallList(offset);
}