#pragma once

#include "CSingleton.h"
#include <string>
#include <map>

#define ZAMF_CFG_GET_PATH(_TYPE) CConfig::GetSingleton().GetFullPathTo(_TYPE)

namespace ZAMF
{
	class CConfig : public CSingleton<CConfig>
	{
	public:
		CConfig(void);
		~CConfig(void);

		bool Load(std::string filename);

		std::string GetFullPathTo(std::string resourceType);
		
		int GetResX(){return mResX;}
		int GetResY(){return mResY;}

	private:
		std::string mPathToResources;
		std::map<std::string, std::string> mPaths;

		int mResX, mResY;
		int mWindowMode;
		std::string mTitle;
	};
}