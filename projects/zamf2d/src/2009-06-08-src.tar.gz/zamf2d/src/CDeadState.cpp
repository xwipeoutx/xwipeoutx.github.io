#include "CDeadState.h"
#include "CScene.h"
#include "CHud.h"

using namespace ZAMF;

CDeadState::CDeadState(void)
{
}

CDeadState::~CDeadState(void)
{
}

void CDeadState::Enter()
{
}

void CDeadState::Exit()
{
}

void CDeadState::Pause()
{
}

void CDeadState::Resume()
{
}

void CDeadState::HandleEvent(const SDL_Event &e)
{

}

void CDeadState::Draw()
{
	CScene::GetSingleton().Draw();
}
