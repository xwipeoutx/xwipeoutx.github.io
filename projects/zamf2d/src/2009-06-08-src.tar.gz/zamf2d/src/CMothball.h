#pragma once
#include "CActor.h"

namespace ZAMF
{
	class CMothballDef : public CActorDef
	{
	public:
		bool Load(TiXmlElement *root);

		float baseDamage, damageMultiplier;
		float w, h;
		float initialVel, initialDisplacement;
		float density, friction, restitution;
		float linearDamping, angularDamping;
	};

	class CMothball : public ZAMF::CActor
	{
	public:
		CMothball(CMothballDef *def, float x, float y, float xdir, float ydir);
		~CMothball(void);

		void Draw();
		bool Update(float dt);
		void Collide(CActor *other);

		bool GetDestroyed(){return mDestroyed;}

	private:
		bool mDestroyed;
		float mCountdown;
		CMothballDef mDef;
	};
};