#pragma once

#include "CSingleton.h"
#include "CSprite.h"
#include "tinyxml.h"

#include "common.h"

namespace ZAMF
{

	class CSpriteFactory : public CSingleton<CSpriteFactory>
	{
	public:
		CSpriteFactory(void);
		~CSpriteFactory(void);

		CSprite *Load(std::string type, std::string name, std::string filename, float width, float height, int columns=1, int rows=1, int numStates=1, int initialState=0, CSprite::SpriteFrameInfo *spritesInfo=NULL);
		//CSprite *Load(std::string name, std::string filename, float width, float height, int numStates=1, int framesPerState=1, float fps=1, int initialState=0);
		CSprite *Load(std::string type, std::string name, TiXmlElement *spriteNode);
		CSprite *Get(std::string type, std::string name);

	private:

#ifdef _WIN32
		typedef stdext::hash_map<std::string, CSprite* > SpritesMapDef;
#else
		typedef std::unordered_map<std::string, CSprite* > SpritesMapDef;
#endif
		SpritesMapDef mSprites;
	};
};
