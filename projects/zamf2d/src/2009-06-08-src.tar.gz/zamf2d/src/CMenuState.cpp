#include "CMenuState.h"

#include "CSpriteFactory.h"
#include "CGameManager.h"
#include "CPlayState.h"
#include "CHud.h"

#include "CGUIManager.h"

using namespace ZAMF;
using namespace CEGUI;
CMenuState::CMenuState(void)
{
}

CMenuState::~CMenuState(void)
{
}


void CMenuState::Enter()
{
	//load the image set
	ImagesetManager::getSingleton().createImageset("intro.imageset");

	//load the menu layout
	Window* window = WindowManager::getSingleton().loadWindowLayout( "menulayout.xml" );
	System::getSingleton().setGUISheet( window );

	//subscribe events for play and quit buttons
	window = WindowManager::getSingleton().getWindow("Menu/PlayButton");
	window->subscribeEvent(PushButton::EventClicked, Event::Subscriber(&CMenuState::onPlayButtonClicked, this));
	window = WindowManager::getSingleton().getWindow("Menu/QuitButton");
	window->subscribeEvent(PushButton::EventClicked, Event::Subscriber(&CMenuState::onQuitButtonClicked, this));
}

void CMenuState::Exit()
{
	ImagesetManager::getSingleton().destroyImageset("Intro");
	WindowManager::getSingleton().destroyWindow("Menu");
	System::getSingleton().setGUISheet( NULL );
}

void CMenuState::Pause()
{
}

void CMenuState::Resume()
{
}
bool CMenuState::onPlayButtonClicked(const CEGUI::EventArgs &e)
{
	CGameManager::GetSingleton().ChangeState(new CPlayState());
	return true;
}
bool CMenuState::onQuitButtonClicked(const CEGUI::EventArgs &e)
{
	CGameManager::GetSingleton().Shutdown();
	return true;
}
void CMenuState::HandleEvent(const SDL_Event &e)
{
	if (e.type == SDL_KEYDOWN)
	{
		switch (e.key.keysym.sym)
		{
		case SDLK_s:
		case SDLK_RETURN:
			CGameManager::GetSingleton().ChangeState(new CPlayState());
			break;
		case SDLK_ESCAPE:
			CGameManager::GetSingleton().Shutdown();
		default:
			break;
		}
	}
}