#include "CZombie.h"
#include "CScene.h"
#include "CPhysicsManager.h"
#include "CPlayer.h"

#include "tinyxml.h"
#include "utils.h"

#include <fstream>
#include <string>

using namespace ZAMF;
using namespace std;

bool CZombieDef::Load(TiXmlElement *root)
{
	CActorDef::Load(root);

	TiXmlElement *el=NULL;
	// block: behaviour
	TiXmlElement *behaviourRootNode = root->FirstChildElement("behaviour");

	//stats
	el = behaviourRootNode->FirstChildElement("stats");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("hp", &mMaxHP) );

	//movement
	el = behaviourRootNode->FirstChildElement("movement");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("xvel", &xVel) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("seekplayerdistance", &seekPlayerDistance) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("accelforce", &accelForce) );

	//physics
	el = behaviourRootNode->FirstChildElement("physics");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("density", &density) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("friction", &friction) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("restitution", &restitution) );
	return true;
}

CZombie::CZombie(CZombieDef *def, float x, float y)
: CActor(def)
{
	mFlags = ACTOR_ENEMY;

	CZombieDef def2 = *def;
	mDef = def2;

	mHP = mDef.mMaxHP;

	//add to physics world
	b2BodyDef bodyDef;
	bodyDef.position.Set(x, y);
	bodyDef.fixedRotation = true;
	bodyDef.linearDamping = 0.0f;
	bodyDef.angularDamping = 0.0f;
	bodyDef.allowSleep = false;
	mBody = CPhysicsManager::GetSingleton().GetPhysicsWorld()->CreateBody(&bodyDef);

	float h = mSprite->GetHeight();
	float w = mSprite->GetWidth();
	float offset = 0.f;
	if (w < h) 
		offset = 0.5f*w;
	b2PolygonDef bodyShape;
	bodyShape.SetAsBox(0.5f*mSprite->GetWidth(), 0.5f*h - offset);
	bodyShape.density = def->density;
	bodyShape.friction = def->friction;
	bodyShape.restitution = def->restitution;
	bodyShape.filter.categoryBits = ACTOR_ENEMY;
	bodyShape.filter.maskBits = ACTOR_ENEMY | ACTOR_PLAYER | ACTOR_FRIDGE | ACTOR_PROJECTILE | ACTOR_STATIONARY;
	bodyShape.userData = this;
	mBody->CreateShape(&bodyShape);

	if (w < h)
	{
		b2CircleDef headShape;
		headShape.radius = 0.5f*mSprite->GetWidth();
		headShape.density = def->density;
		headShape.friction = def->friction;
		headShape.restitution = def->restitution;
		headShape.filter.categoryBits = ACTOR_ENEMY;
		headShape.filter.maskBits = ACTOR_ENEMY | ACTOR_PLAYER | ACTOR_FRIDGE | ACTOR_PROJECTILE | ACTOR_STATIONARY;
		headShape.userData = this;
		headShape.localPosition = b2Vec2(0, 0.5f*h - 0.5f*w);
		mBody->CreateShape(&headShape);
		headShape.localPosition = b2Vec2(0, -0.5f*h + 0.5f*w);
		mBody->CreateShape(&headShape);
	}
	




	mBody->SetMassFromShapes();

	//mBody->ApplyImpulse(b2Vec2(2, 0), b2Vec2(0,0));
	//mBody->SetLinearVelocity(b2Vec2(ZOMBIE_SPEEDX, 0));
}

CZombie::~CZombie(void)
{
	CPhysicsManager::GetSingleton().GetPhysicsWorld()->DestroyBody(mBody);
	mBody = NULL;
	delete mSprite;
}

bool CZombie::Update(float dt)
{
	//well all we have to make sure about now is the zombie is moving...let's try it
	b2Vec2 linVel = mBody->GetLinearVelocity();

	const CPlayer *p = CScene::GetSingleton().GetPlayer();

	float targetVelocity=0;
	float dp = (p->GetPosition() - mBody->GetPosition()).LengthSquared();
	if (dp < mDef.seekPlayerDistance)
	{
		//seek the player
		dp = p->GetPosition().x - mBody->GetPosition().x;
		targetVelocity = (dp > 0.f ? 1.f : -1.f);
	}
	else
	{
		//seek the fridge
		b2Body *b = CPhysicsManager::GetSingleton().GetPhysicsWorld()->GetBodyList();
		while (b != NULL)
		{
			b2Shape *s= b->GetShapeList();
			while (s != NULL)
			{
				if (s->GetFilterData().categoryBits & ACTOR_FRIDGE)
				{
					float ds = b->GetPosition().x - mBody->GetPosition().x;
					targetVelocity = ds > 0.f ? 1.f : -1.f;
				}
				s = s->GetNext();
			}
			b = b->GetNext();
		}
	}
	targetVelocity *= mDef.xVel;

	if (targetVelocity > 0)
	{
		mSprite->SetState(ZOMBIE_FACING_RIGHT);
	} 
	else if (targetVelocity < 0) 
	{
		mSprite->SetState(ZOMBIE_FACING_LEFT);
	}
	
	//apply force to the zombie
	float d = targetVelocity - linVel.x;
	d *= mDef.accelForce*mBody->GetMass()*dt;
	mBody->ApplyForce(b2Vec2(d, 0), mBody->GetPosition());


	mSprite->AdvanceFrame(dt);

	return true;
}
void CZombie::Draw()
{
	glPushMatrix();

	b2Vec2 pos = mBody->GetPosition();
	float angle = mBody->GetAngle();

	glTranslatef(pos.x, pos.y, 0);
	glRotatef(angle*180/3.14159f, 0,0,1);
	mSprite->Draw();
	glPopMatrix();
}

void CZombie::Hit(float dmg)
{
	mHP -= dmg;
	if (mHP <= 0)
		mDying = true;
}

//contact points
void CZombie::Collide(CActor *other)
{
	if (other != NULL && other->GetFlags() & ACTOR_FRIDGE)
	{
		other->SetDying(true);
	}
}
