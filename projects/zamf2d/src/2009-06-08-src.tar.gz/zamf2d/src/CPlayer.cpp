#include "CPlayer.h"
#include "CScene.h"
#include "CNail.h"
#include "CActorFactory.h"
#include "CPhysicsManager.h"

#include <string>
#include <fstream>
#include "CHud.h"

#include "utils.h"
using namespace ZAMF;
using namespace std;

bool CPlayerDef::Load(TiXmlElement *root)
{
	CActorDef::Load(root);

	TiXmlElement *el=NULL;

	//block: stats
	el = root->FirstChildElement("stats");
	CheckXMLSuccessAttribute( el->QueryIntAttribute("bagcapacity", &bagCapacity ) );
	// block: behaviour
	TiXmlElement *behaviourRootNode = root->FirstChildElement("behaviour");

	//movement
	el = behaviourRootNode->FirstChildElement("movement");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("maxvel", &maxVel) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("accelforce", &accelForce) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("jumpforce", &jumpForce) );

	//physics
	el = behaviourRootNode->FirstChildElement("physics");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("density", &density) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("friction", &friction) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("restitution", &restitution) );

	return true;
}

CPlayer::CPlayer(CPlayerDef *def, float x, float y)
: CActor(def)
{
	mFlags = ACTOR_PLAYER;
	mVel = 0;

	CPlayerDef def2 = *def;
	mDef = def2;

	//add to physics world
	b2BodyDef bodyDef;
	bodyDef.position.Set(x, y);
	bodyDef.fixedRotation = true;
	bodyDef.linearDamping = 0.0f;
	bodyDef.angularDamping = 0.0f;
	bodyDef.allowSleep = false;
	mBody = CPhysicsManager::GetSingleton().GetPhysicsWorld()->CreateBody(&bodyDef);

	float h = mSprite->GetHeight();
	float w = mSprite->GetWidth();
	float offset = 0.f;
	if (w < h)
		offset = 0.5f*w;
	b2PolygonDef bodyShape;
	bodyShape.SetAsBox(0.5f*w, 0.5f*h - offset);
	bodyShape.density = mDef.density;
	bodyShape.friction = mDef.friction;
	bodyShape.restitution = mDef.restitution;
	bodyShape.filter.categoryBits = ACTOR_PLAYER;
	bodyShape.filter.maskBits = ACTOR_ENEMY | ACTOR_STATIONARY | ACTOR_ITEM;
	bodyShape.userData = this;
	mBody->CreateShape(&bodyShape);

	if (w < h)
	{
		b2CircleDef headShape;
		headShape.radius = 0.5f*mSprite->GetWidth();
		headShape.density = mDef.density;
		headShape.friction = mDef.friction;
		headShape.restitution = mDef.restitution;
		headShape.filter.categoryBits = ACTOR_PLAYER;
		headShape.filter.maskBits = ACTOR_FRIDGE | ACTOR_ENEMY | ACTOR_STATIONARY;
		headShape.userData = this;
		headShape.localPosition = b2Vec2(0, 0.5f*h - 0.5f*w);
		mBody->CreateShape(&headShape);
		headShape.localPosition = b2Vec2(0, -0.5f*h + 0.5f*w);
		mBody->CreateShape(&headShape);
	}

	mBody->SetMassFromShapes();

	mBag = std::vector<CItem*>(mDef.bagCapacity);
}

CPlayer::~CPlayer(void)
{
}
b2Vec2 CPlayer::GetPosition() const
{
	return mBody->GetPosition();
}

void CPlayer::HandleEvent(const SDL_Event &e)
{
	if (e.type == SDL_KEYDOWN)
	{
		b2Vec2 pos = mBody->GetPosition();
		switch (e.key.keysym.sym)
		{
		case SDLK_RIGHT:
		case SDLK_d:
			mVel += mDef.maxVel;
			break;
		case SDLK_LEFT:
		case SDLK_a:
			mVel -= mDef.maxVel;
			break;
		case SDLK_UP:
		case SDLK_w:
		case SDLK_SPACE:
			Jump();
			break;
		case SDLK_e:
			FireNail();
			break;
		case SDLK_c:
			CActorFactory::GetSingleton().Create("weapon", "catapult", pos.x, pos.y);
			break;
		default:
			break;
		}
	}
	else if (e.type == SDL_KEYUP)
	{
		switch (e.key.keysym.sym)
		{
		case SDLK_RIGHT:
		case SDLK_d:
			mVel -= mDef.maxVel;
			break;
		case SDLK_LEFT:
		case SDLK_a:
			mVel += mDef.maxVel;
			break;
		default:
			break;
		}
	}
	else if (e.type == SDL_MOUSEBUTTONDOWN && e.button.button == 1)
	{
		FireNail();
	}
}

bool CPlayer::Update(float dt)
{
	b2Vec2 linVel = mBody->GetLinearVelocity();
	//linVel.x = mVel;

	//accelerate player towards velocity
	float d = mVel - linVel.x;
	d *= mDef.accelForce*mBody->GetMass()*dt;
	mBody->ApplyForce(b2Vec2(d, 0), mBody->GetPosition());

	mSprite->AdvanceFrame(abs(linVel.x) / mDef.maxVel * dt);
	float v = mBody->GetLinearVelocity().x;
	if (v > 0) mSprite->SetState(PLAYER_FACING_RIGHT);
	else if (v < 0) mSprite->SetState(PLAYER_FACING_LEFT);

	return true;
}

void CPlayer::Draw()
{
	glPushMatrix();
	b2Vec2 pos = mBody->GetPosition();
	float angle = mBody->GetAngle();

	glTranslatef(pos.x, pos.y, 0);
	glRotatef(angle*180/3.14159f, 0,0,1);
	mSprite->Draw();
	glPopMatrix();
}

void CPlayer::FireNail()
{
	int x, y;
	SDL_GetMouseState(&x, &y);
	b2Vec2 playerPos = mBody->GetPosition();
	b2Vec2 dir = CScene::GetSingleton().PixelToWorld(x, y) - playerPos;
	CActorFactory::GetSingleton().Create("projectile", "nail",playerPos.x, playerPos.y, dir.x, dir.y);
}

void CPlayer::Jump()
{
	mBody->ApplyImpulse(b2Vec2(0,mDef.jumpForce), b2Vec2_zero);
}

void CPlayer::Collide(CActor *other)
{
	if (other==NULL) return;

	if (other->GetFlags() & ACTOR_ITEM)
	{
		CItem *item = static_cast<CItem*>(other);
		if (item->GetState() == CItem::ITEM_IN_WORLD)
		{
			bool ok = this->AddItemToBag(item);
			if (ok)	item->PickUp();
			CHud::GetSingleton().UpdateInventory();
		}
	}
	else if (other->GetFlags() & ACTOR_FRIDGE)
	{
		//put the items in the fridge
		int pos;
		while ((pos = GetFirstOccupiedItemPosition()) != mDef.bagCapacity)
		{
			CItem *item = GetItemFromBag(pos);
			bool ok = this->RemoveItemFromBag(pos);
			if (ok)
			{
				item->PutInFridge();
				CScene::GetSingleton().AddScore(item->GetPoints());
				CHud::GetSingleton().UpdateScore();
				CHud::GetSingleton().UpdateInventory();
			}
		}
	}
	else if (other->GetFlags() & ACTOR_STATIONARY)
	{

	}
}

int CPlayer::GetFirstFreeBagPosition(int start) const
{
	for (int i=start; i<mDef.bagCapacity; i++)
	{
		if (mBag[i] == NULL) return i;
	}
	return mDef.bagCapacity;
}

bool CPlayer::AddItemToBag(CItem *item)
{
	int pos = GetFirstFreeBagPosition();

	if (pos == mDef.bagCapacity)
		return false;

	mBag[pos] = item;
	return true;

}

bool CPlayer::RemoveItemFromBag(int pos)
{
	if (pos < 0 || pos >= mDef.bagCapacity) return false;
	mBag[pos] = NULL;
	return true;
}

CItem *CPlayer::GetItemFromBag(int position) const
{
	return mBag[position];
}

int CPlayer::GetFirstOccupiedItemPosition(int start) const
{
	for (int i=start; i<mDef.bagCapacity; i++)
	{
		if (mBag[i] != NULL) return i;
	}
	return mDef.bagCapacity;
}
