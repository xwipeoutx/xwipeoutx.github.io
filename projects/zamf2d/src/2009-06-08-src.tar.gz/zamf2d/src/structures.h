#pragma once

namespace ZAMF
{
	struct Box
	{
		float x, y, w, h;
	};
}