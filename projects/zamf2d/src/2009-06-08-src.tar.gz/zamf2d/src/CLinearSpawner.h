#pragma once

#include "CActor.h"
#include <string>

namespace ZAMF
{
	class CLinearSpawnerDef : public CActorDef
	{
	public:
		CLinearSpawnerDef();
		bool Load(TiXmlElement *root);
	};

	class CLinearSpawner : public CActor
	{
	public:
		CLinearSpawner(CLinearSpawnerDef *def, const std::string &actorType, const std::string &actorName, float x, float y, float delay);
		~CLinearSpawner(void);

		bool Update(float dt);

	private:
		float mX, mY, mDelay;
		std::string mActorType;
		std::string mActorName;

		float mElapsed;
	};
};