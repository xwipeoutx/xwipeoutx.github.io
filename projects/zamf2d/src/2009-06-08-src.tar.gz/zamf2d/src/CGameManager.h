#pragma once

#include <vector>
#include "CSingleton.h"
#include "CGUIManager.h"


namespace ZAMF
{
	class IGameState;

	class CGameManager : public CSingleton<CGameManager>
	{
	public:
		CGameManager();
		~CGameManager();
		void Start(IGameState* state);
		void Stop();
		
		void Run();

		void Shutdown();

		void ChangeState(IGameState* state);
		void PushState(IGameState* state);
		void PopState();
	protected:		
		bool mRunning;

		void SetupStates(void);
		void SetupPhysics(void);

	private:
		std::vector<IGameState*> mStates;
		CGUIManager *mGUIManager;
	};
}