#pragma once

#include "CActor.h"

namespace ZAMF
{
	#define ZOMBIE_FACING_RIGHT 0
	#define ZOMBIE_FACING_LEFT 1

	class CZombieDef : public CActorDef
	{
	public:
		bool Load(TiXmlElement *root);

		float mMaxHP;
		float xVel, seekPlayerDistance, accelForce;
		int initialDir;
		float density, friction, restitution;
	};


	class CZombie :	public CActor
	{
	public:
		CZombie(CZombieDef *def, float x, float y);
		~CZombie(void);

		bool Update(float dt);
		void Draw();
		void Collide(CActor *other);

		void Hit(float dmg);

	private:
		CZombieDef mDef;

		float mHP;
	};
};
