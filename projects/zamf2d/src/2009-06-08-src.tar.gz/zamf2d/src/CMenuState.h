#pragma once

#include "CEGUI.h"

#include "IGameState.h"
#include "CSprite.h"

namespace ZAMF
{
	class CMenuState : public IGameState
	{
	public:
		CMenuState(void);
		~CMenuState(void);
		
		virtual void Enter();
		virtual void Exit();

		virtual void Pause();
		virtual void Resume();
		
		virtual void HandleEvent(const SDL_Event &e);
		
		inline virtual const std::string GetStateName(){return "MenuState";}
		bool onPlayButtonClicked(const CEGUI::EventArgs &e);
		bool onQuitButtonClicked(const CEGUI::EventArgs &e);
	};
}