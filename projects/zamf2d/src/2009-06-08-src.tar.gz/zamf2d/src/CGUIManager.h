#pragma once
#include "CSingleton.h"
#include "common.h"

namespace ZAMF
{
	class CGUIManager : public CSingleton<CGUIManager>
	{
	public:
		CGUIManager(void);
		~CGUIManager(void);

		void Init(int width, int height);
		void Destroy();

		void HandleEvent(SDL_Event &e);
		void Update(float dt);
		void Draw();
	protected:
		void HandleMouseButtonDown(Uint8 &button);
		void HandleMouseButtonUp(Uint8 &button);

		CEGUI::System *mSystem;
		CEGUI::Renderer *mRenderer;
	};
};