#include "common.h" 

#include <fstream>

#include "CGameWindow.h"

#include "CGameManager.h"
#include "CPlayState.h"
#include "CMenuState.h"

#include "CEGUI.h"

namespace ZAMF
{
	bool InitGL()
	{
		glClearColor(0.5,0.5,0.5,0);

		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrtho(0, 1, 0, 1, -1, 1);

		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		//enable stuff/settings
		glEnable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		if (glGetError() != GL_NO_ERROR)
			return false;
		return true;
	}

	bool Init()
	{
		if (SDL_Init(SDL_INIT_VIDEO) != 0)
			return false;

		new CGameWindow();
		if ((InitGL()) == false) return false;

		return true;
	}

	int Start()
	{
		if (!Init()) return 1;

		CGameManager *mgr = new CGameManager();

		mgr->Start(new CMenuState());
		mgr->Run();
		mgr->Stop();

		delete mgr;
		delete CGameWindow::GetSingletonPtr();

		return 0;
	}
};

int StartZAMF2D(int argc, char *argv[])
{
	int ret;
	try
	{
		ret = ZAMF::Start();
	} 
	catch (char *ex) 
	{
		std::ofstream exLog("exception.log");
		exLog << ex;
		exLog.close();
		ret = 1;
	}
	catch (CEGUI::Exception &ex)
	{
		std::ofstream exLog("exception.log");
		exLog << ex.getMessage();
		exLog.close();
		ret = 1;
	}
	return ret;
}