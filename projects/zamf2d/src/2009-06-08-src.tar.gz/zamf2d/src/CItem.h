#pragma once

#include "CActor.h"
#include <string>

namespace ZAMF
{
	class CItemDef : public CActorDef
	{
	public:
		bool Load(TiXmlElement *root);
		int points;
	};

	class CItem : public CActor
	{
	public:
		enum ItemState
		{
			ITEM_IN_WORLD,
			ITEM_IN_INVENTORY,
			ITEM_IN_FRIDGE
		};
		CItem(CItemDef *def, float x, float y);
		~CItem(void);

		void PickUp();
		void PutInFridge();
		ItemState GetState(){return mState;}
		const std::string &GetType(){return mDef.mType;}
		const std::string &GetSubType(){return mDef.mSubType;}
		const std::string &GetName(){return mDef.mName;}

		int GetPoints(){return mDef.points;}

		bool Update(float dt);
		void Draw();

	protected:
		CItemDef mDef;

		ItemState mState;
		float mX, mY;
		b2Body *mBody;
	};
};
