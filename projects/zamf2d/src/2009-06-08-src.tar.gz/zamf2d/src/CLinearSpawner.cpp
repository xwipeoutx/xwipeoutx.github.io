#include "CLinearSpawner.h"

#include "CActorFactory.h"
#include "CPhysicsManager.h"

using namespace ZAMF;

CLinearSpawnerDef::CLinearSpawnerDef()
{
}

bool CLinearSpawnerDef::Load(TiXmlElement *root)
{
	TiXmlElement *el=NULL;
	el = root->FirstChildElement("name");
	mName = std::string(el->GetText());

	mLoaded = true;
	return true;
}

CLinearSpawner::CLinearSpawner(CLinearSpawnerDef *def, const std::string &actorType, const std::string &actorName, float x, float y, float delay)
: CActor(def), mX(x), mY(y)
{
	mElapsed = (float)(rand())/RAND_MAX;
	mDelay = delay;

	mFlags = ACTOR_FRIDGE;
	mSprite = NULL;

	mActorType = actorType;
	mActorName = actorName;
}

CLinearSpawner::~CLinearSpawner(void)
{

}

bool CLinearSpawner::Update(float dt)
{
	mElapsed += dt;
	if (mElapsed > mDelay)
	{
		//only spawn if the world at that point is empty
		b2AABB a;
		a.lowerBound = b2Vec2(mX - 0.1f, mY - 0.1f);
		a.upperBound = b2Vec2(mX + 0.1f, mY + 0.1f);
		b2Shape**shapes = new b2Shape*[1];
		int numShapes = CPhysicsManager::GetSingleton().GetPhysicsWorld()->Query(a, shapes, 1);
		
		if (numShapes == 0)
		{
			mElapsed = 0;
			CActorFactory::GetSingleton().Create(mActorType, mActorName, mX, mY);
		}
		else
		{
			mElapsed -= 1.f;
		}
	}

	return true;
}