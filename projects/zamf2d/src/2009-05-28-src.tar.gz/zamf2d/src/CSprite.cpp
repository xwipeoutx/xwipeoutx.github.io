#include "CSprite.h"

#include "utils.h"

using namespace ZAMF;

CSprite::CSprite(std::string filename, 
			  float width, float height, 
			  int numStates, int framesPerState, float fps, int initialState)
: mWidth(width), mHeight(height), 
mNumStates(numStates), mFramesPerState(framesPerState), 
mFPS(fps), mState(initialState), mFrame(0)
{
	
	//Create a surface for the image
	SDL_Surface *surface = ZAMF::ImageLoad(filename);
	if (surface == NULL) throw("Failed to load image");
	mTexId = SDL_GL_SurfaceToTexture(surface);
	SDL_FreeSurface(surface);

	//generate display lists
	GLuint numFrames = mNumStates*mFramesPerState;
	mDisplayListIds = glGenLists(numFrames);

	float dx = 1.f / mFramesPerState;
	float dy = 1.f / mNumStates;

	for (GLuint i=0; i<numFrames; i++)
	{
		float x = dx * (i % mFramesPerState);
		float y = dy * (i/mFramesPerState);
		int displayList = i + mDisplayListIds;
		
		glNewList(displayList, GL_COMPILE);
		glBegin(GL_QUADS);
			glTexCoord2f(x, y);
			glVertex3f( -0.5f*mWidth, -0.5f*mHeight, 0 );

			glTexCoord2f(x+dx,y);
			glVertex3f(  0.5f*mWidth,  -0.5f*mHeight, 0 ); 

			glTexCoord2f(x+dx,y+dy);
			glVertex3f(  0.5f*mWidth,   0.5f*mHeight, 0 ); 

			glTexCoord2f(x,y+dy);
			glVertex3f( -0.5f*mWidth,  0.5f*mHeight, 0 ); 
		glEnd();
		glEndList();
		checkGLError("Creating Lists");

	}
}

CSprite::CSprite(CSprite *other)
{
	mTexId = other->mTexId;
	mWidth = other->mWidth;
	mHeight = other->mHeight;
	mNumStates = other->mNumStates;
	mFramesPerState = other->mFramesPerState;
	mFPS = other->mFPS;
	mFrame = other->mFrame;
	mState = other->mState;
	mDisplayListIds = other->mDisplayListIds;
}

CSprite::~CSprite(void)
{
	return;
	/*
	std::map<std::string, std::pair<int, GLuint> >::iterator it;
	it = sSpriteAllocations.find(mFilename);
	if (it != sSpriteAllocations.end())
	{
		if(--it->second.first == 0)
		{
			//delete the texture and iterator
			glDeleteTextures(1, &mTexId);
			sSpriteAllocations.erase(it);
		}
	}
	*/
}


void CSprite::AdvanceFrame(float dt)
{
	mFrame += dt*mFPS;
	if (mFrame > mFramesPerState) mFrame = 0;
}

void CSprite::Draw()
{
	glBindTexture(GL_TEXTURE_2D,mTexId);
	GLuint offset = 0;
	offset += (GLuint)(mFrame);
	offset += mState*mFramesPerState;

	glCallList(mDisplayListIds+offset);
}