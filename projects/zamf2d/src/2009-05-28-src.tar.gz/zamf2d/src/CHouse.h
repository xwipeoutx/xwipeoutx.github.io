#pragma once
#include <list>
#include <string>
#include "Box2D.h"

#include "CActor.h"
#include "CPhysicsDebugDraw.h"
#include "sdlinc.h"

namespace ZAMF
{
	class CHouse : public b2ContactListener
	{
	public:
		//construction stuff
		CHouse();
		~CHouse(void);

		void Build(std::string house);
		void Wreck();
		void BuildHouseFrame(float x, float y, float w, float h);
		void AddStructure(float x, float y, float w, float h);

		//actor stuff
		std::list<CActor *> GetActors(){return mActors;}
		void RegisterActor(CActor *actor);
		void UnregisterActor(CActor *actor);
		bool CollidesWith(const CActor *actor, CActor::ActorFlags flags=CActor::ACTOR_ALL);
		
		//xform stuff
		b2Vec2 PixelToWorld(int x, int y);
		void WorldToPixel(const b2Vec2 &pos, int *x, int *y);

		//event stuff
		virtual void HandleEvents(const SDL_Event &e);
		virtual bool Update(float dt);
		virtual void Draw();

		//physics stuff
		b2World *GetPhysicsWorld(){return mPhysicsWorld;}
		bool IsInBounds(const Box &box);
		void Add(const b2ContactPoint *point);

		//singletonish stuff
		static CHouse *Get()
		{
			return mInstance;
		}
	private:
		Box mBox;
		static CHouse *mInstance;
		bool mEnableDebugDrawing;
		bool mEnableActorDrawing;

		std::list<CActor *> mActors;

		b2World *mPhysicsWorld;
		CPhysicsDebugDraw mDebugDraw;

		std::list<b2Body*> mStaticBodies;
		std::list<Box> mStructures;

		std::list< std::pair<CActor*, CActor*> > mCollisions;
	};

};