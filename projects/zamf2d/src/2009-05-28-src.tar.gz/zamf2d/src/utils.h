#pragma once

#include "sdlinc.h"
#include <string>

namespace ZAMF
{
	SDL_Surface *ImageLoad( std::string filename );

	GLuint SDL_GL_SurfaceToTexture(SDL_Surface * surface);

	inline void checkGLError(const char *label)
	{
		GLenum errCode;
		const GLubyte *errStr;
		if ((errCode = glGetError()) != GL_NO_ERROR)
		{
			errStr = gluErrorString(errCode);
			exit(1);
		}
	}

	void CheckXMLSuccessAttribute(int success);
};