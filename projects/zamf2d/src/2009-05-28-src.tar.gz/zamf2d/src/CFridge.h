#pragma once
#include "CActor.h"

namespace ZAMF
{
	class CFridgeDef : public CActorDef
	{
	public:
		CFridgeDef();
		bool Load(TiXmlElement *root);

		std::string mSpriteFilename;
	};

	class CFridge :	public CActor
	{
	public:

		CFridge(CFridgeDef *def, float x, float y, float w, float h);
		~CFridge(void);

		void Draw();
	};
};