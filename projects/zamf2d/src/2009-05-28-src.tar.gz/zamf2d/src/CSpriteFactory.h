#pragma once

#include "CSprite.h"
#include "tinyxml.h"
#include <map>

namespace ZAMF
{

	class CSpriteFactory
	{
	public:
		CSpriteFactory(void);
		~CSpriteFactory(void);

		CSprite *Load(std::string name, std::string filename, float width, float height, int numStates=1, int framesPerState=1, float fps=1, int initialState=0);
		CSprite *Load(std::string name, TiXmlElement *spriteNode);
		CSprite *Get(std::string name);

		//singletonish stuff
		static CSpriteFactory *Get()
		{
			return mInstance;
		}
	private:
		std::map<std::string, CSprite* > mSprites;
		
		static CSpriteFactory *mInstance;
	};
};