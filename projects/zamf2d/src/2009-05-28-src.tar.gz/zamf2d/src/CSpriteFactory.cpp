#include "CSpriteFactory.h"

#include "utils.h"
#include "tinyxml.h"

using namespace ZAMF;

ZAMF::CSpriteFactory *ZAMF::CSpriteFactory::mInstance=NULL;

CSpriteFactory::CSpriteFactory(void)
{

	mInstance = this;
}

CSpriteFactory::~CSpriteFactory(void)
{

	mInstance = NULL;
}


CSprite *CSpriteFactory::Load(std::string name, std::string filename,
					   float width, float height,
					   int numStates, int framesPerState, float fps, int initialState)
{
	//check it doesn't already exist
	std::map<std::string, CSprite* >::iterator it;
	it = mSprites.find(name);
	if (it != mSprites.end())
		return it->second;

	CSprite *sprite = new CSprite(filename, width, height, numStates, framesPerState, fps, initialState);
	mSprites[name] = sprite;
	return sprite;
}

CSprite *CSpriteFactory::Load(std::string name, TiXmlElement *spriteNode)
{
	//check it doesn't already exist
	std::map<std::string, CSprite* >::iterator it;
	it = mSprites.find(name);
	if (it != mSprites.end())
		return it->second;

	//load it
	float w=0, h=0;
	int columns, rows, initialState;
	float fps=0;
	TiXmlElement *el;

	//dimensions (in all sprites)
	CheckXMLSuccessAttribute( spriteNode->QueryFloatAttribute("width", &w) );
	CheckXMLSuccessAttribute( spriteNode->QueryFloatAttribute("height", &h) );
	el = spriteNode->FirstChildElement("image");
	std::string filename(el->Attribute("filename"));

	//animation (not in all sprites)
	el = spriteNode->FirstChildElement("animation");
	if (el)
	{
		CheckXMLSuccessAttribute( el->QueryIntAttribute("columns", &columns) );
		CheckXMLSuccessAttribute( el->QueryIntAttribute("rows", &rows) );
		CheckXMLSuccessAttribute( el->QueryFloatAttribute("fps", &fps) );
		CheckXMLSuccessAttribute( el->QueryIntAttribute("initialstate", &initialState) );
		return Load(name, filename, w, h, rows, columns, fps, initialState);
	}
	else
	{
		//load without animation
		return Load(name, filename, w, h);
	}
}

CSprite *CSpriteFactory::Get(std::string name)
{
	//check it doesn't already exist
	std::map<std::string, CSprite* >::iterator it;
	it = mSprites.find(name);
	if (it == mSprites.end())
		return NULL;

	//make a copy
	return new CSprite(it->second);
}
