#pragma once

#include "CTimer.h"
#include "sdlinc.h" 

namespace ZAMF
{
	class CGameWindow
	{
	public:
		CGameWindow(void);
		~CGameWindow(void);
		
		void HandleEvents(const SDL_Event &event);
		bool Update(float dt){return true;}
		void StartFrame();
		void EndFrame();


		//Accessors / Mutators
		bool IsWindowed(){return mWindowed;}
		void ToggleFullScreen();
		const SDL_Surface *GetScreen(){return mScreen;}

		int GetWidth(){return mWidth;}
		int GetHeight(){return mHeight;}

		static CGameWindow *Get()
		{
			return mInstance;
		}
		static void Destroy()
		{
			if (mInstance != NULL)
				delete mInstance;
		}

		
		static const int SCREEN_WIDTH = 640;
		static const int SCREEN_HEIGHT = 480;
		static const int SCREEN_BPP = 32;

	private:
		static CGameWindow *mInstance;

		bool mWindowed;
		bool mWindowOK;
		SDL_Surface *mScreen;

		int mWidth;
		int mHeight;

		CTimer mFPSTimer;
		int mFrame;

	};
};