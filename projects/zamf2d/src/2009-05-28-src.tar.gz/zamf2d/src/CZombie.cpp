#include "CZombie.h"
#include "CHouse.h"
#include "CNail.h"

#include "tinyxml.h"
#include "utils.h"

#include <fstream>
#include <string>

using namespace ZAMF;
using namespace std;

bool CZombieDef::Load(TiXmlElement *root)
{
	CActorDef::Load(root);

	TiXmlElement *el=NULL;
	// block: behaviour
	TiXmlElement *behaviourRootNode = root->FirstChildElement("behaviour");

	//movement
	el = behaviourRootNode->FirstChildElement("movement");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("xvel", &xVel) );

	//physics
	el = behaviourRootNode->FirstChildElement("physics");
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("density", &density) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("friction", &friction) );
	CheckXMLSuccessAttribute( el->QueryFloatAttribute("restitution", &restitution) );
	return true;
}

CZombie::CZombie(CZombieDef *def, float x, float y)
: CActor(def)
{
	mFlags = ACTOR_ENEMY;

	CZombieDef def2 = *def;
	mDef = def2;

	/*
	mSprite = new CSprite(def->imageFile.c_str(),
		def->w, def->h, def->numStates, def->framesPerState, def->fps, def->initialDir);
	*/
	//add to physics world
	b2BodyDef bodyDef;
	bodyDef.position.Set(x, y);
	bodyDef.fixedRotation = true;
	bodyDef.linearDamping = 0.0f;
	bodyDef.angularDamping = 0.0f;
	mBody = CHouse::Get()->GetPhysicsWorld()->CreateBody(&bodyDef);

	b2PolygonDef shapeDef;
	shapeDef.SetAsBox(0.5f*mSprite->GetWidth(), 0.5f*mSprite->GetHeight());
	shapeDef.density = def->density;
	shapeDef.friction = def->friction;
	shapeDef.restitution = def->restitution;
	shapeDef.filter.categoryBits = ACTOR_ENEMY;
	shapeDef.filter.maskBits = ACTOR_ENEMY | ACTOR_PLAYER | ACTOR_FRIDGE | ACTOR_PROJECTILE | ACTOR_STATIONARY;
	shapeDef.userData = this;
	mBody->CreateShape(&shapeDef);
	mBody->SetMassFromShapes();

	//mBody->ApplyImpulse(b2Vec2(2, 0), b2Vec2(0,0));
	//mBody->SetLinearVelocity(b2Vec2(ZOMBIE_SPEEDX, 0));
}

CZombie::~CZombie(void)
{
	CHouse::Get()->GetPhysicsWorld()->DestroyBody(mBody);
	mBody = NULL;
	delete mSprite;
}

bool CZombie::Update(float dt)
{
	//well all we have to make sure about now is the zombie is moving...let's try it
	b2Vec2 linVel = mBody->GetLinearVelocity();
	if (linVel.x > 0)
	{
		mSprite->SetState(1);
		//mBody->ApplyForce(b2Vec2(ZOMBIE_SPEEDX*0.1f - inertia, 0), b2Vec2_zero);
		mBody->SetLinearVelocity(b2Vec2(mDef.xVel, linVel.y));

	} else if (linVel.x < 0) {
		mSprite->SetState(0);
		//mBody->ApplyForce(b2Vec2(inertia - ZOMBIE_SPEEDX*0.1f, 0), b2Vec2_zero);
		mBody->SetLinearVelocity(b2Vec2(-mDef.xVel, linVel.y));
	} else {
		if (mSprite->GetState()==1)
			mBody->SetLinearVelocity(b2Vec2(mDef.xVel, linVel.y));
		else
			mBody->SetLinearVelocity(b2Vec2(-mDef.xVel, linVel.y));
		//mBody->ApplyForce(b2Vec2(1 - inertia, 0), b2Vec2_zero);
	}
	mSprite->AdvanceFrame(dt);

	return true;
}
void CZombie::Draw()
{
	glPushMatrix();

	b2Vec2 pos = mBody->GetPosition();
	float angle = mBody->GetAngle();

	glTranslatef(pos.x, pos.y, 0);
	glRotatef(angle*180/3.14159f, 0,0,1);
	mSprite->Draw();
	glPopMatrix();
}

//contact points
void CZombie::Collide(CActor *other)
{
	if (other != NULL && other->GetFlags() & ACTOR_PROJECTILE)
	{
		CNail *nail = dynamic_cast<CNail*>(other);
		if (!nail->GetDestroyed())
			mDying = true;
	}
}
