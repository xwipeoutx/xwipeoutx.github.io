#include "sdlinc.h" 

#include <fstream>
#include <deque>

#include "CHouse.h"
#include "CActorFactory.h"
#include "CSpriteFactory.h"
#include "CTimer.h"
#include "CGameWindow.h"

namespace ZAMF
{
	bool InitGL()
	{
		glClearColor(0.5,0.5,0.5,0);

		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		glOrtho(0, 1, 0, 1, -1, 1);

		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		//enable stuff/settings
		glEnable(GL_TEXTURE_2D);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		if (glGetError() != GL_NO_ERROR)
			return false;
		return true;
	}

	bool Init()
	{
		if (SDL_Init(SDL_INIT_VIDEO) != 0)
			return false;

		new CGameWindow();
		if ((InitGL()) == false) return false;

		return true;
	}

	int Start()
	{
		if (!Init()) return 1;

		CGameWindow *window = CGameWindow::Get();
		new CActorFactory();
		new CSpriteFactory();

		CHouse *house = new CHouse();
		house->Build("house");

		CTimer deltaTimer;
		deltaTimer.Start();

		bool running = true;

		std::deque< CActor* >::iterator it;
		while(running)
		{
			SDL_Event ev;
			//handle events
			while (SDL_PollEvent (&ev))
			{
				window->HandleEvents(ev);
				house->HandleEvents(ev);
		
				
				if (ev.type == SDL_KEYDOWN)
				{
					switch (ev.key.keysym.sym)
					{
					case SDLK_z:
						CActorFactory::Get()->CreateZombie(2.f,12.f);
						break;
					case SDLK_ESCAPE:
					case SDLK_q:
						running = false;
						break;
					default:
						break;
					}
				}
			}
			//SDL_Delay(1);
			//get the loop delta time
			int numTicks = deltaTimer.GetTicks();
			deltaTimer.Start();
			float dt = 0.001f * numTicks;
			
			
			window->StartFrame();

			//update all actors here - inside frame, so physics debugging works
			window->Update(dt);
			house->Update(dt);
			
			//draw all actors
			house->Draw();
			window->EndFrame();

			if (ev.type == SDL_QUIT)
				running = false;
		}
		house->Wreck();
		delete house;

		delete CSpriteFactory::Get();
		delete CActorFactory::Get();
		CGameWindow::Destroy();

		return 0;
	}
};

int StartZAMF2D(int argc, char *argv[])
{
	int ret;
	try
	{
	ret = ZAMF::Start();
	} 
	catch (char *ex) 
	{
		std::ofstream exLog("exception.log");
		exLog << ex;
		exLog.close();
		ret = 1;
	}
	return ret;
}