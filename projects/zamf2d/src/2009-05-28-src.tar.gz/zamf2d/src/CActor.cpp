#include "CActor.h"
#include "CHouse.h"
#include "CSpriteFactory.h"

using namespace ZAMF;

CActor::CActor(CActorDef *def)
: mFlags(ACTOR_NONE), mDying(false)
{
	CHouse::Get()->RegisterActor(this);
	if(def != NULL)
		mSprite = CSpriteFactory::Get()->Get(def->mName);
}

CActor::~CActor(void)
{
	CHouse::Get()->UnregisterActor(this);
}

CActorDef::CActorDef()
 :mLoaded(false),mName("")
{
}

bool CActorDef::Load(TiXmlElement *root)
{
	mName = std::string(root->FirstChildElement("name")->GetText());
	CSpriteFactory::Get()->Load(mName, root->FirstChildElement("sprite"));

	mLoaded = true;
	return true;
}