#pragma once

#include "CActor.h"

namespace ZAMF
{
	#define ZOMBIE_FACING_LEFT 0
	#define ZOMBIE_FACING_RIGHT 1

	class CZombieDef : public CActorDef
	{
	public:
		bool Load(TiXmlElement *root);

		float xVel;
		int initialDir;
		float density, friction, restitution;
	};


	class CZombie :	public CActor
	{
	public:
		CZombie(CZombieDef *def, float x, float y);
		~CZombie(void);

		bool Update(float dt);
		void Draw();
		void Collide(CActor *other);

	private:
		CZombieDef mDef;
	};
};
