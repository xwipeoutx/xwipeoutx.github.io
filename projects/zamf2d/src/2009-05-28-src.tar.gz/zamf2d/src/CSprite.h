#pragma once

#include "tinyxml.h"
#include "sdlinc.h"
#include <string>

namespace ZAMF
{
	class CSprite
	{
	public:
		CSprite(std::string filename, float width, float height, int numStates=1, int framesPerState=1, float fps=1, int initialState=0);
		CSprite(CSprite *other);
		~CSprite(void);

		inline GLuint GetTexId(){return mTexId;}
		void AdvanceFrame(float dt);
		inline void ResetFrame(){mFrame=0;};

		inline void SetState(int state){mState = state;}
		inline int GetState(){return mState;}
		void Draw();

		float GetWidth(){return mWidth;}
		float GetHeight(){return mHeight;}

	protected:
		CSprite(){}

	private:
		//std::string mFilename;
		GLuint mTexId;
		float mWidth;
		float mHeight;
		int mNumStates;
		int mFramesPerState;
		float mFPS;

		int mState;
		float mFrame;
		int mDisplayListIds;

	};
}
