#pragma once

#include "structures.h"

namespace ZAMF
{
	bool CheckCollisionBoxBox(const Box &A, const Box &B);
};