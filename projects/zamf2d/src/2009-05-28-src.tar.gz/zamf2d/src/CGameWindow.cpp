#include "CGameWindow.h"

#include "CTimer.h"
#include "sdlinc.h" 
#include <sstream>

using namespace ZAMF;
CGameWindow *CGameWindow::mInstance = NULL;
CGameWindow::CGameWindow(void)
{
	mWidth = SCREEN_WIDTH;
	mHeight = SCREEN_HEIGHT;
	mScreen = SDL_SetVideoMode(mWidth, mHeight, SCREEN_BPP, SDL_OPENGL | SDL_RESIZABLE | SDL_GL_ACCELERATED_VISUAL);

	if (mScreen == NULL)
	{
		mWindowOK = false;
		return;
	}
	mWindowOK = true;
	
	SDL_WM_SetCaption("ZAMF 2D", NULL);
	mWindowed = true;

	mFPSTimer.Start();
	mFrame = 0;

	CGameWindow::mInstance = this;
}

CGameWindow::~CGameWindow(void)
{
	CGameWindow::mInstance = NULL;
	SDL_FreeSurface(mScreen);
}

void CGameWindow::HandleEvents(const SDL_Event &e)
{
	if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_RETURN)
	{
		//this->ToggleFullScreen();
	}
}

void CGameWindow::ToggleFullScreen()
{
	if (mWindowed)
	{
		mScreen = SDL_SetVideoMode(mWidth, mHeight, SCREEN_BPP, SDL_OPENGL | SDL_RESIZABLE | SDL_FULLSCREEN);
		if (mScreen == NULL)
		{
			mWindowOK = false;
			return;
		}
		mWindowed = false;
	}
	else
	{	
		mScreen = SDL_SetVideoMode(mWidth, mHeight, SCREEN_BPP, SDL_OPENGL | SDL_RESIZABLE);

		if (mScreen == NULL)
		{
			mWindowOK = false;
			return;
		}
		mWindowed = true;
	}
}

void CGameWindow::StartFrame()
{
	glClear(GL_COLOR_BUFFER_BIT);	
}

void CGameWindow::EndFrame()
{
	//glFinish();
	SDL_GL_SwapBuffers();

	//framerate
	mFrame++;
	if (mFPSTimer.GetTicks() > 1000)
	{
		float fps = 1000.0f*mFrame/mFPSTimer.GetTicks();
		mFrame = 0;
		mFPSTimer.Start();
		
		std::ostringstream caption;
		caption << "ZAMF 2D - FPS: " << fps;
		SDL_WM_SetCaption(caption.str().c_str(), NULL);

	}

}