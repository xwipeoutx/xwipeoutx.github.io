#include "CBank.h"

using namespace Ogre;
template<> CBank* Singleton<CBank>::ms_Singleton = 0;

CBank::CBank(void)
{

}

CBank::~CBank(void)
{

}
