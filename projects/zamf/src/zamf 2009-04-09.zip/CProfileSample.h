#pragma once

#include <Ogre.h>

class IProfilerOutputHandler;

#define MAX_PROFILER_SAMPLES 50

//uncomment following line to disable profiling
//#define ZAMF_NO_PROFILE 1
#ifndef ZAMF_NO_PROFILE
	#define PROFILE_THIS(var) CProfileSample profile(var);
#else
	#define PROFILE_THIS(var)
#endif

class CProfileSample
{
public:
	CProfileSample(std::string sampleName);
	~CProfileSample(void);
	
	static void Output();
	
	static void ResetSample(std::string sampleName);
	static void ResetAll();
	
	static IProfilerOutputHandler *outputHandler;
	
protected:
	//index into the array of samples
	int iSampleIndex;
	int iParentIndex;
	
	inline static float GetTime() {
		return 0.000001 * Ogre::Root::getSingleton().getTimer()->getMicroseconds();
	} //TODO windows only
	
	static struct profileSample
	{
	
		profileSample()
		{
			bIsValid = false;
			dataCount = 0;
			averagePc = minPc = maxPc = -1;
		}
		
		bool bIsValid; //whether or not this sample is valid and ready to use
		bool bIsOpen;	//is the sample being profiled?
		unsigned int callCount; //number of times this sample has been executed, this frame
		std::string name; //name of this sample
		
		float startTime; //starting time on the clock, in seconds
		float totalTime; //total time recorded across all executions of this sample, this frame
		float childTime; //total time taken by children of this sample, this frame
		
		int parentCount; //number of parents this sample has (useful for neat indenting)
		
		float averagePc; //average percentage of game loop time taken up
		float minPc; //minimum percentage of game loop time taken up
		float maxPc; //maximum percentage of game loop time taken up
		unsigned long dataCount; //number of times values have been stored since
								//sample creation/reset
		
	} samples[MAX_PROFILER_SAMPLES];
	static int lastOpenedSample;
	static int openSampleCount;
	static float rootBegin, rootEnd;
	
};