#pragma once

class ILevel;

namespace Ogre{
	class SceneManager;
};

class CLevelLoader
{
public:
	CLevelLoader(Ogre::SceneManager *mgr);
	~CLevelLoader(void);

	void Load(int level);
	ILevel *GetCurrentLevel();

private:
	ILevel *level;

	Ogre::SceneManager *mSceneMgr;
};
