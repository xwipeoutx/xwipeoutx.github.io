#include "CMessageBroadcaster.h"

#include "IMessageHandler.h"
#include "CInputManager.h"

#include "CProfileSample.h"

using namespace Ogre;

template<> CMessageBroadcaster* Singleton<CMessageBroadcaster>::ms_Singleton;

CMessageBroadcaster::CMessageBroadcaster(CInputManager *inputManager)
: mTimeIsGoing(true)
{
	inputManager->getKeyboard()->setEventCallback(this);
	inputManager->getMouse()->setEventCallback(this);

	Root::getSingletonPtr()->addFrameListener(this);
}

CMessageBroadcaster::~CMessageBroadcaster(void)
{
	//mainly doing this for log messages
	refreshMessageHandlerList();
}

bool CMessageBroadcaster::keyClicked(const OIS::KeyEvent &e)
{
	dispatch(MT_CLICK, e);
	return true;
}

bool CMessageBroadcaster::keyPressed(const OIS::KeyEvent &e)
{
	dispatch(MT_DOWN, e);
	return true;
}

bool CMessageBroadcaster::keyReleased(const OIS::KeyEvent &e)
{
	dispatch(MT_UP, e);
	return true;
}

bool CMessageBroadcaster::mouseMoved(const OIS::MouseEvent &e)
{
	dispatchMouse(MT_NONE, MID_NONE, e);
	return true;
}
bool CMessageBroadcaster::mousePressed(const OIS::MouseEvent &e, OIS::MouseButtonID button)
{
	dispatchMouse(MT_DOWN, mbToMessageId(button), e);
	return true;
}
bool CMessageBroadcaster::mouseReleased(const OIS::MouseEvent &e, OIS::MouseButtonID button)
{
	dispatchMouse(MT_UP, mbToMessageId(button), e);
	return true;
}


void CMessageBroadcaster::attach(IMessageHandler *messageHandler, const Ogre::String &instanceName)
{
	Ogre::LogManager::getSingleton().logMessage("Message Handler: Attaching " + instanceName);
	messageHandler->setTimeIsGoing(mTimeIsGoing);
	mNewMessageHandlers.insert(std::make_pair<String, IMessageHandler*>(instanceName, messageHandler));
	//messageHandler->AddRef();
}


void CMessageBroadcaster::detach(const Ogre::String &instanceName)
{
	Ogre::LogManager::getSingleton().logMessage("Message Handler: Detaching " + instanceName);
	mDeletedMessageHandlers.push_back(instanceName);
}


bool CMessageBroadcaster::frameStarted(const Ogre::FrameEvent &evt)
{
	PROFILE_THIS("CMessageBroadcaster::frameStarted");

	//capture input
	CInputManager::getSingleton().getMouse()->capture();
	CInputManager::getSingleton().getKeyboard()->capture();

	refreshMessageHandlerList();

	//'tick' each message handler
	Real dt = 0.000001 * mTimer.getMicroseconds();
	mTimer.reset();
	if (!mMessageHandlers.empty())
	for (itMessageHandler = mMessageHandlers.begin(); itMessageHandler != mMessageHandlers.end(); ++itMessageHandler)
	{
		(*itMessageHandler).second->tick(dt);
	}
	
	return true;
}

void CMessageBroadcaster::inject(MESSAGE_TYPE type, MESSAGE_ID id)
{
	std::map<Ogre::String, CMMPointer<IMessageHandler> >::iterator it = itMessageHandler;
	
	dispatch(type, id);

	if (id == MID_APP_QUIT)
	{
		itMessageHandler = mMessageHandlers.end();
		if (!mMessageHandlers.empty())
			itMessageHandler--;
	}
	else
	{
		itMessageHandler = it;
	}
}

void CMessageBroadcaster::dispatch(MESSAGE_TYPE type, MESSAGE_ID id)
{
	if (mMessageHandlers.empty()) return;
	itMessageHandler = mMessageHandlers.begin();
	for (; itMessageHandler != mMessageHandlers.end(); ++itMessageHandler)
	{
#ifdef DEBUG_VERBOSE
		Ogre::String msg = "(v) CMessageBroadcaster::dispatch() on ";
		msg += (*itMessageHandler).first;
		Ogre::LogManager::getSingleton().logMessage(msg);
#endif

		if (id == MID_STOP_TIME)
			(*itMessageHandler).second->setTimeIsGoing(false);
		
		if (id == MID_RESTART_TIME)
			(*itMessageHandler).second->setTimeIsGoing(true);

		(*itMessageHandler).second->handleMessage(type, id);
	}
}

void CMessageBroadcaster::dispatchMouse(MESSAGE_TYPE type, MESSAGE_ID id, const OIS::MouseEvent &evt)
{
	if (mMessageHandlers.empty()) return;

	itMessageHandler = mMessageHandlers.begin();
	for (; itMessageHandler != mMessageHandlers.end(); ++itMessageHandler)
	{
		(*itMessageHandler).second->handleMouseMessage(type, id, evt);
	}
}

void CMessageBroadcaster::dispatch(MESSAGE_TYPE type, const OIS::KeyEvent &evt)
{
	switch (evt.key)
	{
	//movement
	case OIS::KC_W:
		dispatch(type, MID_WALK_FORWARD);
		break;
	case OIS::KC_S:
		dispatch(type, MID_WALK_BACKWARD);
		break;
	case OIS::KC_A:
		dispatch(type, MID_STRAFE_LEFT);
		break;
	case OIS::KC_D:
		dispatch(type, MID_STRAFE_RIGHT);
		break;

	//run mode
	case OIS::KC_LSHIFT:
		dispatch(type, MID_RUN);
		break;
	case OIS::KC_CAPITAL:
		dispatch(type, MID_TOGGLE_RUN);
		break;

	//actions
	case OIS::KC_SPACE:
		dispatch(type, MID_SHOOT);
		break;

	//weapon selects
	case OIS::KC_1:
		dispatch(type, MID_WEAPON_TURRET);
		break;
	case OIS::KC_2:
		dispatch(type, MID_WEAPON_MAGNET);
		break;
	case OIS::KC_3:
		dispatch(type, MID_WEAPON_BOWL);
		break;

	//other
	case OIS::KC_PAUSE:
		dispatch(type, MID_PAUSE);
		break;

	//menu actions
	case OIS::KC_RETURN:
		dispatch(type, MID_MENU_CONFIRM);
		break;
	case OIS::KC_ESCAPE:
		dispatch(type, MID_MENU_CANCEL);
		dispatch(type, MID_MENU);
		break;

	//debug actions
	case OIS::KC_GRAVE:
		dispatch(type, MID_TOGGLE_CONSOLE);
		break;
	case OIS::KC_F3:
		dispatch(type, MID_DBG_DRAW_PHYSICS_BOUNDS);
		break;
	case OIS::KC_F5:
		dispatch(type, MID_DBG_CLEAR_PROFILE);
		break;
	case OIS::KC_F6:
		dispatch(type, MID_DBG_PRINT_PROFILE);
		break;

	default:
		break;
	}
}


MESSAGE_ID CMessageBroadcaster::mbToMessageId(const OIS::MouseButtonID &id)
{
	switch (id)
	{
	case OIS::MB_Left:
		return MID_SHOOT;
	default:
		break;
	}

	return MID_NONE;
}

void CMessageBroadcaster::refreshMessageHandlerList()
{
	IMessageHandler *tmp = NULL;
	//clear out deleted message handlers
	for (std::list<Ogre::String>::iterator it=mDeletedMessageHandlers.begin(); it != mDeletedMessageHandlers.end(); ++it)
	{
		if (mMessageHandlers.find(*it) != mMessageHandlers.end())
		{
			//mMessageHandlers.find(*it)->second->Release();
			mMessageHandlers.erase(*it);
			Ogre::LogManager::getSingleton().logMessage("Message Handler: Detached " + *it);
		}
		else
		{
			Ogre::LogManager::getSingleton().logMessage("WARNING: Message Handler: Detaching " + *it + " failed - not found");
		}
	}
	mDeletedMessageHandlers.clear();

	//add new message handlers
	for (itMessageHandler = mNewMessageHandlers.begin(); itMessageHandler != mNewMessageHandlers.end(); ++itMessageHandler)
	{
		if (mMessageHandlers.find(itMessageHandler->first) == mMessageHandlers.end())
		{
			mMessageHandlers[itMessageHandler->first] = itMessageHandler->second;
			Ogre::LogManager::getSingleton().logMessage("Message Handler: Attached " + itMessageHandler->first);
		}
		else
		{
			Ogre::LogManager::getSingleton().logMessage("WARNING: Message Handler: Attaching " + itMessageHandler->first + " failed - duplicate");
		}
	}
	mNewMessageHandlers.clear();

}