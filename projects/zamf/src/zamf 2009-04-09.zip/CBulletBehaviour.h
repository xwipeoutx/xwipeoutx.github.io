#pragma once
#include "IMessageHandler.h"

class CBulletPhysicsResponse;

namespace Ogre
{
	class Vector3;
	class SceneNode;
	class SceneManager;
}
class btRigidBody;
class btCollisionShape;

class CBulletBehaviour : public IMessageHandler
{
public:
	CBulletBehaviour(Ogre::SceneManager *sm);
	virtual ~CBulletBehaviour(void);

	void fireBullet(Ogre::Vector3 origin, Ogre::Vector3 direction, Ogre::Real range=40);

	bool tick(float dt);

	IMM_AUTO_SIZE;

	struct BulletBehaviour
	{
		Ogre::SceneNode *bulletNode;
		Ogre::Vector3 direction;
		Ogre::Real range;

		btRigidBody *physObject;
		CBulletPhysicsResponse *physResponse;

		bool dying;
	};

protected:
	Ogre::SceneManager *mSceneMgr;

	std::list<BulletBehaviour*> *mBullets;
	std::list<BulletBehaviour*> *mBulletPool;
	int mNumBullets;
	int mNumPooledBullets;

	int mNumBulletsSpawned;
	int mNumBulletsDestroyed;
	int mNumBulletsMissed;

	//constant stuff
	btCollisionShape *mBulletShape;

	//functions
	std::list<BulletBehaviour*>::iterator DrownBullet(std::list<BulletBehaviour*>::iterator it);

	//settings
	float mInitialSpeed;
	float mMass;
	float mFriction;
	float mRestitution;
	float mDeactivationTime;
	float mCCDMotionThreshold;
};
