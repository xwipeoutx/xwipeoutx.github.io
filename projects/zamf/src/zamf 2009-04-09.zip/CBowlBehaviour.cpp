#include "CBowlBehaviour.h"
#include "CProfileSample.h"
#include "CPhysicsManager.h"
#include "CMagnetBehaviour.h"

#include "btOgreGP.h"
#include "btOgrePG.h"

#include <Ogre.h>
#include "constants.h"

using namespace Ogre;

CBowlBehaviour::CBowlBehaviour(SceneManager *mgr, CMagnetBehaviour *mb)
: mSceneMgr(mgr)
{
	mBowlShape = new btSphereShape(0.49);
	mMagnetBehaviour = mb;
}

CBowlBehaviour::~CBowlBehaviour(void)
{
	for(std::list<Bowl*>::iterator it=mBowls.begin();it!=mBowls.end();++it)
	{
		CPhysicsManager::getSingleton().getWorld()->removeCollisionObject((*it)->rigidBody);
		delete (*it)->rigidBody->getUserPointer();
	}
	mBowls.clear();
}

bool CBowlBehaviour::tick(float dt)
{
	//attract to magnet
	std::list<CMagnetBehaviour::Magnet *> &magnets = mMagnetBehaviour->getMagnets();

	for(std::list<Bowl *>::iterator itb=mBowls.begin();itb!=mBowls.end();++itb)
	{
		Vector3 bowlPos = (*itb)->node->getPosition();
		for(std::list<CMagnetBehaviour::Magnet *>::iterator itm=magnets.begin();itm!=magnets.end();++itm)
		{
			if ((*itm)->isActive)
			{
				//get distance between
				Vector3 magnetPos = (*itm)->node->getPosition();
				Vector3 diff = magnetPos - bowlPos;
				Real dist2 = diff.squaredLength();
				diff *= 5;// (mass)
				diff *= 200;
				btVector3 &d = BtOgre::Convert::toBullet(diff) / dist2;
				(*itb)->rigidBody->applyCentralForce(d);
				(*itb)->vel = (*itb)->rigidBody->getLinearVelocity();
				(*itb)->rigidBody->activate(true);
			}
		}
	}

	return true;
}

void CBowlBehaviour::addBowl(Ogre::SceneNode *bowlNode)
{
	PROFILE_THIS("Add Bowl");
	Bowl *bowl = new Bowl();
	bowl->node = bowlNode;
	bowlNode->translate(0, 1, 0);

	//create bt Object (physics)
	btTransform transform( 
		BtOgre::Convert::toBullet(bowlNode->getOrientation()), 
		BtOgre::Convert::toBullet(bowlNode->getPosition()));
	btScalar mass = 5;
	btVector3 inertia;
	mBowlShape->calculateLocalInertia(mass, inertia);

	btMotionState *motionState = new BtOgre::RigidBodyState(bowlNode);
	//bb->physResponse = new CBulletPhysicsResponse(bb);
	bowl->rigidBody = new btRigidBody(mass, motionState, mBowlShape, inertia);
	//bb->physObject->setUserPointer((void*)bb->physResponse);
	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(bowl->rigidBody, MVT_PROJECTILE, MVT_ENEMY|MVT_STATIONARY|MVT_TURRET|MVT_PROJECTILE);
	bowl->rigidBody->setGravity(btVector3(0.0,-9.8,0.0));
	bowl->rigidBody->setDeactivationTime(1.0f);

	bowl->rigidBody->setFriction(1.0);
	bowl->rigidBody->setRestitution(0.1);
	bowl->rigidBody->setCcdMotionThreshold(0.49);
	bowl->rigidBody->setUserPointer(new CBowlPhysicsResponse(bowl));
	mBowls.push_back( bowl );	
}

void CBowlBehaviour::clearBowls()
{
	mBowls.clear();
}

void CBowlPhysicsResponse::Collide(IPhysicsResponse *other, btPersistentManifold *contactManifold, int flipFlop)
{
	CMagnetPhysicsResponse *magnet = dynamic_cast<CMagnetPhysicsResponse*>(other);
	if (magnet != NULL)
	{
		this->mBowl->rigidBody->applyForce(
			-this->mBowl->vel * 2000, btVector3(0,0,0)
		);
	}
}