#pragma once

class btPersistentManifold;

class IPhysicsResponse
{
public:
	IPhysicsResponse(void){}
	virtual ~IPhysicsResponse(void){}

	virtual void Collide(IPhysicsResponse *other, btPersistentManifold* contactManifold, int flipFlop)=0;
};
