#pragma once
#include "IPhysicsResponse.h"
#include "CBulletBehaviour.h"

class CBulletPhysicsResponse : public IPhysicsResponse
{
public:
	CBulletPhysicsResponse(CBulletBehaviour::BulletBehaviour *bb);
	virtual ~CBulletPhysicsResponse(void);

	void Collide(IPhysicsResponse *other, btPersistentManifold* contactManifold, int flipFlop);

	CBulletBehaviour::BulletBehaviour *GetBulletBehaviour(){return mBulletBehaviour;}

protected:
	CBulletBehaviour::BulletBehaviour *mBulletBehaviour;
};
