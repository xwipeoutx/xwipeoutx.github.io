#pragma once

#include "IPhysicsResponse.h"
#include "IMessageHandler.h"
#include "LinearMath/btVector3.h"
#include "CMagnetBehaviour.h"

#include <Ogre.h>

//class CMagnetBehaviour;
class btRigidBody;
class btCollisionShape;

class CBowlBehaviour : public IMessageHandler
{
public:
	CBowlBehaviour(Ogre::SceneManager *sm, CMagnetBehaviour *mb);
	virtual ~CBowlBehaviour(void);

	struct Bowl
	{
		btRigidBody *rigidBody;
		Ogre::SceneNode *node;
		btVector3 vel;
	};

	void addBowl(Ogre::SceneNode *bowl);
	void clearBowls();

	bool tick(Ogre::Real dt);
	IMM_AUTO_SIZE;
protected:
	Ogre::SceneManager *mSceneMgr;

	

	std::list<Bowl*> mBowls;
	CMagnetBehaviour *mMagnetBehaviour;

	btCollisionShape *mBowlShape;

private:
};

//physics response object
class CBowlPhysicsResponse : public IPhysicsResponse
{
public:
	CBowlPhysicsResponse(CBowlBehaviour::Bowl *bb)
		: mBowl(bb)
	{
	}

	virtual ~CBowlPhysicsResponse(void)
	{
	}

	void Collide(IPhysicsResponse *other, btPersistentManifold* contactManifold, int flipFlop);

	CBowlBehaviour::Bowl *GetBowl(){return mBowl;}

	IMM_AUTO_SIZE;

protected:
	CBowlBehaviour::Bowl *mBowl;

};