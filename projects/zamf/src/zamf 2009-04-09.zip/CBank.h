#pragma once
#include "Ogre.h"

class CBank : public Ogre::Singleton<CBank>
{
public:
	CBank(void);
	~CBank(void);

	Ogre::Real Withdraw(Ogre::Real cash){return mCash-=cash;}
	Ogre::Real Deposit(Ogre::Real cash){return mCash+=cash;}

	Ogre::Real GetCash(){return mCash;}
	void SetCash(Ogre::Real cash){mCash = cash;}
protected:
	Ogre::Real mCash;
};
