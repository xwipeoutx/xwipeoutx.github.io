#pragma once

#include <cassert>

template<class T>
class CMMPointer
{
protected:
	T* obj;
public:
	// Constructor - basic
	CMMPointer(void)
	{
		obj=0;
	}
	
	// Constructing with a pointer
	CMMPointer(T *o)
	{
		obj=0;
		*this = o;
	}
	
	// Copy constructor
	CMMPointer (const CMMPointer<T> &p)
	{
		obj=0;
		*this=p;
	}
	
	//Destructor
	~CMMPointer(void)
	{
		if (obj) obj->Release();
	}
	
	//Assignement operators - assigning a plain pointer
	inline CMMPointer<T>& operator =(T *o)
	{
		if(obj)obj->Release();
		obj=o;
		if(obj)obj->AddRef();
		return *this;
	}

	//Assigning another smart pointer
	inline CMMPointer<T>& operator =(const CMMPointer<T> &p)
	{
		if(obj)obj->Release();
		obj=p.obj;
		if(obj)obj->AddRef();
		return *this;
	}

	//access as a reference
	inline T& operator *() const
	{
		assert(obj != 0 && "Tried to * on a NULL smart pointer");
		return *obj;
	}

	//access as a pointer
	inline T* operator ->() const
	{
		assert(obj != 0 && "Tried to -> on a NULL smart pointer");
		return obj;
	}
	
	//conversion - convert to T*
	inline operator T*() const
	{
		return obj;
	}
	
	inline bool isValid() const
	{
		return (obj != 0);
	}
	
	inline bool operator !()
	{
		return !(obj);
	}
	
	inline bool operator ==(const CMMPointer<T> &p) const
	{
		return (obj == p.obj);
	}
	
	inline bool operator ==(const T* o) const
	{
		return (obj == o);
	}
};
