#include "CZombieBehaviour.h"
#include "CPhysicsManager.h"
#include "constants.h"
#include "CZombiePhysicsResponse.h"
#include "CBank.h"

#include "CSoundManager.h"
#include "CGameManager.h"
#include "CDeadState.h"
#include "CPlayStateHelper.h"
#include "CProfileSample.h"
#include "CPlayerCamera.h"
#include "CSettings.h"

#include "btOgreGP.h"
#include "BulletCollision/CollisionDispatch/btGhostObject.h"

#include <Ogre.h>
#include <CEGUI/CEGUI.h>

using namespace Ogre;

template<> CZombieBehaviour* Singleton<CZombieBehaviour>::ms_Singleton = 0;

CZombieBehaviour::CZombieBehaviour(SceneManager *mgr)
: mSceneMgr(mgr), mZombieShape(0), mNumSpawned(0), mNumKills(0)
{
	mZombies = new std::list<ZombieAI*>();
	
	mSpeed = CSettings::getSingleton().getFloat("zombieSpeed");
	mWorth = CSettings::getSingleton().getFloat("zombieWorth");
		
	mCooldown = CSettings::getSingleton().getFloat("zombieCooldown");
	mAttackPower = CSettings::getSingleton().getFloat("zombieAttackPower");
	mAttackSpeed = CSettings::getSingleton().getFloat("zombieAttackSpeed");
	mAttackRange2 = CSettings::getSingleton().getFloat("zombieAttackRange2");

	mMaxHP = CSettings::getSingleton().getFloat("zombieMaxHP");
	mHPIncrease1 = CSettings::getSingleton().getFloat("zombieHPIncrease1");
	mHPIncrease2 = CSettings::getSingleton().getFloat("zombieHPIncrease2");
	mHPIncreaseExp1 = CSettings::getSingleton().getFloat("zombieHPIncreaseExp1");
	mHPIncreaseExp2 = CSettings::getSingleton().getFloat("zombieHPIncreaseExp2");
}

CZombieBehaviour::~CZombieBehaviour(void)
{
	//TODO: Kill mZombies AI thing
	for(std::list<ZombieAI*>::iterator it=mZombies->begin();it!=mZombies->end();++it)
	{
		CPhysicsManager::getSingleton().getWorld()->removeCollisionObject((*it)->ghostObject);
		delete (*it)->physResponse;
		(*it)->physResponse = NULL;
	}
	mZombies->clear();
	delete mZombies;
}

bool CZombieBehaviour::tick(float dt)
{
	if (dt < 0.0001) return true;
	if (!mTimeIsGoing) return true;
	PROFILE_THIS("CZombieBehaviour::tick");

	Vector3 playerPos = mSceneMgr->getSceneNode("PlayerCamera")->getPosition();

	for(std::list<ZombieAI*>::iterator it=mZombies->begin();it!=mZombies->end();++it)
	{
		//temporarily just move the zombie around
		SceneNode *zomb = (*it)->zombieNode;
		Vector3 zombiePos = zomb->getPosition();
		if ((*it)->remainingHealth > 0.00001)
		{
			if ((*it)->state == AI_SEEKING || (*it)->state == AI_COOLING)
			{
				//head towards the player
				//get heading of turret and relation to zombie
				Vector3 zombiePos = zomb->getPosition();
				Vector3 diff = zombiePos - playerPos;
				//negated, because the zombie is facing backwards...
				Radian desiredAngle = Ogre::Math::ATan2(diff.x, diff.z); 
				Degree difference = desiredAngle - zomb->getOrientation().getYaw();

				//make sure we're dealing with sane angles
				if (Degree(difference) < Degree(180)) difference += Degree(360);
				if (Degree(difference) > Degree(180)) difference -= Degree(360);

				Degree rotateBy =  Math::Clamp<Degree>(difference, Degree(-dt*360), Degree(dt*360));

				zomb->yaw(rotateBy);

				//now move towards player
				Real moved = dt*mSpeed;
				zomb->translate(Vector3(0,0,-moved), Node::TS_LOCAL);

				//update physics world transform
				btTransform currTrans = (*it)->ghostObject->getWorldTransform();
				currTrans.setOrigin(BtOgre::Convert::toBullet(zombiePos));
				currTrans.setRotation(BtOgre::Convert::toBullet(zomb->getOrientation()));
				(*it)->ghostObject->setWorldTransform(currTrans);
				zombiePos = zomb->getPosition();

				if ((*it)->state == AI_SEEKING && (*it)->cooldown <= 0.0001 && mAttackRange2 > zombiePos.squaredDistance(playerPos))
				{
					CSoundManager::getSingleton().PlayWav("../../resource/sounds/zombie/attack1.wav", zombiePos, Vector3::ZERO);
					(*it)->state = AI_SWINGING;
					(*it)->cooldown = mAttackSpeed;
				}
			}

			if ((*it)->state == AI_SWINGING)
			{
				if ((*it)->cooldown < 0.0001)
				{
					//do damage
					(*it)->state = AI_COOLING;
					(*it)->cooldown = mCooldown;
					if(mAttackRange2 > zombiePos.squaredDistance(playerPos))
					{
						CSoundManager::getSingleton().PlayWav("../../resource/sounds/zombie/hit1.wav", zombiePos, Vector3::ZERO);
						CPlayerCamera::getSingletonPtr()->TakeDmg(mAttackPower);
						CPlayStateHelper::getSingleton().UpdateStats();
						if (CPlayerCamera::getSingletonPtr()->GetCurrHP() <= 0) 
						{
							CGameManager::getSingleton().pushState(new CDeadState());
						}
					}
				}
			}

			if ((*it)->state == AI_COOLING)
			{
				if ((*it)->cooldown < 0.0001)
					(*it)->state = AI_SEEKING;
			}

			if ((*it)->state == AI_COOLING || (*it)->state == AI_SWINGING)
				(*it)->cooldown -= dt;

		}
		else 
		{
			//kill the zombie
			it = KillZombie(it);
			CBank::getSingleton().Deposit(mWorth);
			CPlayStateHelper::getSingleton().UpdateStats();
			if (it == mZombies->end())
				break;
		}
	}
	return true;
}

std::list<CZombieBehaviour::ZombieAI*>::iterator CZombieBehaviour::KillZombie(std::list<CZombieBehaviour::ZombieAI*>::iterator it)
{
	mNumKills++;
	ZombieAI *z = *it;
	
	CPhysicsManager::getSingleton().getWorld()->removeCollisionObject(z->ghostObject);
	delete z->ghostObject;
	z->ghostObject = NULL;
	z->physResponse = NULL;
	z->zombieNode->setUserAny(Any(NULL));
	mSceneMgr->destroySceneNode(z->zombieNode);
	z->zombieNode = NULL;

	return mZombies->erase(it);
}

void CZombieBehaviour::addZombie(Ogre::SceneNode *zombie, Ogre::Entity *entity)
{
	ZombieAI *z=new ZombieAI();
	z->state = AI_SEEKING;
	z->zombieNode = zombie;

	//if kills are greater than 40, than linearly increase maximum health
	z->maxHealth = z->remainingHealth = 
		0.33333*mMaxHP *
		(	1 + 
			3*mNumSpawned * mHPIncrease1 +
			3*mNumSpawned * mNumSpawned * mHPIncrease2 + 
			Ogre::Math::Pow(mHPIncreaseExp1, mNumSpawned) + 
			Ogre::Math::Pow(mHPIncreaseExp2, mNumSpawned*mNumSpawned)
		);

	CPlayStateHelper::getSingleton().AddDebugMsg("Zombie Spawned: " + StringConverter::toString(z->maxHealth));

	//create bt Object (physics)
	z->ghostObject = new btPairCachingGhostObject();
	z->ghostObject->setWorldTransform(btTransform(
		BtOgre::Convert::toBullet(zombie->getOrientation()), 
		btVector3(0,1,0) + BtOgre::Convert::toBullet(zombie->getPosition())));
	
    //Create the ground shape.
	if (!mZombieShape)
	{
		BtOgre::StaticMeshToShapeConverter *zombConverter = 
			new BtOgre::StaticMeshToShapeConverter(entity);
		//mZombieShape = new btSphereShape(2.0);
		//mZombieShape = zombConverter->createBox();
		//mZombieShape = zombConverter->createSphere();		
		const Ogre::Vector3 sz = zombConverter->getSize();
		mZombieShape = new btCylinderShapeX(BtOgre::Convert::toBullet(sz * 0.5));

		//mZombieShape = zombConverter->createCylinder();
		//mZombieShape = zombConverter->createConvex();
		//mZombieShape = zombConverter->createTrimesh();
		delete zombConverter;
	}

	z->ghostObject->setCollisionShape(mZombieShape);
	z->physResponse = new CZombiePhysicsResponse(z);
	z->ghostObject->setUserPointer((void*)z->physResponse);
	z->cooldown = 0;
	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(z->ghostObject, MVT_ENEMY, MVT_PROJECTILE|MVT_ENEMY|MVT_TURRET);
	z->ghostObject->setCollisionFlags(z->ghostObject->getCollisionFlags() | btCollisionObject::CF_CUSTOM_MATERIAL_CALLBACK);

	mZombies->push_back(z);
	mNumSpawned++;
	CPlayStateHelper::getSingleton().UpdateStats();
}
