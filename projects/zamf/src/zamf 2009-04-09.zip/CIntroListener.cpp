#include "CIntroListener.h"
#include "CPlayState.h"

CIntroListener::CIntroListener(void)
{
}

CIntroListener::~CIntroListener(void)
{
}

bool CIntroListener::handleMessage(MESSAGE_TYPE type, MESSAGE_ID id)
{
	if (type == MT_DOWN)
	{
		if (id == MID_MENU_CONFIRM)
			CGameManager::getSingleton().changeState(new CPlayState());

		if (id == MID_MENU_CANCEL)
			CMessageBroadcaster::getSingleton().inject(MT_NONE, MID_APP_QUIT);
	}
	return true;
}

bool CIntroListener::evtQuit(const CEGUI::EventArgs &arg)
{
	CMessageBroadcaster::getSingleton().inject(MT_NONE, MID_APP_QUIT);

	return true;
}

bool CIntroListener::evtStartGame(const CEGUI::EventArgs &arg)
{
	CGameManager::getSingleton().changeState(new CPlayState());
	return true;
}