#pragma once
#include "IMessageHandler.h"

class btDynamicsWorld;

class CPhysicsBehaviour : public IMessageHandler
{
public:
	CPhysicsBehaviour(void);
	virtual ~CPhysicsBehaviour(void);

	virtual bool tick(Ogre::Real dt);
	virtual bool handleMessage(MESSAGE_TYPE type, MESSAGE_ID id);
	void dispatchCollisions(btDynamicsWorld *phyWorld);

	IMM_AUTO_SIZE;
protected:

	bool mDoDebug;
};
