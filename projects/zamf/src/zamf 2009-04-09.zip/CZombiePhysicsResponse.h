#pragma once
#include "IPhysicsResponse.h"
#include "CZombieBehaviour.h"

class CZombiePhysicsResponse : public IPhysicsResponse
{
public:
	CZombiePhysicsResponse(CZombieBehaviour::ZombieAI *zAI);
	virtual ~CZombiePhysicsResponse(void);

	void Collide(IPhysicsResponse *other, btPersistentManifold* contactManifold, int flipFlop);
	CZombieBehaviour::ZombieAI *getZombie(){return mZombieAI;}


	IMM_AUTO_SIZE;
protected:
	CZombieBehaviour::ZombieAI *mZombieAI;
	int mFlipFlop;
};
