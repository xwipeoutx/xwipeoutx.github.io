#pragma once
#include "IMMObject.h"
#include "CMMPointer.h"

#include <al.h>
#include <alut.h>

#include "Ogre.h"
class CSoundBuffer;

class CSoundSource : public IMMObject
{
public:
	CSoundSource(void);
	virtual ~CSoundSource(void);


	bool GetCurrentlyPlaying();

	void Play(CMMPointer<CSoundBuffer> buffer);
	void Stop();

	void SetPosition(Ogre::Vector3 position);
	void SetVelocity(Ogre::Vector3 velocity);

	void SetLooping(bool loop);
	
	IMM_AUTO_SIZE;
private:
	bool mCurrentlyPlaying;

	ALuint mALSource;

};
