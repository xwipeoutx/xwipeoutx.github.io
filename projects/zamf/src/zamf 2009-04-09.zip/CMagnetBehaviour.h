#pragma once

#include "IMessageHandler.h"
#include "IPhysicsResponse.h"
#include <Ogre.h>

class CBowlBehaviour;
class btCollisionObject;
class btCollisionShape;

class CMagnetBehaviour : public IMessageHandler
{
public:
	CMagnetBehaviour(Ogre::SceneManager *sm);
	virtual ~CMagnetBehaviour(void);

	struct Magnet
	{
		btCollisionObject *physObject;
		Ogre::SceneNode *node;
		bool isActive;
		float activationTime;
	};

	void addMagnet(Ogre::SceneNode *bowl);
	void clearMagnets();
	std::list<Magnet*> &getMagnets(){return mMagnets;}

	bool tick(Ogre::Real dt);

	IMM_AUTO_SIZE;
protected:
	Ogre::SceneManager *mSceneMgr;
	std::list<Magnet*> mMagnets;
	btCollisionShape *mMagnetShape;
};

//physics response object
class CMagnetPhysicsResponse : public IPhysicsResponse
{
public:
	CMagnetPhysicsResponse(CMagnetBehaviour::Magnet *m)
		: mMagnetBehaviour(m)
	{
	}

	virtual ~CMagnetPhysicsResponse(void)
	{
		mMagnetBehaviour = NULL;
	}

	void Collide(IPhysicsResponse *other, btPersistentManifold* contactManifold, int flipFlop);

	CMagnetBehaviour::Magnet *CMagnetBehaviour(){return mMagnetBehaviour;}

	IMM_AUTO_SIZE;
protected:
	CMagnetBehaviour::Magnet *mMagnetBehaviour;
};