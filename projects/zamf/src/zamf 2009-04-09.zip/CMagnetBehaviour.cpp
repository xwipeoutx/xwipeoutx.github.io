#include "CMagnetBehaviour.h"
#include "CProfileSample.h"
#include "CPhysicsManager.h"
#include "CBowlBehaviour.h"

#include "btOgreGP.h"
#include "btOgrePG.h"

#include <Ogre.h>
#include "constants.h"

using namespace Ogre;

CMagnetBehaviour::CMagnetBehaviour(SceneManager *mgr)
: mSceneMgr(mgr)
{
	//mMagnetShape = new btSphereShape(1);
	mMagnetShape = new btBoxShape(btVector3(0.55, 0.55, 0.55));
	//mMagnetShape = new btBoxShape(btVector3(1, 1, 1));
}

CMagnetBehaviour::~CMagnetBehaviour(void)
{
	for(std::list<Magnet*>::iterator it=mMagnets.begin();it!=mMagnets.end();++it)
	{
		CPhysicsManager::getSingleton().getWorld()->removeCollisionObject((*it)->physObject);
		delete (*it)->physObject->getUserPointer();
	}
	mMagnets.clear();
}

bool CMagnetBehaviour::tick(float dt)
{
	for(std::list<Magnet*>::iterator it=mMagnets.begin();it!=mMagnets.end();++it)
	{
		if (!(*it)->isActive)
		{
			(*it)->activationTime -= dt;
			if ((*it)->activationTime < 0.0f)
				(*it)->isActive = 1;
		} else {
			(*it)->node->yaw(Radian(5*dt));
		}
	}
	return true;
}

void CMagnetBehaviour::addMagnet(Ogre::SceneNode *magnetNode)
{
	PROFILE_THIS("Add Magnet");
	Magnet *magnet = new Magnet();
	magnet->node = magnetNode;
	magnet->isActive = true;
	magnet->node->translate(0,0.5,0);

	//create bt Object (physics)
	btTransform transform( 
		BtOgre::Convert::toBullet(magnetNode->getOrientation()), 
		BtOgre::Convert::toBullet(magnetNode->getPosition()));

	//btMotionState *motionState = new BtOgre::RigidBodyState(magnetNode);
	//bb->physResponse = new CBulletPhysicsResponse(bb);
	magnet->physObject = new btCollisionObject();
	magnet->physObject->setWorldTransform(transform);
	magnet->physObject->setCollisionShape(mMagnetShape);
	
	//bb->physObject->setUserPointer((void*)bb->physResponse);
	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(magnet->physObject, MVT_TURRET, MVT_ENEMY|MVT_STATIONARY|MVT_PROJECTILE);
	magnet->physObject->setUserPointer(new CMagnetPhysicsResponse(magnet));

	mMagnets.push_back( magnet );	
}

void CMagnetBehaviour::clearMagnets()
{
	mMagnets.clear();
}

void CMagnetPhysicsResponse::Collide(IPhysicsResponse *other, btPersistentManifold *contactManifold, int flipFlop)
{	
	if (dynamic_cast<CBowlPhysicsResponse*>(other) != NULL) {
		mMagnetBehaviour->isActive = 0;
		mMagnetBehaviour->activationTime = 2.0f;
	}
}