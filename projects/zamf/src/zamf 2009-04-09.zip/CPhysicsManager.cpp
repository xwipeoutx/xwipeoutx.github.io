#include "CPhysicsManager.h"

using namespace Ogre;

template<> CPhysicsManager* Singleton<CPhysicsManager>::ms_Singleton = 0;
CPhysicsManager::CPhysicsManager(void)
: mDbgDraw(0)
{
	int maxProxies = 1024;
	btVector3 worldAabbMin(-500,-10,-500);
	btVector3 worldAabbMax(500,10,500);
	mBroadphase = new btAxisSweep3(worldAabbMin,worldAabbMax,maxProxies);
	//mBroadphase = new btDbvtBroadphase();
	//mBroadphase = new btMultiSapBroadphase();
	mSolver = new btSequentialImpulseConstraintSolver();

	mCollisionConfiguration = new btDefaultCollisionConfiguration();
	mDispatcher = new btCollisionDispatcher(mCollisionConfiguration);
	mWorld = new btDiscreteDynamicsWorld(mDispatcher, mBroadphase, mSolver, mCollisionConfiguration);
	mWorld->setGravity(btVector3(0,-9.8,0));
}

CPhysicsManager::~CPhysicsManager(void)
{
	delete mWorld;
	delete mDispatcher;
	delete mCollisionConfiguration;
	delete mSolver;
	delete mBroadphase;
}

void CPhysicsManager::createDebugger(Ogre::SceneNode *node)
{
	mDbgDraw = new BtOgre::DebugDrawer(node, mWorld);
	mDbgDraw->setDebugMode(0);
}
void CPhysicsManager::destroyDebugger()
{
	delete mDbgDraw;
	mDbgDraw = NULL;
}