#include <stdio.h> //required for NULL???

#include "CLevelLoader.h"

#include "ILevel.h"
#include "CLevelGraveyard.h"

#include <Ogre.h>

CLevelLoader::CLevelLoader(Ogre::SceneManager *mgr)
: level(NULL), mSceneMgr(mgr)
{
}

CLevelLoader::~CLevelLoader(void)
{
	if (this->level)
	{
		delete this->level;
		this->level = NULL;
	}
}

void CLevelLoader::Load(int level)
{
	if (this->level)
	{
		delete this->level;
		this->level = NULL;
	}

	//TODO: Load levels properly
	switch(level)
	{
	case 1:
		this->level = new CLevelGraveyard(mSceneMgr);
		break;
	}
}

ILevel *CLevelLoader::GetCurrentLevel()
{
	return level;
}