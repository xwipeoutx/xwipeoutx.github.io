#pragma once
#include "IMessageHandler.h"

#include <Ogre.h>

namespace CEGUI
{
	class System;
};
namespace OIS
{
	class MouseEvent;
}

class CGameListener : public IMessageHandler
{
public:
	CGameListener(CEGUI::System *gui);
	~CGameListener(void);

	//inject to gui
	bool handleMouseMessage(MESSAGE_TYPE type, MESSAGE_ID id, const OIS::MouseEvent &evt);

	//app quite
	bool handleMessage(MESSAGE_TYPE type, MESSAGE_ID id);

	//app quit
	bool tick(Ogre::Real dt);
	IMM_AUTO_SIZE;

protected:
	CEGUI::System *mGUISystem;
	Ogre::Root *mRoot;
};
