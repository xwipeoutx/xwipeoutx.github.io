#ifdef _NOT_USING_THIS_PLAYER_CAMERA
#include "CPlayerCamera.h"

#include "CPhysicsManager.h"
#include "btOgreExtras.h"
using namespace Ogre;

template<> CPlayerCamera* Singleton<CPlayerCamera>::ms_Singleton = 0;

CPlayerCamera::CPlayerCamera(SceneManager *sm, const String &rootName, const Real maxHP)
	: mSceneMgr(sm), 
	mXVelocity(0), mZVelocity(0),
	mSensitivity(0.1), 
	mSpeed(10.0), mRunMultiplier(5.0), mRunning(false),
	mMaxHP(maxHP), mCurrHP(maxHP)
{
	//base node
	this->mCameraNode = 
		this->mSceneMgr->getRootSceneNode()->createChildSceneNode(rootName);
	this->mCameraNode->setPosition(0,0,0);

	//yaw
	this->mCameraYawNode =
		this->mCameraNode->createChildSceneNode(rootName + "Yaw");
	this->mCameraYawNode->setPosition(0,0,0);
	
	//pitch
	this->mCameraPitchNode =
		this->mCameraYawNode->createChildSceneNode(rootName + "Pitch");
	this->mCameraPitchNode->setPosition(0,0,0);
	
	//roll
	this->mCameraRollNode =
		this->mCameraPitchNode->createChildSceneNode(rootName + "Roll");
	this->mCameraRollNode->setPosition(0,0,0);

	//camera attachment
	mCamera = sm->createCamera(rootName + "Camera");
	this->mCameraRollNode->attachObject(this->mCamera);

	//settings
	mCamera->setNearClipDistance(0.5f);

	//blah
	btTransform startTransform;
	startTransform.setIdentity ();
	startTransform.setOrigin (btVector3(0.0, 10.0, 0.0));

	mGhostObject = new btPairCachingGhostObject();
	mGhostObject->setWorldTransform(startTransform);
	CPhysicsManager::getSingleton().getBroadphase()->
		getOverlappingPairCache()->setInternalGhostPairCallback(new btGhostPairCallback());

	btConvexShape *capsule = new btCapsuleShape(0.5, 1.75);
	mGhostObject->setCollisionShape(capsule);
	mGhostObject->setCollisionFlags(btCollisionObject::CF_CHARACTER_OBJECT);

	mCharacter = new btKinematicCharacterController(mGhostObject, capsule, 0.35);

	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(mGhostObject, 
		MVT_PLAYER_CHARACTER, 
		MVT_STATIONARY|MVT_TURRET);
	CPhysicsManager::getSingleton().getWorld()->addAction(mCharacter);
}

CPlayerCamera::~CPlayerCamera(void)
{
	//TODO: Destroy things!
	//TODO: Actually no, let the scene manager handle that
	CPhysicsManager::getSingleton().getWorld()->removeAction(mCharacter);
	CPhysicsManager::getSingleton().getWorld()->removeCollisionObject(mGhostObject);
	delete mGhostObject->getCollisionShape();
	CPhysicsManager::getSingleton().getBroadphase()->
		getOverlappingPairCache()->setInternalGhostPairCallback(NULL);
	delete mGhostObject;
	delete mCharacter;
}

bool CPlayerCamera::handleMessage(MESSAGE_TYPE type, MESSAGE_ID id)
{
	if (id == MID_STOP_TIME) mXVelocity = mZVelocity = 0;
	if (!mTimeIsGoing) return true;

	if (type==MT_DOWN) msgDown(id);
	if (type==MT_UP) msgUp(id);

	return true;
}

bool CPlayerCamera::handleMouseMessage(MESSAGE_TYPE type, MESSAGE_ID id,
		const OIS::MouseEvent &evt)
{
	if (!mTimeIsGoing) return true;
	if (type == MT_NONE)
	{
		Radian dx = Degree(-evt.state.X.rel * mSensitivity);
		float vDx = dx.valueRadians();
		Radian dy = Degree(-evt.state.Y.rel * mSensitivity);
		float vDy = dy.valueRadians();

		btTransform &transform = mGhostObject->getWorldTransform();
		btQuaternion quat = transform.getRotation();
		btQuaternion delta(-vDx, vDy, 0);
		delta.normalize();

		transform.setRotation(delta*quat);

		mCameraYawNode->yaw( dx );
		mCameraPitchNode->pitch( dy );
	}
	return true;
}

bool CPlayerCamera::tick(float dt)
{
	//if (dt < 0.00001) return true;
	if (!mTimeIsGoing) return true;
	Real moveBy = dt;
	if (mRunning)
		moveBy *= mRunMultiplier;



	btTransform &transform = mGhostObject->getWorldTransform();

	btVector3 forwardDir = transform.getBasis()[2];
	btVector3 upDir = transform.getBasis()[1];
	btVector3 strafeDir = transform.getBasis()[0];
	forwardDir.setY(0);
	strafeDir.setY(0);

	forwardDir.normalize(); upDir.normalize(); strafeDir.normalize();

	btVector3 walkDirection = mZVelocity * forwardDir + mXVelocity * strafeDir;
	walkDirection *= (moveBy * 4);

	if(0)
	LogManager::getSingleton().logMessage(
		"dt=" + StringConverter::toString(dt, 12) + 
		"\t\tmoveby=" + StringConverter::toString(moveBy) + 
		"\t\tvel=" + StringConverter::toString(walkDirection.x()) + 
				"," +  StringConverter::toString(walkDirection.z())
		);

	mCharacter->setWalkDirection(walkDirection);
	Vector3 &pos = BtOgre::Convert::toOgre(transform.getOrigin());

	//mCameraNode->setPosition( pos );

	return true;
}

void CPlayerCamera::msgDown(MESSAGE_ID id)
{
	switch (id){
	case MID_WALK_FORWARD:
		mZVelocity -= mSpeed;
		break;

	case MID_WALK_BACKWARD:
		mZVelocity += mSpeed;
		break;

	case MID_STRAFE_LEFT:
		mXVelocity -= mSpeed;
		break;

	case MID_STRAFE_RIGHT:
		mXVelocity += mSpeed;
		break;

	case MID_TOGGLE_RUN:
		mRunning = !mRunning;
		break;

	case MID_RUN:
		mRunning = true;
		break;

	}
}

void CPlayerCamera::msgUp(MESSAGE_ID id)
{
	switch (id){
	case MID_WALK_FORWARD:
		mZVelocity += mSpeed;
		break;
	case MID_WALK_BACKWARD:
		mZVelocity -= mSpeed;
		break;

	case MID_STRAFE_LEFT:
		mXVelocity += mSpeed;
		break;

	case MID_STRAFE_RIGHT:
		mXVelocity -= mSpeed;
		break;
		
	case MID_RUN:
		mRunning = false;
		break;
	}
}
#endif