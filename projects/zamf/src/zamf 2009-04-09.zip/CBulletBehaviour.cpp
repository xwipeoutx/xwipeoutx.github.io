#include "CBulletBehaviour.h"
#include "CPhysicsManager.h"
#include "CSettings.h"

#include "constants.h"
#include "btOgreGP.h"
#include "btOgrePG.h"

#include "CBulletPhysicsResponse.h"

#include "CPlayStateHelper.h"
#include "CProfileSample.h"

#include <Ogre.h>
#include <CEGUI/CEGUI.h>

using namespace Ogre;

CBulletBehaviour::CBulletBehaviour(SceneManager *mgr)
: mSceneMgr(mgr), mNumBullets(0), mNumPooledBullets(0), mNumBulletsSpawned(0),
	mNumBulletsDestroyed(0), mNumBulletsMissed(0)
{
	mBulletPool = new std::list<BulletBehaviour*>();
	mBullets = new std::list<BulletBehaviour*>();

	//mBulletShape = new btSphereShape(0.04);
	mBulletShape = new btBoxShape(btVector3(0.02, 0.02, 0.2));

	mInitialSpeed = CSettings::getSingleton().getFloat("bulletInitialSpeed");
	mMass = CSettings::getSingleton().getFloat("bulletMass");
	mFriction = CSettings::getSingleton().getFloat("bulletFriction");
	mRestitution = CSettings::getSingleton().getFloat("bulletRestitution");
	mDeactivationTime = CSettings::getSingleton().getFloat("bulletDeactivationTime");
	mCCDMotionThreshold = CSettings::getSingleton().getFloat("bulletCCDMotionThreshold");
}

CBulletBehaviour::~CBulletBehaviour(void)
{
	//TODO: destroy the lists
	for(std::list<BulletBehaviour*>::iterator it=mBullets->begin();it!=mBullets->end();++it)
	{
		BulletBehaviour *bb = *it;

		CPhysicsManager::getSingleton().getWorld()->removeRigidBody((btRigidBody*)bb->physObject);
		delete ((btRigidBody*)bb->physObject)->getMotionState();
		delete bb->physObject->getUserPointer();
		bb->physObject->setUserPointer(NULL);
		delete bb->physObject;
		bb->physObject = NULL;
		bb->physResponse = NULL;
	}
	mBullets->clear();
	mBulletPool->clear();
}

bool CBulletBehaviour::tick(Real dt)
{
	if (dt < 0.0001) return true;
	if (!mTimeIsGoing) return true;
	PROFILE_THIS("CBulletBehaviour::tick");

	Real moveBy = 20*dt;
	for(std::list<BulletBehaviour*>::iterator it=mBullets->begin();it!=mBullets->end();++it)
	{
		BulletBehaviour *bb = *it;
		SceneNode *bullet = bb->bulletNode;

		if (bb->bulletNode->getPosition().squaredLength() > 14000 ||
			bb->physObject->getLinearVelocity().length2() < 100) 
		{
			++mNumBulletsMissed;
			bb->dying = true;
		}
		if (bb->dying && (!bb->physObject->isActive() || dt > 0.01)) {
			it = this->DrownBullet(it);
			if (it == mBullets->end()) 
				break;
		}
	}
	return true;
}

std::list<CBulletBehaviour::BulletBehaviour*>::iterator CBulletBehaviour::DrownBullet(std::list<CBulletBehaviour::BulletBehaviour*>::iterator it) 
{
	++mNumBulletsDestroyed;

	BulletBehaviour *bb = *it;
	//move it to the pool, take it out of here
	mNumPooledBullets++;
	if (bb->bulletNode->getName().length())
		bb->bulletNode->setVisible(false);

	CPhysicsManager::getSingleton().getWorld()->removeRigidBody((btRigidBody*)bb->physObject);
	delete ((btRigidBody*)bb->physObject)->getMotionState();
	bb->physObject->setUserPointer(NULL);
	delete bb->physObject;
	bb->physObject = NULL;
	bb->physResponse = NULL;

	mBulletPool->push_back(*it);
	return mBullets->erase(it);
}

void CBulletBehaviour::fireBullet(Vector3 origin, Vector3 direction, Real range)
{
	PROFILE_THIS("CBulletBehaviour::fireBullet");
	++mNumBulletsSpawned;


	BulletBehaviour *bb;
	if (mNumPooledBullets > 0)
	{
		//use pooled bullet
		bb = mBulletPool->front();
		mBulletPool->pop_front();
		--mNumPooledBullets;

		//Set bullet params for the pooled bullet
		bb->bulletNode->setVisible(true);
		bb->bulletNode->setPosition(origin);
	}
	else
	{
		//create bullet from scratch
		bb = new BulletBehaviour();
		String name = "Bullet" + StringConverter::toString(mNumBullets++);
		String nodeName = "BulletNode" + StringConverter::toString(mNumBullets);

		//Entity *ent = mSceneMgr->createEntity(name, SceneManager::PT_SPHERE);
		Entity *ent = mSceneMgr->createEntity(name, SceneManager::PT_CUBE);
		ent->setQueryFlags(MVT_PROJECTILE);

		SceneNode *node = mSceneMgr->getRootSceneNode()->createChildSceneNode(nodeName, origin);
		node->attachObject(ent);
		node->scale(Vector3(0.0002, 0.0002, 0.002));
		node->setUserAny(Any(bb));

		bb->bulletNode = node;
	}

	bb->bulletNode->setOrientation(Vector3::UNIT_Z.getRotationTo(direction));

	//create bt Object (physics)
	btTransform transform( 
		BtOgre::Convert::toBullet(bb->bulletNode->getOrientation()), 
		BtOgre::Convert::toBullet(bb->bulletNode->getPosition()));
	btScalar mass = mMass; //mass of a nail is about 1g
	btVector3 inertia;
	mBulletShape->calculateLocalInertia(mass, inertia);

	btMotionState *motionState = new BtOgre::RigidBodyState(bb->bulletNode);
	bb->physResponse = new CBulletPhysicsResponse(bb);
	bb->physObject = new btRigidBody(mass, motionState, mBulletShape, inertia);
	bb->physObject->setUserPointer((void*)bb->physResponse);
	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(bb->physObject, MVT_PROJECTILE, MVT_ENEMY|MVT_STATIONARY);
	
	btVector3 dir = BtOgre::Convert::toBullet( direction );
	dir *= mInitialSpeed; //nail speed is like 100m/s
	dir.setY(dir.y() + 2);

	bb->physObject->setGravity(btVector3(0.0,-9.8,0.0));
	bb->physObject->setLinearVelocity(dir);
	bb->physObject->setFriction(mFriction);
	bb->physObject->setRestitution(mRestitution);
	bb->physObject->setCcdMotionThreshold(mCCDMotionThreshold);
	bb->physObject->setDeactivationTime(mDeactivationTime);

	bb->direction = direction;
	bb->range = range;
	bb->dying = false;

	mBullets->push_back(bb);
}