#include "CZombiePhysicsResponse.h"

#include "CBulletPhysicsResponse.h"
#include "CPlayStateHelper.h"
#include "CBowlBehaviour.h"

#include "CSettings.h"
#include "btOgreGP.h"

#include <Ogre.h>

using namespace Ogre;

CZombiePhysicsResponse::CZombiePhysicsResponse(CZombieBehaviour::ZombieAI *zAI)
: mZombieAI(zAI), mFlipFlop(-1)
{
}

CZombiePhysicsResponse::~CZombiePhysicsResponse(void)
{
	mZombieAI = NULL;
}

void CZombiePhysicsResponse::Collide(IPhysicsResponse *other, btPersistentManifold* contactManifold, int body)
{
	int numContacts = contactManifold->getNumContacts();
	CBulletPhysicsResponse* bullet = dynamic_cast<CBulletPhysicsResponse*>(other);
	CBowlPhysicsResponse *bowl = dynamic_cast<CBowlPhysicsResponse*>(other);

	if (bullet != NULL && !bullet->GetBulletBehaviour()->dying) 
	{
		bullet->GetBulletBehaviour()->dying=true;
		Real dmg = CSettings::getSingleton().getFloat("bulletDamage");
		mZombieAI->remainingHealth -= dmg;
	}
	else if (bowl != NULL)
	{
		Real dmg = 0;

		//dmg = bowl->GetBowl()->vel.length();
		for (int i=0;i<numContacts;i++)
		{
			dmg += contactManifold->getContactPoint(i).getAppliedImpulse();
		}
		
		dmg *= CSettings::getSingleton().getFloat("bowlDamageMultiplier");

		mZombieAI->remainingHealth -= dmg;

	}
	else
	{
		if (numContacts > 0)
		{
			btVector3 move(0,0,0);
			
			//move away by half the penetration distance of each point
			for (int i=0;i<numContacts;i++)
			{
				btManifoldPoint &c = contactManifold->getContactPoint(i);
				btVector3 n = 0.5*(c.m_positionWorldOnA-c.m_positionWorldOnB);
				if (body == 0)
					move -= n;
				else
					move += n;

			}
			move.setY(0);

			Ogre::SceneNode *zomb = mZombieAI->zombieNode;
			zomb->translate(BtOgre::Convert::toOgre(move), Node::TS_PARENT);
			
			//update physics world transform
			Vector3 pos = zomb->getPosition();
			btTransform currTrans = mZombieAI->ghostObject->getWorldTransform();
			currTrans.setOrigin(BtOgre::Convert::toBullet(zomb->getPosition()));
			currTrans.setRotation(BtOgre::Convert::toBullet(zomb->getOrientation()));
			mZombieAI->ghostObject->setWorldTransform(currTrans);
		}
	}
}