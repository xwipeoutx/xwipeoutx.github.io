#pragma once

#include "IMessageHandler.h"

#include <Ogre.h>

class CZombiePhysicsResponse;

class btCollisionObject;
class btCollisionShape;

class CZombieBehaviour : public IMessageHandler, public Ogre::Singleton<CZombieBehaviour>
{
public:
	CZombieBehaviour(Ogre::SceneManager *sm);
	virtual ~CZombieBehaviour(void);

	enum AI_STATE 
	{
		AI_SEEKING,
		AI_SWINGING,
		AI_COOLING,
		AI_DEAD
	};

	struct ZombieAI
	{
		Ogre::SceneNode *zombieNode;
		btCollisionObject *ghostObject;
		Ogre::Real maxHealth;
		Ogre::Real remainingHealth;
		AI_STATE state;

		Ogre::Real cooldown;

		CZombiePhysicsResponse *physResponse;
	};

	void addZombie(Ogre::SceneNode *zombie, Ogre::Entity *entity);
	bool tick(float dt);
	int getNumSpawned(){return mNumSpawned;}
	int getNumKills(){return mNumKills;}
	
	IMM_AUTO_SIZE;
protected:
	std::list<CZombieBehaviour::ZombieAI*>::iterator CZombieBehaviour::KillZombie(std::list<CZombieBehaviour::ZombieAI*>::iterator it);

	Ogre::SceneManager *mSceneMgr;
	std::list<ZombieAI*> *mZombies;
	
	btCollisionShape *mZombieShape;
	
	int mNumSpawned;
	int mNumKills;

	float mMaxHP;
	float mSpeed;
	float mWorth;

	float mCooldown;
	float mAttackSpeed;
	float mAttackRange2;
	float mAttackPower;

	float mHPIncrease1;
	float mHPIncrease2;
	float mHPIncreaseExp1;
	float mHPIncreaseExp2;
private:
};
