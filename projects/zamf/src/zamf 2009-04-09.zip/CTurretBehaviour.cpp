#include "CTurretBehaviour.h"
#include "CBulletBehaviour.h"

#include "CPlayStateHelper.h"
#include "CZombieBehaviour.h"
#include "CSettings.h"
#include "CSoundManager.h"

#include "CProfileSample.h"

#include <Ogre.h>
#include "constants.h"

using namespace Ogre;

CTurretBehaviour::CTurretBehaviour(SceneManager *mgr, CBulletBehaviour *bulletBehaviour)
: mSceneMgr(mgr), mBulletBehaviour(bulletBehaviour)
{

	mIdleSpeed = CSettings::getSingleton().getFloat("turretIdleSpeed");
	mTargetingSpeed = CSettings::getSingleton().getFloat("turretTargetingSpeed");
	mCooldown = CSettings::getSingleton().getFloat("turretCooldown");
}

CTurretBehaviour::~CTurretBehaviour(void)
{
}

bool CTurretBehaviour::tick(float dt)
{
	if (dt < 0.0001) return true;
	if (!mTimeIsGoing) return true;
	PROFILE_THIS("CTurretBehaviour::tick");


	
	for (std::list<TurretAI>::iterator it = mTurrets.begin(); it != mTurrets.end(); ++it)
	{
		TurretAI &turret = *it;

#ifdef FIRE_RANDOM_THING
//FIRE
turret.turretNode->yaw(Degree(-dt * 45));
if (turret.timeUntilNextShot > 0)
	it->timeUntilNextShot -= dt;
else
{
	Vector3 pos = turret.position;
	pos.y += 0.79f;
	mBulletBehaviour->fireBullet(pos, Vector3(0,0,1));
	it->timeUntilNextShot = 1.0f;
}
continue;
#endif

		//find a target
		if (turret.searching)
		{
			PROFILE_THIS("Searching");

			SceneQueryResult &res = turret.query->execute();
			//find a target
			if (res.movables.begin() != res.movables.end())
			{
				turret.targetInitialDistanceSquared = 100000.0f;
				turret.searching = false;
				SceneNode *curr;
				std::list<MovableObject*>::iterator itm;
				for(itm=res.movables.begin(); itm!=res.movables.end(); ++itm)
				{
					PROFILE_THIS("Looping for Closest");
					curr = (*itm)->getParentSceneNode();
					if (turret.position.squaredDistance(curr->getPosition())  < turret.targetInitialDistanceSquared)
					{
						turret.targetNode = curr;
						turret.targetInitialDistanceSquared = turret.position.squaredDistance(curr->getPosition());
					}
				}
				if (turret.targetInitialDistanceSquared < 10000)
					turret.targetInitialDistanceSquared = 10000;

				turret.targetNode->setListener(this);
			}
			else
			{
				//move speed: 45 degrees per second
				turret.turretNode->yaw(Degree(-dt * mIdleSpeed));
			}			
		}
		else
		{
			PROFILE_THIS("Face Target");
			//get heading of turret and relation to zombie
			Vector3 targetPos = turret.targetNode->getPosition();
			Vector3 diff = targetPos - turret.position;
			diff.normalise();
			//negated, because the turret is facing backwards...
			Radian desiredAngle = Ogre::Math::ATan2(-diff.x, -diff.z); 
			Degree difference = desiredAngle - turret.turretNode->getOrientation().getYaw();

			//make sure we're dealing with sane angles
			if (Degree(difference) < Degree(180)) difference += Degree(360);
			if (Degree(difference) > Degree(180)) difference -= Degree(360);

			Degree rotateBy =  Math::Clamp<Degree>(difference, Degree(-dt*mTargetingSpeed), Degree(dt*mTargetingSpeed));

			turret.turretNode->yaw(rotateBy);

			//FIRE
			if (turret.timeUntilNextShot > 0)
				it->timeUntilNextShot -= dt;
			else
			{
				if (difference < Degree(5) & difference > Degree(-5))
				{
					CSoundManager::getSingleton().PlayWav("../../resource/sounds/guns/turret_fire.wav", turret.position, Vector3::ZERO);
					diff.y = 0;
					Vector3 pos = turret.position;
					pos.y += 0.79f;
					mBulletBehaviour->fireBullet(pos, diff);
					it->timeUntilNextShot = mCooldown;
				}
			}
		}
	}
	return true;
}

void CTurretBehaviour::addTurret(Ogre::SceneNode *turret)
{
	TurretAI turretAI;
	turretAI.turretNode = turret;
	turretAI.position = turretAI.turretNode->getPosition();

	Sphere sphere(turretAI.position, 20);
	turretAI.query = mSceneMgr->createSphereQuery(sphere);
	turretAI.query->setQueryMask(MVT_ENEMY);
	
	turretAI.searching = true;
	turretAI.timeUntilNextShot = 0.0f;

	mTurrets.push_back( turretAI );	
}

void CTurretBehaviour::clearTurrets()
{
	mTurrets.clear();
}

void CTurretBehaviour::nodeDestroyed(const Ogre::Node *node)
{
	//let's go!
	for (std::list<TurretAI>::iterator it = mTurrets.begin(); it != mTurrets.end(); ++it)
	{
		if (!it->searching)
		if (it->targetNode->getName() == node->getName())
		{
			it->searching = true;
			it->targetNode = NULL;
		}
	}
}