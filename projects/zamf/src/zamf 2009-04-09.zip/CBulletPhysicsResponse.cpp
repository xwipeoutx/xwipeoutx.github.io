#include "CBulletPhysicsResponse.h"

#include "CZombiePhysicsResponse.h"
#include "CPlayStateHelper.h"

CBulletPhysicsResponse::CBulletPhysicsResponse(CBulletBehaviour::BulletBehaviour *bb)
: mBulletBehaviour(bb)
{
}

CBulletPhysicsResponse::~CBulletPhysicsResponse(void)
{
	mBulletBehaviour = NULL;
}

void CBulletPhysicsResponse::Collide(IPhysicsResponse *other, btPersistentManifold* contactManifold, int flipFlop)
{
}