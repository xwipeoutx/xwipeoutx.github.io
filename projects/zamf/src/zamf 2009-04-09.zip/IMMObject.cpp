#include "IMMObject.h"

#include <Ogre.h>

//static initaliser required somewhere - here will do
std::list<IMMObject *> IMMObject::liveObjects;
std::list<IMMObject *> IMMObject::deadObjects;

IMMObject::IMMObject()
{
	liveObjects.push_back(this);
#ifdef DEBUG_VERBOSE
	Ogre::LogManager::getSingleton().logMessage("(v) IMMObject: New IMMObject Created");
#endif
	refCount = 0;
}

IMMObject::~IMMObject()
{
	//We add an empty virtual destructor to make sure that 
	//the destructor in derived classes work properly
}

#ifdef DEBUG_VERBOSE
void IMMObject::AddRef()
{ 
	++refCount; 
	Ogre::String msg = "(v) IMMObject::AddRef() on ";
	msg += typeid(*this).name();
	msg += " refcount=";
	msg += Ogre::StringConverter::toString(refCount);
	Ogre::LogManager::getSingleton().logMessage(msg);
}
#endif

void IMMObject::Release()
{
	--refCount;
#ifdef DEBUG_VERBOSE
	Ogre::String msg = "(v) IMMObject::Release() on ";
	msg += typeid(*this).name();
	msg += " refcount=";
	msg += Ogre::StringConverter::toString(refCount);
	Ogre::LogManager::getSingleton().logMessage(msg);
#endif
	if (refCount <= 0)
	{
#ifdef DEBUG_VERBOSE
		Ogre::String msg = "(v) IMMObject: Moved to dead objects: ";
		msg += typeid(*this).name();
		Ogre::LogManager::getSingleton().logMessage(msg);
#endif

		/* TODO: optimise. see http://www.gamedev.net/reference/programming/features/enginuity2/page2.asp */
		liveObjects.remove(this); 
		deadObjects.push_back(this);
	}
}

void IMMObject::CollectGarbage()
{
	if (deadObjects.size())
	{
		for (std::list<IMMObject *>::iterator it = deadObjects.begin(); it != deadObjects.end(); ++it)
		{
#ifdef DEBUG_VERBOSE
			try 
			{
				Ogre::String msg = "(v) IMMObject: Collecting ";
				msg += typeid(**it).name();
				Ogre::LogManager::getSingleton().logMessage(msg);
			} 
			catch(char*ex)
			{
				Ogre::LogManager::getSingleton().logMessage(ex);
				Ogre::LogManager::getSingleton().logMessage("(v) IMMObject: Error collecting something (has it been deleted already?)");
			}
#endif
			delete (*it);
			(*it) = NULL;
		}
		deadObjects.clear();
	}
}

void IMMObject::CollectRemainingObjects(bool bEmitWarnings)
{
	#ifdef DEBUG
		Ogre::LogManager::getSingleton().logMessage("IMMObject: Freeing all memory");

		Ogre::LogManager::getSingleton().logMessage("IMMObject: One last call to CollectGarbage()");
	#endif
	CollectGarbage();
	
	
	#ifdef DEBUG
		Ogre::LogManager::getSingleton().logMessage("IMMObject: Clearing everything else");
	#endif
	for (std::list<IMMObject *>::iterator it = liveObjects.begin(); it != liveObjects.end(); ++it)
	{
		if (bEmitWarnings)
		{
			int numRefs = (*it)->refCount;
#ifdef DEBUG
			Ogre::String msg = "Warning: IMMObject: Not all objects have been cleaned up: ";
			try 
			{
			msg += (typeid(**it).name());
			} 
			catch (char *ex)
			{
				msg += "[[[Exception! ";
				msg += ex;
				msg += "]] - type not found!]";
			}
			msg += " (";
			msg += Ogre::StringConverter::toString(numRefs);
			msg += " refs)";
			Ogre::LogManager::getSingleton().logMessage(msg);
#endif
		}
		delete (*it);
	}
	liveObjects.clear();
}