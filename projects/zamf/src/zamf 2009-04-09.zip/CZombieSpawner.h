#pragma once
#include "IMessageHandler.h"

namespace Ogre
{
	class SceneManager;
};
class CZombieBehaviour;

class CZombieSpawner : public IMessageHandler
{
public:
	CZombieSpawner(Ogre::SceneManager *mgr, CZombieBehaviour *zombieBehaviour);
	virtual ~CZombieSpawner(void);

	bool tick(Ogre::Real dt);

	IMM_AUTO_SIZE;

protected:
	int mZombieCount;
	Ogre::SceneManager *mSceneMgr;
	CMMPointer<CZombieBehaviour> mZombieBehaviour;
};
