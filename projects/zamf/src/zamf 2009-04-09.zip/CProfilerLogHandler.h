#pragma once
#include "IProfilerOutputHandler.h"

class CProfilerLogHandler : public IProfilerOutputHandler
{
public:
	void BeginOutput();
	void EndOutput(float totalTime);
	void Sample(float fMin, float fAvg, float fMax, float tAvg,
		int callCount, const std::string name, int parentCount);
};
