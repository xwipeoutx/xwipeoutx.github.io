#include "CLevelGraveyard.h"

#include "CMessageBroadcaster.h"
#include "CSoundManager.h"

#include "CBulletBehaviour.h"
#include "CTurretBehaviour.h"
#include "CTurretSpawner.h"
#include "CBowlBehaviour.h"
#include "CMagnetBehaviour.h"
#include "CZombieBehaviour.h"
#include "CZombieSpawner.h"

#include "CPhysicsBehaviour.h"
#include "CPhysicsManager.h"

#include "CSettings.h"
#include "CBank.h"
#include "constants.h"

#include <Ogre.h>

#include "btOgreExtras.h"

using namespace Ogre;

CLevelGraveyard::CLevelGraveyard(Ogre::SceneManager *mgr)
: ILevel(mgr)
{
	LogManager::getSingleton().logMessage("Loading Graveyard...");
	PreloadObjects();
	LoadBehaviours();
	LoadSounds();
	CreateScene();
	CSoundManager::getSingleton().PlayLoop("../../resource/sounds/music/drumloop1.wav");
	LogManager::getSingleton().logMessage("Done Loading Graveyard...");
}

CLevelGraveyard::~CLevelGraveyard(void)
{
	CSoundManager::getSingleton().ClearAllEverything();
	CPhysicsManager::getSingleton().destroyDebugger();

	CMessageBroadcaster::getSingleton().detach("BowlBehaviour");
	CMessageBroadcaster::getSingleton().detach("MagnetBehaviour");
	CMessageBroadcaster::getSingleton().detach("BulletBehaviour");
	CMessageBroadcaster::getSingleton().detach("TurretBehaviour");
	CMessageBroadcaster::getSingleton().detach("TurretSpawner");
	
	CMessageBroadcaster::getSingleton().detach("ZombieBehaviour");
	CMessageBroadcaster::getSingleton().detach("ZombieSpawner");
	
	CMessageBroadcaster::getSingleton().detach("LevelGraveyardPhysicsBehaviour");

	mTurretBehaviour = NULL;
	mZombieBehaviour = NULL;
	mTurretSpawner = NULL;
	mZombieSpawner = NULL;

	mSceneMgr->clearScene();
}


void CLevelGraveyard::LoadBehaviours()
{
	LogManager::getSingleton().logMessage("Loading Behaviours...");
	mBulletBehaviour = new CBulletBehaviour(mSceneMgr);
	mMagnetBehaviour = new CMagnetBehaviour(mSceneMgr);
	mBowlBehaviour = new CBowlBehaviour(mSceneMgr, mMagnetBehaviour);
	mTurretBehaviour = new CTurretBehaviour(mSceneMgr, mBulletBehaviour);
	mTurretSpawner =  new CTurretSpawner(mSceneMgr, mTurretBehaviour, mBowlBehaviour, mMagnetBehaviour);
	mZombieBehaviour =  new CZombieBehaviour(mSceneMgr);
	mZombieSpawner =  new CZombieSpawner(mSceneMgr, mZombieBehaviour);
	mPhysicsBehaviour = new CPhysicsBehaviour();

	CMessageBroadcaster::getSingleton().attach(mBulletBehaviour, "BulletBehaviour");
	CMessageBroadcaster::getSingleton().attach(mTurretBehaviour, "TurretBehaviour");
	CMessageBroadcaster::getSingleton().attach(mTurretSpawner , "TurretSpawner");
	CMessageBroadcaster::getSingleton().attach(mMagnetBehaviour, "MagnetBehaviour");
	CMessageBroadcaster::getSingleton().attach(mBowlBehaviour, "BowlBehaviour");
	CMessageBroadcaster::getSingleton().attach(mZombieBehaviour, "ZombieBehaviour");
	CMessageBroadcaster::getSingleton().attach(mZombieSpawner , "ZombieSpawner");
	CMessageBroadcaster::getSingleton().attach(mPhysicsBehaviour , "LevelGraveyardPhysicsBehaviour");

	CBank::getSingleton().SetCash(CSettings::getSingleton().getFloat("bankInitialFunds"));
}

void CLevelGraveyard::PreloadObjects()
{
	LogManager::getSingleton().logMessage("Loading Objects...");
	MeshManager::getSingleton().load("zombie.mesh", ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME);
	MeshManager::getSingleton().load("turret.mesh", ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME);
	MeshManager::getSingleton().load("cube.1m.mesh", ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME);
	mSceneMgr->createEntity("ZOOMZOOM", SceneManager::PT_SPHERE);
	MaterialManager::getSingleton().load("ZAMF/Ground", ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME);
}

void CLevelGraveyard::CreateScene()
{
	LogManager::getSingleton().logMessage("Creating Scene...");
	//set up scene to be cool - shadows and all
	mSceneMgr->setAmbientLight(ColourValue(0.0, 0.0, 0.0));
	mSceneMgr->setShadowTechnique(SHADOWTYPE_STENCIL_ADDITIVE);

	Entity *ent = NULL;

	//Create the ground
	Plane plane(Vector3::UNIT_Y, 0);
	MeshManager::getSingleton().createPlane("ground",
		ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME, plane,
		100, 100, 20, 20, true, 1, 1, 1, Vector3::UNIT_Z);
	ent = mSceneMgr->createEntity("GroundEntity", "ground");
	ent->setMaterialName("ZAMF/Ground");
	ent->setCastShadows(false);
	ent->setQueryFlags(MVT_STATIONARY);
	mSceneMgr->getRootSceneNode()->createChildSceneNode("GroundNode")->attachObject(ent);

	//Light it up eddy
	Light *light;
	light = mSceneMgr->createLight("MoonLight");
	light->setType(Light::LT_DIRECTIONAL);
	light->setDirection(1, -1, -0.5);
	light->setDiffuseColour(0.7, 0.7, 1.0);
	light->setSpecularColour(0.7, 0.7, 1.0);

	//skybox
	mSceneMgr->setSkyBox(true, "ZAMF/NightSky");

	//attach a physics debug drawer
	SceneNode *phyDebugNode = mSceneMgr->getRootSceneNode()->createChildSceneNode();
	CPhysicsManager::getSingleton().createDebugger(phyDebugNode);
	CPhysicsManager::getSingleton().getWorld()->setDebugDrawer(CPhysicsManager::getSingleton().getDebugDrawer());

	//make the ground
	btCollisionShape *groundShape = new btStaticPlaneShape(btVector3(0,1,0),0);
	btMotionState *motionstate = new btDefaultMotionState();
	btRigidBody *ground = new btRigidBody(0.0f, motionstate, groundShape);
	ground->setRestitution(0.1);
	ground->setFriction(1.0);
	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(ground, MVT_STATIONARY);

	//and the walls
	float wallRestitution=0.5,wallFriction=1;
	btCollisionShape *wall1Shape = new btStaticPlaneShape(btVector3(-1,0,0),-50);
	btMotionState *wall1MotionState = new btDefaultMotionState();
	btRigidBody *wall1 = new btRigidBody(0.0f, wall1MotionState, wall1Shape);
	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(wall1, MVT_STATIONARY);
	wall1->setRestitution(wallRestitution);
	wall1->setFriction(wallFriction);
	
	btCollisionShape *wall2Shape = new btStaticPlaneShape(btVector3(1,0,0),-50);
	btMotionState *wall2MotionState = new btDefaultMotionState();
	btRigidBody *wall2 = new btRigidBody(0.0f, wall2MotionState, wall2Shape);
	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(wall2, MVT_STATIONARY);
	wall2->setRestitution(wallRestitution);
	wall2->setFriction(wallFriction);
	
	btCollisionShape *wall3Shape = new btStaticPlaneShape(btVector3(0,0,-1),-50);
	btMotionState *wall3MotionState = new btDefaultMotionState();
	btRigidBody *wall3 = new btRigidBody(0.0f, wall3MotionState, wall3Shape);
	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(wall3, MVT_STATIONARY);
	wall3->setRestitution(wallRestitution);
	wall3->setFriction(wallFriction);
	
	btCollisionShape *wall4Shape = new btStaticPlaneShape(btVector3(0,0,1),-50);
	btMotionState *wall4MotionState = new btDefaultMotionState();
	btRigidBody *wall4 = new btRigidBody(0.0f, wall4MotionState, wall4Shape);
	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(wall4, MVT_STATIONARY);
	wall4->setRestitution(wallRestitution);
	wall4->setFriction(wallFriction);
}

void CLevelGraveyard::LoadSounds()
{
	CSoundManager::getSingleton().AddSound("../../resource/sounds/music/drumloop1.wav");
	CSoundManager::getSingleton().AddSound("../../resource/sounds/guns/turret_fire.wav");
	CSoundManager::getSingleton().AddSound("../../resource/sounds/zombie/attack1.wav");
	CSoundManager::getSingleton().AddSound("../../resource/sounds/zombie/hit1.wav");
	CSoundManager::getSingleton().AddSound("../../resource/sounds/player/death1.wav");
}