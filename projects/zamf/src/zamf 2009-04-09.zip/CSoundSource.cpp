#include "CSoundSource.h"
#include "CSoundBuffer.h"

#include "Ogre.h"

#include <al.h>
#include <alut.h>

using namespace Ogre;

CSoundSource::CSoundSource(void)
: mCurrentlyPlaying(false)
{
	alGetError();
	alGenSources(1, &mALSource);
	if (alGetError() != AL_NO_ERROR)
	{
		LogManager::getSingleton().logMessage("CSoundSource: Error creating source!");
	}

	
	alSourcef(mALSource, AL_PITCH, 1.0f);
	alSourcef(mALSource, AL_GAIN, 8.0f);

	//alSourcefv(source[0], AL_POSITION, );
	//alSourcefv(source[0], AL_VELOCITY, source0Vel);

	alSourcei(mALSource, AL_LOOPING, false);
	LogManager::getSingleton().logMessage("CSoundSource: Created new source");
}

CSoundSource::~CSoundSource(void)
{
	alDeleteSources(1, &mALSource);
}

bool CSoundSource::GetCurrentlyPlaying()
{
	ALint state;
	alGetSourcei(mALSource, AL_SOURCE_STATE, &state);

	return (state == AL_PLAYING);
}

void CSoundSource::Play(CMMPointer<CSoundBuffer> buffer)
{
	alSourcei(mALSource, AL_BUFFER, buffer->GetBuffer());
	alSourcePlay(mALSource);

	if (alGetError() != AL_NO_ERROR)
	{
		LogManager::getSingleton().logMessage("CSoundSource: Error playing from source!");
	}

	return;
}

void CSoundSource::Stop()
{
	if (GetCurrentlyPlaying())
		alSourceStop(mALSource);
}

void CSoundSource::SetPosition(Ogre::Vector3 position)
{
	alSource3f(mALSource, AL_POSITION, position.x, position.y, position.z);
}

void CSoundSource::SetVelocity(Ogre::Vector3 velocity)
{
	alSource3f(mALSource, AL_VELOCITY, velocity.x, velocity.y, velocity.z);
}

void CSoundSource::SetLooping(bool looping)
{
	alSourcef(mALSource, AL_GAIN, 0.10f);

	alSourcei(mALSource, AL_LOOPING, looping);
}