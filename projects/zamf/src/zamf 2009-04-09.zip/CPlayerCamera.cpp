#ifndef _NOT_USING_THIS_PLAYER_CAMERA
#include "CPlayerCamera.h"
#include "CSettings.h"

using namespace Ogre;

template<> CPlayerCamera* Singleton<CPlayerCamera>::ms_Singleton = 0;

CPlayerCamera::CPlayerCamera(SceneManager *sm, const String &rootName, const Real maxHP)
	: mSceneMgr(sm), 
	mXVelocity(0), mZVelocity(0),
	mRunning(false)
{
	//speeds and such
	mSpeed = CSettings::getSingleton().getFloat("playerSpeed");
	mRunMultiplier = CSettings::getSingleton().getFloat("playerRunMultiplier");
	mSensitivity = CSettings::getSingleton().getFloat("mouseSensitivity");
	mMaxHP = mCurrHP = CSettings::getSingleton().getFloat("playerMaxHP");
	mHeight = CSettings::getSingleton().getFloat("playerHeight");

	//base node
	this->mCameraNode = 
		this->mSceneMgr->getRootSceneNode()->createChildSceneNode(rootName);
	this->mCameraNode->setPosition(0,0,0);

	//yaw
	this->mCameraYawNode =
		this->mCameraNode->createChildSceneNode(rootName + "Yaw");
	this->mCameraYawNode->setPosition(0,0,0);
	
	//pitch
	this->mCameraPitchNode =
		this->mCameraYawNode->createChildSceneNode(rootName + "Pitch");
	this->mCameraPitchNode->setPosition(0,0,0);
	
	//roll
	this->mCameraRollNode =
		this->mCameraPitchNode->createChildSceneNode(rootName + "Roll");
	this->mCameraRollNode->setPosition(0,0,0);

	//camera attachment
	mCamera = sm->createCamera(rootName + "Camera");
	this->mCameraRollNode->attachObject(this->mCamera);

	//settings
	mCamera->setNearClipDistance(0.5f);
}

CPlayerCamera::~CPlayerCamera(void)
{
	//TODO: Destroy things!
	//TODO: Actually no, let the scene manager handle that
}

bool CPlayerCamera::handleMessage(MESSAGE_TYPE type, MESSAGE_ID id)
{
	if (id == MID_STOP_TIME) mXVelocity = mZVelocity = 0;
	if (!mTimeIsGoing) return true;

	if (type==MT_DOWN) msgDown(id);
	if (type==MT_UP) msgUp(id);

	return true;
}

bool CPlayerCamera::handleMouseMessage(MESSAGE_TYPE type, MESSAGE_ID id,
		const OIS::MouseEvent &evt)
{
	if (!mTimeIsGoing) return true;
	if (type == MT_NONE)
	{
	    this->yaw(Degree(-evt.state.X.rel * mSensitivity));
        this->pitch(Degree(-evt.state.Y.rel * mSensitivity));
	}
	return true;
}

bool CPlayerCamera::tick(float dt)
{
	if (!mTimeIsGoing) return true;
	Real moveBy = dt;
	if (mRunning)
		moveBy *= mRunMultiplier;

	move(Ogre::Vector3(mXVelocity*moveBy, 0, mZVelocity*moveBy));

	Real diff = this->mCameraNode->getPosition().y;
	this->mCameraNode->translate(Vector3(0,-diff + mHeight, 0), SceneNode::TS_PARENT);

	return true;
}

void CPlayerCamera::msgDown(MESSAGE_ID id)
{
	switch (id){
	case MID_WALK_FORWARD:
		mZVelocity -= mSpeed;
		break;

	case MID_WALK_BACKWARD:
		mZVelocity += mSpeed;
		break;

	case MID_STRAFE_LEFT:
		mXVelocity -= mSpeed;
		break;

	case MID_STRAFE_RIGHT:
		mXVelocity += mSpeed;
		break;

	case MID_TOGGLE_RUN:
		mRunning = !mRunning;
		break;

	case MID_RUN:
		mRunning = true;
		break;
	}
}

void CPlayerCamera::msgUp(MESSAGE_ID id)
{
	switch (id){
	case MID_WALK_FORWARD:
		mZVelocity += mSpeed;
		break;

	case MID_WALK_BACKWARD:
		mZVelocity -= mSpeed;
		break;

	case MID_STRAFE_LEFT:
		mXVelocity += mSpeed;
		break;

	case MID_STRAFE_RIGHT:
		mXVelocity -= mSpeed;
		break;
		
	case MID_RUN:
		mRunning = false;
		break;
	}
}


#endif