#include "CTurretSpawner.h"
#include "CTurretBehaviour.h"
#include "CBowlBehaviour.h"
#include "CMagnetBehaviour.h"

#include "CSettings.h"
#include "CPlayerCamera.h"

#include "CBank.h"
#include "CPlayStateHelper.h"
#include "constants.h"

#include "CProfileSample.h"

#include <Ogre.h>
using namespace Ogre;

CTurretSpawner::CTurretSpawner(SceneManager *mgr, 
							   CTurretBehaviour *turretBehaviour, 
							   CBowlBehaviour *bowlBehaviour,
							   CMagnetBehaviour *magnetBehaviour)
: mSceneMgr(mgr), mWeaponCount(0), mTurretBehaviour(turretBehaviour), 
mBowlBehaviour(bowlBehaviour), mMagnetBehaviour(magnetBehaviour), 
mActiveWeapon(AW_TURRET), mWeaponCost(10), mPlaceholderBounceFactor(0)
{
	mPlaceholderNode = mSceneMgr->getRootSceneNode()->createChildSceneNode("WeaponPlaceholderNode");

	Entity *ent = mSceneMgr->createEntity("TurretPlaceholderEntity", "turret.mesh");
	ent->setQueryFlags(MVT_NONE);
	ent->setVisible(false);
	mPlaceholderNode->attachObject(ent);
	ent->setCastShadows(false);
	std::pair<ACTIVE_WEAPON, Entity*> pair = std::make_pair<ACTIVE_WEAPON, Entity*>(AW_TURRET, ent);
	mPlaceholderEntities.insert(pair);

	ent = mSceneMgr->createEntity("MagnetPlaceholderEntity", "cube.1m.mesh");
	ent->setQueryFlags(MVT_NONE);
	ent->setVisible(false);
	mPlaceholderNode->attachObject(ent);
	ent->setCastShadows(false);
	pair = std::make_pair<ACTIVE_WEAPON, Entity*>(AW_MAGNET, ent);
	mPlaceholderEntities.insert(pair);
	
	ent = mSceneMgr->createEntity("BowlPlaceholderEntity", "cube.1m.mesh");
	ent->setQueryFlags(MVT_NONE);
	ent->setVisible(false);
	ent->setMaterialName("cannon");
	mPlaceholderNode->attachObject(ent);
	ent->setCastShadows(false);
	pair = std::make_pair<ACTIVE_WEAPON, Entity*>(AW_BOWL, ent);
	mPlaceholderEntities.insert(pair);

	mPlaceholderNode->setScale(Vector3(0.3, 0.3, 0.3));

	
	mPlaceholderEntities[mActiveWeapon]->setVisible(true);
}

CTurretSpawner::~CTurretSpawner(void)
{
	mTurretBehaviour = NULL;
	mSceneMgr = NULL;
}

bool CTurretSpawner::tick(Real dt)
{
	if (CBank::getSingleton().GetCash() >= mWeaponCost)
	{
		mPlaceholderNode->yaw(Radian(20*dt));
	}
	PROFILE_THIS("CTurretSpawner::Tick");
	Vector3 pos = CPlayerCamera::getSingleton().getCamera()->getRealPosition();
	pos -= 5*CPlayerCamera::getSingleton().getCamera()->getRealOrientation().zAxis();
	pos.y = mPlaceholderBounceFactor;

	mPlaceholderNode->setPosition(pos);
	return true;
}

bool CTurretSpawner::handleMouseMessage(MESSAGE_TYPE type, MESSAGE_ID id, const OIS::MouseEvent &evt)
{
	if (!mTimeIsGoing) return true;
	if (type == MT_DOWN && id == MID_SHOOT && CBank::getSingleton().GetCash() >= mWeaponCost)
	{
		//spawn a turret
		String weaponName = "Weapon" + StringConverter::toString(++mWeaponCount);
		String weaponNodeName = "WeaponNode" + StringConverter::toString(mWeaponCount);

		CBank::getSingleton().Withdraw(mWeaponCost);
		CPlayStateHelper::getSingleton().UpdateStats();
		switch (mActiveWeapon)
		{
		case AW_TURRET:
			spawnTurret(weaponName, weaponNodeName, mPlaceholderNode->getPosition());
			break;
		case AW_MAGNET:
			spawnMagnet(weaponName, weaponNodeName, mPlaceholderNode->getPosition());
			break;
		case AW_BOWL:
			spawnBowl(weaponName, weaponNodeName, mPlaceholderNode->getPosition());
			break;
		}
	}
	return true;
}

bool CTurretSpawner::handleMessage(MESSAGE_TYPE type, MESSAGE_ID id)
{
	if (type == MT_DOWN )
	{
		if (id == MID_WEAPON_TURRET)
			changeToWeapon(AW_TURRET);

		if (id == MID_WEAPON_MAGNET)
			changeToWeapon(AW_MAGNET);

		if (id == MID_WEAPON_BOWL)
			changeToWeapon(AW_BOWL);
	}
	return true;
}

void CTurretSpawner::changeToWeapon(CTurretSpawner::ACTIVE_WEAPON aw)
{
	mPlaceholderEntities[mActiveWeapon]->setVisible(false);
	mActiveWeapon = aw;

	if (aw == AW_TURRET) 
		mWeaponCost = CSettings::getSingleton().getFloat("turretCost");

	if (aw == AW_MAGNET) 
		mWeaponCost = CSettings::getSingleton().getFloat("magnetCost");

	if (aw == AW_BOWL) 
		mWeaponCost = CSettings::getSingleton().getFloat("bowlCost");
	mPlaceholderEntities[mActiveWeapon]->setVisible(true);
}

void CTurretSpawner::spawnTurret(const Ogre::String &name, const Ogre::String &nodeName, const Ogre::Vector3 &intPoint)
{
		Entity *ent = mSceneMgr->createEntity(name, "turret.mesh");
		ent->setCastShadows(false);
		ent->setQueryFlags(MVT_TURRET);
		mSceneMgr->getRootSceneNode()->createChildSceneNode(nodeName,intPoint)->attachObject(ent);
		mTurretBehaviour->addTurret(mSceneMgr->getSceneNode(nodeName));
}

void CTurretSpawner::spawnMagnet(const Ogre::String &name, const Ogre::String &nodeName, const Ogre::Vector3 &intPoint)
{
		Entity *ent = mSceneMgr->createEntity(name, "cube.1m.mesh");
		ent->setCastShadows(false);
		ent->setQueryFlags(MVT_TURRET);
		mSceneMgr->getRootSceneNode()->createChildSceneNode(nodeName,intPoint)->attachObject(ent);
		mMagnetBehaviour->addMagnet(mSceneMgr->getSceneNode(nodeName));
}
void CTurretSpawner::spawnBowl(const Ogre::String &name, const Ogre::String &nodeName, const Ogre::Vector3 &intPoint)
{
		//Entity *ent = mSceneMgr->createEntity(name, "cube.1m.mesh");
		Entity *ent = mSceneMgr->createEntity(name, SceneManager::PT_SPHERE);
		ent->setCastShadows(false);
		ent->setQueryFlags(MVT_PROJECTILE);
		ent->setMaterialName("cannon");
		mSceneMgr->getRootSceneNode()->createChildSceneNode(nodeName,intPoint)->attachObject(ent);
		mSceneMgr->getSceneNode(nodeName)->scale(0.007 * Vector3(1,1,1));
		mBowlBehaviour->addBowl(mSceneMgr->getSceneNode(nodeName));
}