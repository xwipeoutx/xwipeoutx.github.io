#include "CPlayListener.h"

#include "CIntroState.h"
#include "CPauseState.h"

#include <Ogre.h>

CPlayListener::CPlayListener(void)
{
}

CPlayListener::~CPlayListener(void)
{
}

bool CPlayListener::handleMessage(MESSAGE_TYPE type, MESSAGE_ID id)
{
	if (type == MT_DOWN)
	{
		switch (id)
		{
		case MID_MENU:
			CGameManager::getSingleton().changeState(new CIntroState());
			break;

		case MID_PAUSE:
			CGameManager::getSingleton().pushState(new CPauseState());
			break;
		}
	}

	return true;
}
