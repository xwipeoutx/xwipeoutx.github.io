#include "CInputManager.h"

template<> CInputManager* Ogre::Singleton<CInputManager>::ms_Singleton = 0;

CInputManager::CInputManager(Ogre::RenderWindow* pRenderWindow)
{
	size_t windowHwnd = 0;
	std::ostringstream windowHwndStr;
	OIS::ParamList pl;

	pRenderWindow->getCustomAttribute("WINDOW", &windowHwnd);
	windowHwndStr << windowHwnd;
	pl.insert(std::make_pair(std::string("WINDOW"), windowHwndStr.str() ));
	mInputManager = OIS::InputManager::createInputSystem(pl);

	try
	{
		mKeyboard = static_cast<OIS::Keyboard*>(mInputManager->createInputObject(OIS::OISKeyboard, true));
		mMouse = static_cast<OIS::Mouse*>(mInputManager->createInputObject(OIS::OISMouse, true));
		//mJoy = static_cast<OIS::JoyStick*>(mInputManager->createInputObject(OIS::OISJoyStick, false));
	}
	catch (const OIS::Exception &e)
	{
		throw Ogre::Exception(42, e.eText, "CInputManager::CInputManager()");
	}
}

CInputManager::~CInputManager(void)
{
	mInputManager->destroyInputObject(mKeyboard);
	OIS::InputManager::destroyInputSystem(mInputManager);
}
