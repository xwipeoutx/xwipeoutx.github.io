#include "CBulletBehaviour.h"

#include <Ogre.h>
#include "constants.h"

using namespace Ogre;

CBulletBehaviour::CBulletBehaviour(SceneManager *mgr)
: mSceneMgr(mgr), mNumBullets(0), mNumPooledBullets(0)
{

}

CBulletBehaviour::~CBulletBehaviour(void)
{
}

bool CBulletBehaviour::tick(Real dt)
{
	if (dt < 0.0001) 
		return true;

	Real moveBy = 500*dt;
	for(std::list<BulletBehaviour>::iterator it=mBullets.begin();it!=mBullets.end();++it)
	{
		SceneNode *bullet = it->bulletNode;
		if (it->range > 0)
		{
			bullet->translate(moveBy * it->direction);
			it->range -= moveBy;
		} else {
			//move it to the pool, take it out of here
			mNumPooledBullets++;
			it->bulletNode->setVisible(false);
			mBulletPool.push_back(*it);
			it = mBullets.erase(it);
			if (it == mBullets.end()) 
				break;
		}
	}
	return true;
}

void CBulletBehaviour::fireBullet(Vector3 origin, Vector3 direction, Real range)
{
	if (mNumPooledBullets > 0)
	{
		//use pooled bullet
		BulletBehaviour bb = mBulletPool.front();
		mBulletPool.pop_front();
		bb.direction = direction;
		bb.range = range;
		bb.bulletNode->setVisible(true);
		mNumPooledBullets--;
		mBullets.push_back(bb);
	}
	else
	{
		//create bullet from scratch
		String name = "Bullet" + StringConverter::toString(mNumBullets++);
		String nodeName = "BulletNode" + StringConverter::toString(mNumBullets);

		Entity *ent = mSceneMgr->createEntity(name, SceneManager::PT_SPHERE);
		ent->setQueryFlags(MVT_PROJECTILE);

		SceneNode *node = mSceneMgr->getRootSceneNode()->createChildSceneNode(nodeName, origin);
		node->attachObject(ent);
		node->scale(Vector3(0.05, 0.05, 0.05));

		//add to the list
		BulletBehaviour bb;
		bb.bulletNode = node;
		bb.direction = direction;
		bb.range = range;
		mBullets.push_back(bb);
	}

}
