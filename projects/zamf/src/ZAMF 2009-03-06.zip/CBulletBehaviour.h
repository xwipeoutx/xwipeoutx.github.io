#pragma once
#include "IMessageHandler.h"

namespace Ogre
{
	class Vector3;
	class SceneNode;
	class SceneManager;
}

class CBulletBehaviour : public IMessageHandler
{
public:
	CBulletBehaviour(Ogre::SceneManager *sm);
	virtual ~CBulletBehaviour(void);

	void fireBullet(Ogre::Vector3 origin, Ogre::Vector3 direction, Ogre::Real range=400);

	bool tick(float dt);

	IMM_AUTO_SIZE;

protected:
	Ogre::SceneManager *mSceneMgr;

	struct BulletBehaviour
	{
		Ogre::SceneNode *bulletNode;
		Ogre::Vector3 direction;
		Ogre::Real range;
	};

	std::list<BulletBehaviour> mBullets;
	std::list<BulletBehaviour> mBulletPool;
	int mNumBullets;
	int mNumPooledBullets;
	
};
