#include <Ogre.h>

#include "CPlayState.h"

#include "CPlayerCamera.h"
#include "CMessageBroadcaster.h"
#include "CInputManager.h"
#include "CLevelLoader.h"
#include "CPlayListener.h"

#include "constants.h"

using namespace Ogre;

CPlayState::CPlayState()
:mRoot(NULL), mSceneMgr(NULL), mLevelLoader(NULL), mListener(NULL)
{

}

void CPlayState::enter()
{
	mRoot = Root::getSingletonPtr();

	if (!mSceneMgr)
		mSceneMgr = mRoot->createSceneManager(ST_GENERIC, "PlaySceneManager");

	if (!mLevelLoader)
		mLevelLoader = new CLevelLoader(mSceneMgr);
	mLevelLoader->Load(1);
	
	//set this scene manager to be the gui renderer
	CGameManager::getSingletonPtr()->getGUIRenderer().setTargetSceneManager(mSceneMgr);

	//Set the UI elements up
	CGameManager::getSingletonPtr()->getGUISystem().setGUISheet(
		CEGUI::WindowManager::getSingleton().getWindow("ZAMFHUD")
	);

	//hide the mouse cursor
	CEGUI::MouseCursor::getSingleton().hide();

	mListener = new CPlayListener();
	CMessageBroadcaster::getSingleton().attach(mListener, "PlayListener");
}

void CPlayState::exit()
{
	mLevelLoader->Load(0);
	mRoot->getAutoCreatedWindow()->removeAllViewports();
	mRoot->destroySceneManager(mSceneMgr);

	CEGUI::MouseCursor::getSingleton().show();
	CMessageBroadcaster::getSingleton().detach("PlayListener");
}

void CPlayState::pause()
{
	CMessageBroadcaster::getSingleton().detach("PlayListener");
	CEGUI::MouseCursor::getSingleton().show();
}

void CPlayState::resume()
{
	CMessageBroadcaster::getSingleton().attach(mListener, "PlayListener");
	//Set the UI elements up
	CGameManager::getSingletonPtr()->getGUISystem().setGUISheet(
		CEGUI::WindowManager::getSingleton().getWindow("ZAMFHUD")
	);
	CEGUI::MouseCursor::getSingleton().hide();
}
