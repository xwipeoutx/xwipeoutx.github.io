#pragma once

#include <Ogre.h>
#include "CGameManager.h"
#include "IMMObject.h"

class IGameState : public IMMObject
{
public:
	virtual ~IGameState(){
		Ogre::LogManager::getSingleton().logMessage("Cleaned up a game state");
	}

	virtual void enter() = 0;
	virtual void exit() = 0;

	virtual void pause() = 0;
	virtual void resume() = 0;

	virtual bool keyClicked(const OIS::KeyEvent &e) { return true; }
	virtual bool keyPressed(const OIS::KeyEvent &e) { return true; }
	virtual bool keyReleased(const OIS::KeyEvent &e) { return true; }

	//mouse events
	virtual bool mouseMoved(const OIS::MouseEvent &e) { return true; }
	virtual bool mousePressed(const OIS::MouseEvent &e, OIS::MouseButtonID button) { return true; }
	virtual bool mouseReleased(const OIS::MouseEvent &e, OIS::MouseButtonID button) { return true; }

	virtual bool frameStarted(const Ogre::FrameEvent& evt) { return true; }
	virtual bool frameEnded(const Ogre::FrameEvent& evt) { return true; }

	void changeState(IGameState* state) { CGameManager::getSingletonPtr()->changeState(state); }
	void pushState(IGameState* state) { CGameManager::getSingletonPtr()->pushState(state); }
	void popState() { CGameManager::getSingletonPtr()->popState(); }
protected:
	IGameState() { }
};
