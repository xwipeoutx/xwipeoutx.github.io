#include "CLog.h"

#include <atlbase.h> //variable argument list

CLog::CLog(void)
{
}

CLog &CLog::Get()
{
	static CLog log;

	return log;
}

bool CLog::Init()
{
	appLog.open("applog.txt");
	clientLog.open("clientlog.txt");
	serverLog.open("srvrlog.txt");
	//user errors get logged to client
	
	appLog << "Log File Opened..." << std::endl;
	clientLog << "Log File Opened..." << std::endl;
	serverLog << "Log File Opened..." << std::endl;
	
#ifdef DEBUG
	appLog.flush();
	clientLog.flush();
	serverLog.flush();
#endif

	//Load the strings file
	if (!LoadStrings()) return false;
	return true;
}

void CLog::Close()
{
	if (appLog.is_open()) appLog.close();
	if (clientLog.is_open()) clientLog.close();
	if (serverLog.is_open()) serverLog.close();
}
void CLog::Write(int target, const char *msg, ...)
{
	va_list args; va_start(args, msg);
	char szBuf[1024];
	vsprintf(szBuf, msg, args);

	//app log
	if (target & LOG_APP)
	{
		appLog << szBuf << "\n";
#ifdef DEBUG
		appLog.flush();
#endif
	}
	
	//client log
	if (target & LOG_CLIENT)
	{
		clientLog << szBuf << "\n";
#ifdef DEBUG
		clientLog.flush();
#endif
	}
	
	//server log
	if (target & LOG_SERVER)
	{
		serverLog << szBuf << "\n";
#ifdef DEBUG
		serverLog.flush();
#endif
	}
	
	if (target & LOG_USER)
	{
#ifdef WIN32
//	MessageBox(NULL, szBuf, "Message", MB_OK);
#else
#error User-level logging is not yet impemented for this platform
#endif
	}
	va_end(args);
}


void CLog::Write(int target, unsigned long msgID, ...)
{
	va_list args;
	va_start(args, msgID);
	char szBuf[1024];
	ZeroMemory(szBuf, 1024);
	char format[1024];
	strcpy(format, logStrings[msgID].c_str());
	vsprintf(szBuf, format, args);
	Write(target, szBuf);
	va_end(args);
}

#ifdef WIN32
//Under WIN32, strings are read in from string table reseource
bool CLog::LoadStrings()
{
	for (unsigned long i=0; i<MAX_LOG_STRINGS;i++)
	{
		char szBuf[1024];
		int a = LoadStringA(GetModuleHandle(NULL), i, szBuf, 1024); //TODO: stupid strings
		if (!a)
			break;
		logStrings[i] = szBuf;
	}
	
	return true;
}

#else
//other platforms read from strings.txt
bool CLog::LoadStrings()
{
	std::ifstream in("strings.txt");
	if (!in.is_open()) return false;
	
	DWORD index=0;
	
	while (!in.eof())
	{
		char szBuf[1024];
		in.getline(szBuf, 1024);
		logStrings[index++]=szBuf;
	}
	return true;
}
#endif