#pragma once

#include "IMessageHandler.h"

namespace Ogre
{
	class SceneManager;
	//class SceneNode;
	//class SphereSceneQuery;
	//class Vector3;
};

class CZombieBehaviour : public IMessageHandler
{
public:
	CZombieBehaviour(Ogre::SceneManager *sm);
	virtual ~CZombieBehaviour(void);

	void addZombie(Ogre::SceneNode *zombie);

	bool tick(float dt);

	IMM_AUTO_SIZE;
protected:
	Ogre::SceneManager *mSceneMgr;

	struct ZombieAI
	{
		Ogre::SceneNode *zombieNode;
	};

	std::list<ZombieAI> mZombies;
	
private:
};
