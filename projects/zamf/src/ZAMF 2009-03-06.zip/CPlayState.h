#pragma once
#include <Ogre.h>

#include "IGameState.h"

class CLevelLoader;
class CPlayerCamera;
class CTurretBehaviour;
class CPlayListener;

class CPlayState : public IGameState
{
public:
	CPlayState();

	void enter();
	void exit();

	void pause();
	void resume();


	IMM_AUTO_SIZE;
protected:

	Ogre::Root *mRoot;
	Ogre::SceneManager *mSceneMgr;
	CLevelLoader *mLevelLoader;

	CMMPointer< CPlayListener > mListener;
};

