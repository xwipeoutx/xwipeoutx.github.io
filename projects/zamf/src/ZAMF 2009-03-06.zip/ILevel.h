#pragma once

namespace Ogre{
	class SceneManager;
	class Viewport;
};

class CPlayerCamera;

class ILevel
{
public:
	ILevel(Ogre::SceneManager *mgr);
	virtual ~ILevel(void);

protected:
	Ogre::SceneManager *mSceneMgr;
	
	CPlayerCamera *mCamera;
	Ogre::Viewport *mViewport;
};
