#include "CZombieSpawner.h"

#include "CZombieBehaviour.h"
#include "constants.h"

#include <Ogre.h>
using namespace Ogre;

CZombieSpawner::CZombieSpawner(Ogre::SceneManager *mgr, CZombieBehaviour *zombieBehaviour)
: mZombieCount(0), mSceneMgr(mgr), mZombieBehaviour(zombieBehaviour)
{
}

CZombieSpawner::~CZombieSpawner(void)
{
}

bool CZombieSpawner::tick(Ogre::Real dt)
{
	Real zombiesPerSecond = 0.5;
	if (Ogre::Math::RangeRandom(0, 1) >= zombiesPerSecond*dt)
		return true; //don't spawn

	//spawn a zombie
	String zombieName = "Zombie" + StringConverter::toString(mZombieCount++);
	String zombieNodeName = "ZombieNode" + StringConverter::toString(mZombieCount);

	Entity *ent=NULL;
	ent = mSceneMgr->createEntity(zombieName, "zombie.mesh");
	ent->setQueryFlags(MVT_ENEMY);
	ent->setCastShadows(true);
	mSceneMgr->getRootSceneNode()->createChildSceneNode(zombieNodeName)->attachObject(ent);
	mSceneMgr->getSceneNode(zombieNodeName)->setPosition(180, 0, 270);
	mSceneMgr->getSceneNode(zombieNodeName)->yaw(Degree(30));
	mSceneMgr->getSceneNode(zombieNodeName)->showBoundingBox(true);

	mZombieBehaviour->addZombie(mSceneMgr->getSceneNode(zombieNodeName));

	return true;
}