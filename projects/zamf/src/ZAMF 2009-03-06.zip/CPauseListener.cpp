#include "CPauseListener.h"

#include "CInputManager.h"
#include "CIntroState.h"

CPauseListener::CPauseListener(void)
{
}

CPauseListener::~CPauseListener(void)
{
}

bool CPauseListener::handleMessage(MESSAGE_TYPE type, MESSAGE_ID id)
{
	if (type == MT_DOWN)
	{
		switch (id)
		{
		
		/*
		//TODO: Go to menu from pause state
		case MID_MENU:

			CGameManager::getSingleton().popState();
			CGameManager::getSingleton().changeState(new CIntroState());
			break;
		*/

		case MID_PAUSE:
			CGameManager::getSingleton().popState();
			break;
		}
	}

	return true;
}