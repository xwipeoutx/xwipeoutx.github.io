#pragma once

#include <Ogre.h>
#include <OIS/OIS.h>

class CInputManager : public Ogre::Singleton<CInputManager>
{
public:
	CInputManager(Ogre::RenderWindow* rwindow);
	virtual ~CInputManager();
	inline OIS::Keyboard* getKeyboard() const { return mKeyboard; }
	inline OIS::Mouse* getMouse() const { return mMouse; }
	inline OIS::InputManager* getInputManager() const { return mInputManager; }

private:
	OIS::Keyboard *mKeyboard;
	OIS::Mouse *mMouse;
	OIS::InputManager *mInputManager;
};