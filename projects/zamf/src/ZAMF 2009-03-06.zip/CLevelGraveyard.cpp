#include "CLevelGraveyard.h"

#include "CMessageBroadcaster.h"

#include "CBulletBehaviour.h"
#include "CTurretBehaviour.h"
#include "CTurretSpawner.h"
#include "CZombieBehaviour.h"
#include "CZombieSpawner.h"

#include "constants.h"

#include <Ogre.h>

using namespace Ogre;

CLevelGraveyard::CLevelGraveyard(Ogre::SceneManager *mgr)
: ILevel(mgr)
{
	mBulletBehaviour = new CBulletBehaviour(mSceneMgr);
	mTurretBehaviour = new CTurretBehaviour(mSceneMgr, mBulletBehaviour);
	mTurretSpawner =  new CTurretSpawner(mSceneMgr, mTurretBehaviour);
	mZombieBehaviour =  new CZombieBehaviour(mSceneMgr);
	mZombieSpawner =  new CZombieSpawner(mSceneMgr, mZombieBehaviour);

	CMessageBroadcaster::getSingleton().attach(mBulletBehaviour, "BulletBehaviour");
	CMessageBroadcaster::getSingleton().attach(mTurretBehaviour, "TurretBehaviour");
	CMessageBroadcaster::getSingleton().attach(mTurretSpawner , "TurretSpawner");
	CMessageBroadcaster::getSingleton().attach(mZombieBehaviour, "ZombieBehaviour");
	CMessageBroadcaster::getSingleton().attach(mZombieSpawner , "ZombieSpawner");

	//set up scene to be cool - shadows and all
	mSceneMgr->setAmbientLight(ColourValue(0.0, 0.0, 0.0));
	mSceneMgr->setShadowTechnique(SHADOWTYPE_STENCIL_ADDITIVE);

	Entity *ent = NULL;

	//Create the ground
	Plane plane(Vector3::UNIT_Y, 0);
	MeshManager::getSingleton().createPlane("ground",
		ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME, plane,
		1500, 1500, 20, 20, true, 1, 1, 1, Vector3::UNIT_Z);
	ent = mSceneMgr->createEntity("GroundEntity", "ground");
	ent->setMaterialName("ZAMF/Ground");
	ent->setCastShadows(false);
	ent->setQueryFlags(MVT_STATIONARY);
	mSceneMgr->getRootSceneNode()->createChildSceneNode("GroundNode")->attachObject(ent);

	/*
	//Create a random sphere
	ent = mSceneMgr->createEntity("MOOO", SceneManager::PT_SPHERE);
	mSceneMgr->createSceneNode("MOOONode");
	node->attachObject(ent);
	node->scale(Vector3(150,150,150));
	*/

	//Light it up eddy
	Light *light;
	light = mSceneMgr->createLight("MoonLight");
	light->setType(Light::LT_DIRECTIONAL);
	light->setDirection(1, -1, -0.5);
	light->setDiffuseColour(0.7, 0.7, 1.0);
	light->setSpecularColour(0.7, 0.7, 1.0);

	//skybox
	mSceneMgr->setSkyBox(true, "ZAMF/NightSky");
}

CLevelGraveyard::~CLevelGraveyard(void)
{
	mSceneMgr->clearScene();

	CMessageBroadcaster::getSingleton().detach("BulletBehaviour");
	CMessageBroadcaster::getSingleton().detach("TurretBehaviour");
	CMessageBroadcaster::getSingleton().detach("TurretSpawner");
	
	CMessageBroadcaster::getSingleton().detach("ZombieBehaviour");
	CMessageBroadcaster::getSingleton().detach("ZombieSpawner");

	mTurretBehaviour = NULL;
	mZombieBehaviour = NULL;
	mTurretSpawner = NULL;
	mZombieSpawner = NULL;
}
