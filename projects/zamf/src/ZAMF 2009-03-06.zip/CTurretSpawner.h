#pragma once

#include "IMessageHandler.h"

namespace Ogre
{
	class SceneManager;
}
class CTurretBehaviour;

class CTurretSpawner : public IMessageHandler
{
public:
	CTurretSpawner(Ogre::SceneManager *mgr, CTurretBehaviour *turretBehaviour);
	virtual ~CTurretSpawner(void);

	bool handleMouseMessage(MESSAGE_TYPE type,MESSAGE_ID id,
		const OIS::MouseEvent &evt);

	IMM_AUTO_SIZE;
protected:
	Ogre::SceneManager *mSceneMgr;

	CMMPointer< CTurretBehaviour > mTurretBehaviour;
	int mTurretCount;
};