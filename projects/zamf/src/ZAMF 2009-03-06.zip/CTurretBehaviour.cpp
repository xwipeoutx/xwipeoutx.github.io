#include "CTurretBehaviour.h"
#include "CBulletBehaviour.h"

#include <Ogre.h>
#include "constants.h"

using namespace Ogre;

CTurretBehaviour::CTurretBehaviour(SceneManager *mgr, CBulletBehaviour *bulletBehaviour)
: mSceneMgr(mgr), mBulletBehaviour(bulletBehaviour)
{

}

CTurretBehaviour::~CTurretBehaviour(void)
{
}

bool CTurretBehaviour::tick(float dt)
{
	if (dt < 0.0001) 
		return true;

	for (std::list<TurretAI>::iterator it = mTurrets.begin(); it != mTurrets.end(); ++it)
	{
		TurretAI turret = *it;
		//find a target
		if (turret.searching)
		{
			SceneQueryResult res = turret.query->execute();
			
			if (res.movables.begin() != res.movables.end())
			{
				turret.searching = false;
				turret.targetNode = (*res.movables.begin())->getParentSceneNode();
				turret.targetInitialDistanceSquared = 
					turret.position.squaredDistance(turret.targetNode->getPosition());

				if (turret.targetInitialDistanceSquared < 10000)
					turret.targetInitialDistanceSquared = 10000;
			}
			else
			{
				//move speed: 45 degrees per second
				turret.turretNode->yaw(Degree(-dt * 45));
				continue;
			}
		}

		//invariant: mTurret->searching == false - it's found one
		Real distToTarget = turret.position.squaredDistance(turret.targetNode->getPosition());
		if (distToTarget > turret.targetInitialDistanceSquared)
		{
			turret.searching = true;
			continue;
		}

		//get heading of turret and relation to zombie
		Vector3 targetPos = turret.targetNode->getPosition();
		Vector3 diff = targetPos - turret.position;
		diff.normalise();
		//negated, because the turret is facing backwards...
		Radian desiredAngle = Ogre::Math::ATan2(-diff.x, -diff.z); 
		Degree difference = desiredAngle - turret.turretNode->getOrientation().getYaw();

		//make sure we're dealing with sane angles
		if (Degree(difference) < Degree(180)) difference += Degree(360);
		if (Degree(difference) > Degree(180)) difference -= Degree(360);

		Degree rotateBy =  Math::Clamp<Degree>(difference, Degree(-dt*360), Degree(dt*360));

		turret.turretNode->yaw(rotateBy);

		//FIRE
		if (turret.timeUntilNextShot > 0)
			it->timeUntilNextShot -= dt;
		else
		{
			if (difference < Degree(5) & difference > Degree(-5))
			{
				Vector3 pos = turret.position;
				pos.y += 10;
				mBulletBehaviour->fireBullet(pos, diff);
				it->timeUntilNextShot = 1.0f;
			}
		}
			/*
			continue;
			pos.y = pos.y + 1;
			if (pos.y > 10) 
				pos.y = 0;
			turret.turretNode->setPosition(pos);

			//reduce size :)
			turret.targetNode->scale(Vector3(1-dt*0.1));

			if (turret.targetNode->getScale().x < 0.1)
			{
				turret.targetNode->getAttachedObject(0)->setQueryFlags(MVT_STATIONARY);
				turret.searching = true;
			}
			*/

	}
	return true;
}

void CTurretBehaviour::addTurret(Ogre::SceneNode *turret)
{
	TurretAI turretAI;
	turretAI.turretNode = turret;
	turretAI.position = turretAI.turretNode->getPosition();

	Sphere sphere(turretAI.position, 100);
	turretAI.query = mSceneMgr->createSphereQuery(sphere);
	turretAI.query->setQueryMask(MVT_ENEMY);

	turretAI.searching = true;
	turretAI.timeUntilNextShot = 0.0f;

	mTurrets.push_back( turretAI );	
}

void CTurretBehaviour::clearTurrets()
{
	mTurrets.clear();
}

void CTurretBehaviour::fire(Vector3 startPos, Vector3 direction)
{


}