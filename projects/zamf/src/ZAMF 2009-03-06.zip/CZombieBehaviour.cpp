#include "CZombieBehaviour.h"

#include <Ogre.h>
#include "constants.h"

using namespace Ogre;

CZombieBehaviour::CZombieBehaviour(SceneManager *mgr)
: mSceneMgr(mgr)
{

}

CZombieBehaviour::~CZombieBehaviour(void)
{
}

bool CZombieBehaviour::tick(float dt)
{
	if (dt < 0.0001) return true;

	for(std::list<ZombieAI>::iterator it=mZombies.begin();it!=mZombies.end();++it)
	{
		//temporarily just move the zombie around
		SceneNode *zomb = it->zombieNode;
		if (zomb->getScale().x > 0.1)
		{
			//head towards the player
			//get heading of turret and relation to zombie
			Vector3 playerPos = mSceneMgr->getSceneNode("PlayerCamera")->getPosition();
			Vector3 zombiePos = zomb->getPosition();
			Vector3 diff = zombiePos - playerPos;
			//negated, because the zombie is facing backwards...
			Radian desiredAngle = Ogre::Math::ATan2(diff.x, diff.z); 
			Degree difference = desiredAngle - zomb->getOrientation().getYaw();

			//make sure we're dealing with sane angles
			if (Degree(difference) < Degree(180)) difference += Degree(360);
			if (Degree(difference) > Degree(180)) difference -= Degree(360);

			Degree rotateBy =  Math::Clamp<Degree>(difference, Degree(-dt*360), Degree(dt*360));

			zomb->yaw(rotateBy);

			//now move towards player
			zomb->translate(Vector3(0,0,-dt*50), Node::TS_LOCAL);
		}
	}
	return true;
}
void CZombieBehaviour::addZombie(Ogre::SceneNode *zombie)
{
	ZombieAI zombieAI;
	zombieAI.zombieNode = zombie;
	mZombies.push_back(zombieAI);
}
