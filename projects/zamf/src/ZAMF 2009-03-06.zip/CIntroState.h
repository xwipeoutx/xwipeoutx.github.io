#pragma once
#include <Ogre.h>
#include <CEGUI/CEGUI.h>

#include "IGameState.h"

class CIntroListener;

class CIntroState : public IGameState
{
public:
	CIntroState();
	~CIntroState();

	void enter();
	void exit();

	void pause();
	void resume();

	IMM_AUTO_SIZE;
protected:

	Ogre::Root *mRoot;
	Ogre::SceneManager* mSceneMgr;
	Ogre::Viewport* mViewport;
	Ogre::Camera* mCamera;

	CMMPointer<CIntroListener> mListener;

	bool mExitGame;
	
	CEGUI::Event::Connection mConnPlay;
	CEGUI::Event::Connection mConnQuit;

};

