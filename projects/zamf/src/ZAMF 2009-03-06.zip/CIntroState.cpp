#include <Ogre.h>

#include "CIntroState.h"
#include "CIntroListener.h"

using namespace Ogre;

CIntroState::CIntroState()
: mSceneMgr(NULL), mRoot(NULL),mViewport(NULL),mListener(NULL),
mConnPlay(0), mConnQuit(0)
{

}

CIntroState::~CIntroState()
{
	CEGUI::Window *btn = NULL;
	mConnPlay->disconnect();
	mConnQuit->disconnect();
}

void CIntroState::enter()
{
	mRoot = Root::getSingletonPtr();

	mSceneMgr = mRoot->createSceneManager(ST_GENERIC, "IntroSceneManager");

	//set this scene manage to be the gui renderer
	CGameManager::getSingletonPtr()->getGUIRenderer().setTargetSceneManager(mSceneMgr);

	//set up events
	mListener = new CIntroListener();
	CEGUI::Window *btn = NULL;
	
	//quit button
	btn = CEGUI::WindowManager::getSingleton().getWindow((CEGUI::utf8*)"ZAMFMenu/QuitButton");
	mConnQuit = btn->subscribeEvent(CEGUI::PushButton::EventClicked,
		CEGUI::Event::Subscriber(&CIntroListener::evtQuit, &(*mListener)));
	
	//play button
	btn = CEGUI::WindowManager::getSingleton().getWindow((CEGUI::utf8*)"ZAMFMenu/PlayButton");
	mConnPlay = btn->subscribeEvent(CEGUI::PushButton::EventClicked,
		CEGUI::Event::Subscriber(&CIntroListener::evtStartGame, &(*mListener)));

	CGameManager::getSingletonPtr()->getGUISystem().setGUISheet(
		CEGUI::WindowManager::getSingleton().getWindow("ZAMFMenu"));

	//camera, kinda silly :P
	mCamera = mSceneMgr->createCamera("IntroCamera");
	mViewport = mRoot->getAutoCreatedWindow()->addViewport(mCamera);
	mViewport->setBackgroundColour(ColourValue(0.2, 0.0, 0.0, 1.0));

	mExitGame = false;

	CMessageBroadcaster::getSingleton().attach(mListener, "IntroListener");
}

void CIntroState::exit()
{
	CMessageBroadcaster::getSingleton().detach("IntroListener");
	mSceneMgr->clearScene();
	mSceneMgr->destroyAllCameras();
	mRoot->getAutoCreatedWindow()->removeAllViewports();
	mRoot->destroySceneManager(mSceneMgr);

	mCamera = NULL;
	mViewport = NULL;
	mSceneMgr = NULL;
	mListener = NULL;
	mRoot = NULL;
}

void CIntroState::pause()
{
}

void CIntroState::resume()
{
}
