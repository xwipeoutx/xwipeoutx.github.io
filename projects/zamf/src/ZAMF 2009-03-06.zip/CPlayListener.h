#pragma once
#include "IMessageHandler.h"

class CPlayListener : public IMessageHandler
{
public:
	CPlayListener(void);
	~CPlayListener(void);

	bool handleMessage(MESSAGE_TYPE type, MESSAGE_ID id);

	IMM_AUTO_SIZE;
};
