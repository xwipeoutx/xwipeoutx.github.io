#pragma once
#include "ILevel.h"
#include "CMMPointer.h"

class CBulletBehaviour;
class CTurretBehaviour;
class CTurretSpawner;

class CZombieBehaviour;
class CZombieSpawner;

namespace Ogre{
	class SceneManager;
};

class CLevelGraveyard : public ILevel
{
public:
	CLevelGraveyard(Ogre::SceneManager *mgr);
	virtual ~CLevelGraveyard(void);

protected:
	CMMPointer< CBulletBehaviour > mBulletBehaviour;
	CMMPointer< CTurretBehaviour > mTurretBehaviour;
	CMMPointer< CTurretSpawner > mTurretSpawner;
	
	CMMPointer< CZombieBehaviour > mZombieBehaviour;
	CMMPointer< CZombieSpawner > mZombieSpawner;

};
