#pragma once
#include "IMessageHandler.h"

#include "CEGUI/CEGUI.h"

class CIntroListener :	public IMessageHandler
{
public:
	CIntroListener(void);
	~CIntroListener(void);
	
	bool handleMessage(MESSAGE_TYPE type, MESSAGE_ID id);
	
	bool evtQuit(const CEGUI::EventArgs &arg);
	bool evtStartGame(const CEGUI::EventArgs &arg);

	IMM_AUTO_SIZE;
};
