#pragma once

#include <Ogre.h>

#include "IMessageHandler.h"

class CPlayerCamera : public IMessageHandler
{
public:
	CPlayerCamera(Ogre::SceneManager *sm, const Ogre::String &rootName);

	~CPlayerCamera(void);

	inline Ogre::SceneNode *getCameraNode(){ return mCameraNode; }
	inline Ogre::Camera *getCamera(){ return mCamera; }

	//for yaw/pitch/roll, apply to relevant node
	inline void yaw(const Ogre::Radian &angle)
	{
		mCameraYawNode->yaw(angle);
	}
	inline void pitch(const Ogre::Radian &angle)
	{
		mCameraPitchNode->pitch(angle);
	}
	inline void roll(const Ogre::Radian &angle)
	{
		mCameraRollNode->roll(angle);
	}

	inline void setPosition(const Ogre::Vector3 &position)
	{
		this->mCameraNode->setPosition(position);
	}
	
	inline void setPosition(const Ogre::Real x, Ogre::Real y, Ogre::Real z)
	{
		this->mCameraNode->setPosition(x,y,z);
	}

	inline void move(const Ogre::Vector3 &translate)
	{
		this->mCameraNode->translate(this->mCameraYawNode->getOrientation() *
				this->mCameraPitchNode->getOrientation() *
				translate,
				Ogre::SceneNode::TS_LOCAL);
	}

	bool handleMessage(MESSAGE_TYPE type, MESSAGE_ID id);

	bool handleMouseMessage(MESSAGE_TYPE type,MESSAGE_ID id,
		const OIS::MouseEvent &evt);

	bool tick(float dt);

	IMM_AUTO_SIZE;

protected:
	Ogre::SceneNode *mCameraNode;
	Ogre::SceneNode *mCameraYawNode;
	Ogre::SceneNode *mCameraPitchNode;
	Ogre::SceneNode *mCameraRollNode;

	Ogre::Camera *mCamera;

	Ogre::SceneManager *mSceneMgr;

	bool mRunning;

	Ogre::Real mZVelocity;
	Ogre::Real mXVelocity;

	Ogre::Real mSpeed;
	Ogre::Real mRunMultiplier;
	Ogre::Real mSensitivity;

	void msgDown(MESSAGE_ID id);
	void msgUp(MESSAGE_ID id);
};
