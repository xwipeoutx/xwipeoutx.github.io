#pragma once

#include "CMessageBroadcaster.h"
#include "IMMObject.h"

class IMessageHandler : public IMMObject
{
public:
	virtual ~IMessageHandler(void){}

	virtual bool handleMessage(MESSAGE_TYPE type, MESSAGE_ID id)
	{return true;}

	virtual bool handleMouseMessage(MESSAGE_TYPE type, MESSAGE_ID id,
		const OIS::MouseEvent &evt)
	{return true;}

	virtual bool tick(float dt)
	{return true;}
protected:
	IMessageHandler(void){}
};
