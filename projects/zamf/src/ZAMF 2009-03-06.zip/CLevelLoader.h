#pragma once

class ILevel;

namespace Ogre{
	class SceneManager;
};

class CLevelLoader
{
public:
	CLevelLoader(Ogre::SceneManager *mgr);
	~CLevelLoader(void);

	void Load(int level);

private:
	ILevel *GetCurrentLevel();
	ILevel *level;

	Ogre::SceneManager *mSceneMgr;
};
