#include "CMessageBroadcaster.h"

#include "IMessageHandler.h"
#include "CInputManager.h"

using namespace Ogre;

template<> CMessageBroadcaster* Singleton<CMessageBroadcaster>::ms_Singleton;

CMessageBroadcaster::CMessageBroadcaster(CInputManager *inputManager)
{
	inputManager->getKeyboard()->setEventCallback(this);
	inputManager->getMouse()->setEventCallback(this);

	Root::getSingletonPtr()->addFrameListener(this);
}

CMessageBroadcaster::~CMessageBroadcaster(void)
{
	//mainly doing this for log messages
	refreshMessageHandlerList();
}

bool CMessageBroadcaster::keyClicked(const OIS::KeyEvent &e)
{
	dispatch(MT_CLICK, e);
	return true;
}

bool CMessageBroadcaster::keyPressed(const OIS::KeyEvent &e)
{
	dispatch(MT_DOWN, e);
	return true;
}

bool CMessageBroadcaster::keyReleased(const OIS::KeyEvent &e)
{
	dispatch(MT_UP, e);
	return true;
}

bool CMessageBroadcaster::mouseMoved(const OIS::MouseEvent &e)
{
	dispatchMouse(MT_NONE, MID_NONE, e);
	return true;
}
bool CMessageBroadcaster::mousePressed(const OIS::MouseEvent &e, OIS::MouseButtonID button)
{
	dispatchMouse(MT_DOWN, mbToMessageId(button), e);
	return true;
}
bool CMessageBroadcaster::mouseReleased(const OIS::MouseEvent &e, OIS::MouseButtonID button)
{
	dispatchMouse(MT_UP, mbToMessageId(button), e);
	return true;
}


void CMessageBroadcaster::attach(IMessageHandler *messageHandler, const Ogre::String &instanceName)
{
	Ogre::LogManager::getSingleton().logMessage("Message Handler: Attaching " + instanceName);
	mNewMessageHandlers.insert(std::make_pair<String, IMessageHandler*>(instanceName, messageHandler));
	//messageHandler->AddRef();
}


void CMessageBroadcaster::detach(const Ogre::String &instanceName)
{
	Ogre::LogManager::getSingleton().logMessage("Message Handler: Detaching " + instanceName);
	mDeletedMessageHandlers.push_back(instanceName);
}


bool CMessageBroadcaster::frameStarted(const Ogre::FrameEvent &evt)
{
	//capture input
	CInputManager::getSingleton().getMouse()->capture();
	CInputManager::getSingleton().getKeyboard()->capture();

	refreshMessageHandlerList();

	//'tick' each message handler
	if (!mMessageHandlers.empty())
	for (itMessageHandler = mMessageHandlers.begin(); itMessageHandler != mMessageHandlers.end(); ++itMessageHandler)
	{
		Real dt = (((0.5) < (evt.timeSinceLastFrame)) ? (0.5) : (evt.timeSinceLastFrame));
		(*itMessageHandler).second->tick(dt);
	}
	
	return true;
}

void CMessageBroadcaster::inject(MESSAGE_TYPE type, MESSAGE_ID id)
{
	std::map<Ogre::String, CMMPointer<IMessageHandler> >::iterator it = itMessageHandler;
	
	dispatch(type, id);

	if (id == MID_APP_QUIT)
	{
		itMessageHandler = mMessageHandlers.end();
		if (!mMessageHandlers.empty())
			itMessageHandler--;
	}
	else
	{
		itMessageHandler = it;
	}
}

void CMessageBroadcaster::dispatch(MESSAGE_TYPE type, MESSAGE_ID id)
{
	if (mMessageHandlers.empty()) return;
	itMessageHandler = mMessageHandlers.begin();
	for (; itMessageHandler != mMessageHandlers.end(); ++itMessageHandler)
	{
		(*itMessageHandler).second->handleMessage(type, id);
	}
}

void CMessageBroadcaster::dispatchMouse(MESSAGE_TYPE type, MESSAGE_ID id, const OIS::MouseEvent &evt)
{
	if (mMessageHandlers.empty()) return;

	itMessageHandler = mMessageHandlers.begin();
	for (; itMessageHandler != mMessageHandlers.end(); ++itMessageHandler)
	{
		(*itMessageHandler).second->handleMouseMessage(type, id, evt);
	}
}

void CMessageBroadcaster::dispatch(MESSAGE_TYPE type, const OIS::KeyEvent &evt)
{
	switch (evt.key)
	{
	//movement
	case OIS::KC_W:
		dispatch(type, MID_WALK_FORWARD);
		break;
	case OIS::KC_S:
		dispatch(type, MID_WALK_BACKWARD);
		break;
	case OIS::KC_A:
		dispatch(type, MID_STRAFE_LEFT);
		break;
	case OIS::KC_D:
		dispatch(type, MID_STRAFE_RIGHT);
		break;

	//run mode
	case OIS::KC_LSHIFT:
		dispatch(type, MID_RUN);
		break;
	case OIS::KC_CAPITAL:
		dispatch(type, MID_TOGGLE_RUN);
		break;

	//actions
	case OIS::KC_SPACE:
		dispatch(type, MID_SHOOT);
		break;

	//other
	case OIS::KC_PAUSE:
		dispatch(type, MID_PAUSE);
		break;

	//menu actions
	case OIS::KC_RETURN:
		dispatch(type, MID_MENU_CONFIRM);
		break;
	case OIS::KC_ESCAPE:
		dispatch(type, MID_MENU_CANCEL);
		dispatch(type, MID_MENU);
		break;

	default:
		break;
	}
}


MESSAGE_ID CMessageBroadcaster::mbToMessageId(const OIS::MouseButtonID &id)
{
	switch (id)
	{
	case OIS::MB_Left:
		return MID_SHOOT;
	default:
		break;
	}

	return MID_NONE;
}

void CMessageBroadcaster::refreshMessageHandlerList()
{
	IMessageHandler *tmp = NULL;
	//clear out deleted message handlers
	for (std::list<Ogre::String>::iterator it=mDeletedMessageHandlers.begin(); it != mDeletedMessageHandlers.end(); ++it)
	{
		if (mMessageHandlers.find(*it) != mMessageHandlers.end())
		{
			//mMessageHandlers.find(*it)->second->Release();
			mMessageHandlers.erase(*it);
			Ogre::LogManager::getSingleton().logMessage("Message Handler: Detached " + *it);
		}
		else
		{
			Ogre::LogManager::getSingleton().logMessage("WARNING: Message Handler: Detaching " + *it + " failed - not found");
		}
	}
	mDeletedMessageHandlers.clear();

	//add new message handlers
	for (itMessageHandler = mNewMessageHandlers.begin(); itMessageHandler != mNewMessageHandlers.end(); ++itMessageHandler)
	{
		if (mMessageHandlers.find(itMessageHandler->first) == mMessageHandlers.end())
		{
			mMessageHandlers[itMessageHandler->first] = itMessageHandler->second;
			Ogre::LogManager::getSingleton().logMessage("Message Handler: Attached " + itMessageHandler->first);
		}
		else
		{
			Ogre::LogManager::getSingleton().logMessage("WARNING: Message Handler: Attaching " + itMessageHandler->first + " failed - duplicate");
		}
	}
	mNewMessageHandlers.clear();

}