#pragma once

#include "IMessageHandler.h"

namespace Ogre
{
	class SceneManager;
}

class CTurretBehaviour;
class CBowlBehaviour;
class CMagnetBehaviour;

class CTurretSpawner : public IMessageHandler
{
public:
	CTurretSpawner(Ogre::SceneManager *mgr, 
		CTurretBehaviour *turretBehaviour, 
		CBowlBehaviour *bowlBehaviour,
		CMagnetBehaviour *magnetBehaviour);
	virtual ~CTurretSpawner(void);

	bool tick(Ogre::Real dt);

	bool handleMouseMessage(MESSAGE_TYPE type,MESSAGE_ID id,
		const OIS::MouseEvent &evt);

	bool handleMessage(MESSAGE_TYPE type, MESSAGE_ID id);

	IMM_AUTO_SIZE;
protected:
	Ogre::SceneManager *mSceneMgr;

	CMMPointer< CTurretBehaviour > mTurretBehaviour;
	CMMPointer< CBowlBehaviour > mBowlBehaviour;
	CMMPointer< CMagnetBehaviour > mMagnetBehaviour;

	int mWeaponCount;

	enum ACTIVE_WEAPON
	{
		AW_TURRET,
		AW_MAGNET,
		AW_BOWL
	} mActiveWeapon;
	float mWeaponCost;

	Ogre::SceneNode *mPlaceholderNode;
	Ogre::Real mPlaceholderBounceFactor;

	std::map<ACTIVE_WEAPON,Ogre::Entity*> mPlaceholderEntities;
	
	void spawnTurret(const Ogre::String &name, 
		const Ogre::String &nodeName, const Ogre::Vector3 &intPoint);
	void spawnMagnet(const Ogre::String &name, 
		const Ogre::String &nodeName, const Ogre::Vector3 &intPoint);
	void spawnBowl(const Ogre::String &name, 
		const Ogre::String &nodeName, const Ogre::Vector3 &intPoint);
	void changeToWeapon(CTurretSpawner::ACTIVE_WEAPON aw);
};