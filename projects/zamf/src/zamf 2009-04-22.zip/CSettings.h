#pragma once
#include "Ogre.h"

#include <map>

class CSettings : public Ogre::Singleton<CSettings>
{
public:
	CSettings(void);
	~CSettings(void);

	void loadSettings();

	inline int getInt(Ogre::String key){return mSettingsInt[key];}
	inline float getFloat(Ogre::String key){return mSettingsFloat[key];}
	inline Ogre::String getString(Ogre::String key){return mSettingsString[key];}
	inline Ogre::Vector3 getVector3(Ogre::String key){return mSettingsVector3[key];}

protected:
	std::map<std::string, int> mSettingsInt;
	std::map<std::string, float> mSettingsFloat;
	std::map<std::string, Ogre::String> mSettingsString;
	std::map<std::string, Ogre::Vector3> mSettingsVector3;
};
