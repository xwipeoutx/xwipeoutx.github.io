#include "CGameListener.h"

#include "CGameManager.h"

#include <Ogre.h>
#include <OIS/OIS.h>
#include <CEGUI/CEGUI.h>

using namespace Ogre;

CGameListener::CGameListener(CEGUI::System *gui)
: mGUISystem(gui)
{
	mRoot = Root::getSingletonPtr();
}

CGameListener::~CGameListener(void)
{
	LogManager::getSingleton().logMessage("Destroyed Game Listener");
	mRoot = NULL;
}

bool CGameListener::handleMouseMessage(MESSAGE_TYPE type, MESSAGE_ID id, const OIS::MouseEvent &evt)
{
	CEGUI::MouseButton mb = 
		(id == MID_LMB ? CEGUI::LeftButton :
		(id == MID_RMB ? CEGUI::RightButton :
		(id == MID_MMB ? CEGUI::MiddleButton :
		CEGUI::LeftButton)));
	switch (type)
	{
	case MT_DOWN:
		mGUISystem->injectMouseButtonDown(mb);
		break;
	case MT_UP:
		mGUISystem->injectMouseButtonUp(mb);
		break;
	case MT_NONE:
		mGUISystem->injectMouseMove(evt.state.X.rel, evt.state.Y.rel);
		break;
	}

	return true;
}

bool CGameListener::handleMessage(MESSAGE_TYPE type, MESSAGE_ID id)
{
	if (id == MID_APP_QUIT)
		CGameManager::getSingleton().shutdown();
	return true;
}

bool CGameListener::tick(Real dt)
{
	if (mRoot->getAutoCreatedWindow()->isClosed())
		CGameManager::getSingleton().shutdown();

	CEGUI::OgreCEGUIRenderer *ren = CGameManager::getSingleton().getGUIRenderer();
	//CGameManager::getSingleton().getGUIRenderer()->d_ourlistener;
	// unhook from current scene manager.
	//if (0)
	//if (ren->d_sceneMngr != NULL)
	//{
	//	ren->d_sceneMngr->removeRenderQueueListener(ren->d_ourlistener);
	//	ren->d_sceneMngr->addRenderQueueListener(ren->d_ourlistener);
	//}

	return true;
}