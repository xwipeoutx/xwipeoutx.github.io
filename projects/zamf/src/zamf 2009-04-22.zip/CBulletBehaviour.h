#pragma once
#include "IMessageHandler.h"
#include "IPhysicsResponse.h"

namespace Ogre
{
	class Vector3;
	class SceneNode;
	class SceneManager;
}
class btRigidBody;
class btCollisionShape;

class CBullet : public IPhysicsResponse
{
public:
	Ogre::SceneNode *mBulletNode;
	Ogre::Vector3 mDirection;
	Ogre::Real mRange;

	btRigidBody *mPhysObject;

	bool mDying;

	void Collide(IPhysicsResponse *other, btPersistentManifold* contactManifold, int flipFlop);
};

class CBulletBehaviour : public IMessageHandler
{
public:
	CBulletBehaviour(Ogre::SceneManager *sm);
	virtual ~CBulletBehaviour(void);

	void fireBullet(Ogre::Vector3 origin, Ogre::Vector3 direction, Ogre::Real range=40);

	bool tick(float dt);

	IMM_AUTO_SIZE;

protected:
	Ogre::SceneManager *mSceneMgr;

	std::list<CBullet*> *mBullets;
	std::list<CBullet*> *mBulletPool;
	int mNumBullets;
	int mNumPooledBullets;

	int mNumBulletsSpawned;
	int mNumBulletsDestroyed;
	int mNumBulletsMissed;

	//constant stuff
	btCollisionShape *mBulletShape;

	//functions
	std::list<CBullet*>::iterator DrownBullet(std::list<CBullet*>::iterator it);

	//settings
	float mInitialSpeed;
	float mMass;
	float mFriction;
	float mRestitution;
	float mDeactivationTime;
	float mCCDMotionThreshold;
};
