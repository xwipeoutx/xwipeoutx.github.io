#include <Ogre.h>

#include "CGameManager.h"
#include "CIntroState.h"
#include "CPlayState.h"
#include "IMMObject.h"

using namespace Ogre;

#ifdef DEBUG
	#define aZAMFDOHEAPCHK
#endif

#if OGRE_PLATFORM == PLATFORM_WIN32 || OGRE_PLATFORM == OGRE_PLATFORM_WIN32
#define WIN32_LEAN_AND_MEAN
#include "windows.h"

INT WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR strCmdLine, INT)
#else
int main(int argc, char **argv)
#endif
{

#ifdef ZAMFDOHEAPCHK
	_CrtSetDbgFlag(
		_CRTDBG_CHECK_ALWAYS_DF |
		_CRTDBG_CHECK_CRT_DF |
		_CRTDBG_CHECK_DEFAULT_DF
		);

	_heapchk();
#endif
	CGameManager *game = new CGameManager();
	try
	{
		game->start(new CPlayState());
	}
	catch(Exception& e)
	{
#if OGRE_PLATFORM == PLATFORM_WIN32 || OGRE_PLATFORM == OGRE_PLATFORM_WIN32
		MessageBoxA(NULL, e.getFullDescription().c_str(), "An exception has occurred!", MB_OK | MB_ICONERROR | MB_TASKMODAL);
#else
		fprintf(stderr, "An exception has occurred: %s\n",
			e.getFullDescription().c_str());
#endif
	}

#ifdef ZAMFDOHEAPCHK
	_heapchk();

	game->stop();
	_heapchk();

	IMMObject::CollectRemainingObjects(true);
	_heapchk();
#else
	game->stop();
	IMMObject::CollectRemainingObjects(true);
#endif

	delete game;
	//TODO: CLEAN IT UP PROPERLY
	/*
	game->stop();

	IMMObject::CollectRemainingObjects(true);
	*/
	return 0;
}
