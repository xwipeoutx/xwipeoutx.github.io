#include "CSoundBuffer.h"

#include "Ogre.h"
using namespace Ogre;

CSoundBuffer::CSoundBuffer(std::string filename)
: mFilename(filename)
{

	ALsizei size, freq;
	ALenum format;
	ALvoid *data;
	ALboolean loop=0;

	alGetError(); // clear error message
	alGenBuffers(1, &mALBuffer);
	if (alGetError() != AL_NO_ERROR)
	{
		LogManager::getSingleton().logMessage("CSoundBuffer: Error creating buffer");
	}

	alutLoadWAVFile((ALbyte*)filename.c_str(), &format, &data, &size, &freq, &loop);
	if (alGetError() != AL_NO_ERROR || size == 0)
	{
		LogManager::getSingleton().logMessage("CSoundBuffer: Error reading wav file");
	}

	alBufferData(mALBuffer, format, data, size, freq);
	alutUnloadWAV(format, data, size, freq);

	LogManager::getSingleton().logMessage("CSoundBuffer: Created new buffer");
}

CSoundBuffer::~CSoundBuffer(void)
{
	alDeleteBuffers(1, &mALBuffer);
}

String CSoundBuffer::GetFilename()
{
	return mFilename;
}

ALuint CSoundBuffer::GetBuffer()
{

	return mALBuffer;
}
