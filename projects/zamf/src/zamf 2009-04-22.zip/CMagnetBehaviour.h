#pragma once

#include "IMessageHandler.h"
#include "IPhysicsResponse.h"
#include <Ogre.h>

class CBowlBehaviour;
class btCollisionObject;
class btCollisionShape;

class CMagnet : public IPhysicsResponse
{
public:
	btCollisionObject *mPhysObject;
	Ogre::SceneNode *mNode;
	bool mIsActive;
	float mActivationTime;

	void Collide(IPhysicsResponse *other, btPersistentManifold* contactManifold, int flipFlop);
};

class CMagnetBehaviour : public IMessageHandler
{
public:
	CMagnetBehaviour(Ogre::SceneManager *sm);
	virtual ~CMagnetBehaviour(void);

	void addMagnet(Ogre::SceneNode *bowl);
	void clearMagnets();
	std::list<CMagnet*> &getMagnets(){return mMagnets;}

	bool tick(Ogre::Real dt);

	IMM_AUTO_SIZE;
protected:
	Ogre::SceneManager *mSceneMgr;
	std::list<CMagnet*> mMagnets;
	btCollisionShape *mMagnetShape;
};