#include "CMagnetBehaviour.h"
#include "CProfileSample.h"
#include "CPhysicsManager.h"
#include "CBowlBehaviour.h"

#include "BtOgreGP.h"
#include "BtOgrePG.h"

#include <Ogre.h>
#include "constants.h"

using namespace Ogre;

CMagnetBehaviour::CMagnetBehaviour(SceneManager *mgr)
: mSceneMgr(mgr)
{
	//mMagnetShape = new btSphereShape(1);
	mMagnetShape = new btBoxShape(btVector3(0.50, 0.50, 0.50));
	//mMagnetShape = new btBoxShape(btVector3(1, 1, 1));
}

CMagnetBehaviour::~CMagnetBehaviour(void)
{
	for(std::list<CMagnet*>::iterator it=mMagnets.begin();it!=mMagnets.end();++it)
	{
		CPhysicsManager::getSingleton().getWorld()->removeCollisionObject((*it)->mPhysObject);
		delete (*it)->mPhysObject->getUserPointer();
	}
	mMagnets.clear();
}

bool CMagnetBehaviour::tick(float dt)
{
	for(std::list<CMagnet*>::iterator it=mMagnets.begin();it!=mMagnets.end();++it)
	{
		if (!(*it)->mIsActive)
		{
			(*it)->mActivationTime -= dt;
			if ((*it)->mActivationTime < 0.0f)
			{
				(*it)->mIsActive = 1;
				(*it)->mNode->translate(0, 0.25, 0);
			}
		}
	}
	return true;
}

void CMagnetBehaviour::addMagnet(Ogre::SceneNode *magnetNode)
{
	PROFILE_THIS("Add Magnet");
	CMagnet *magnet = new CMagnet();
	magnet->mNode = magnetNode;
	magnet->mIsActive = true;
	magnet->mNode->translate(0,0.5,0);

	//create bt Object (physics)
	btTransform transform( 
		BtOgre::Convert::toBullet(magnetNode->getOrientation()), 
		BtOgre::Convert::toBullet(magnetNode->getPosition()));
	magnet->mPhysObject = new btCollisionObject();
	magnet->mPhysObject->setWorldTransform(transform);
	magnet->mPhysObject->setCollisionShape(mMagnetShape);
	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(magnet->mPhysObject, MVT_TURRET, MVT_PLAYER_CHARACTER|MVT_ENEMY|MVT_STATIONARY|MVT_PROJECTILE);
	IPR_ASSIGN_USER_POINTER(magnet->mPhysObject, magnet);

	mMagnets.push_back( magnet );	
}

void CMagnetBehaviour::clearMagnets()
{
	mMagnets.clear();
}

void CMagnet::Collide(IPhysicsResponse *other, btPersistentManifold *contactManifold, int flipFlop)
{	
	if (dynamic_cast<CBowl*>(other) != NULL && mIsActive) {
		mIsActive = 0;
		mActivationTime = 2.0f;
		mNode->translate(0, -0.25, 0);
	}
}
