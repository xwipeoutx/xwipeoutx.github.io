#ifndef _NOT_USING_THIS_PLAYER_CAMERA
#include "CPlayerCamera.h"
#include "CSettings.h"
#include "CPlayStateHelper.h"
#include "CDeadState.h"
#include "CGameManager.h"
#include "CSoundManager.h"

#include "CPhysicsManager.h"

using namespace Ogre;

template<> CPlayerCamera* Singleton<CPlayerCamera>::ms_Singleton = 0;

CPlayerCamera::CPlayerCamera(SceneManager *sm, const String &rootName, const Real maxHP)
	: mSceneMgr(sm),
	mXVelocity(0), mZVelocity(0),
	mRunning(false), IActor()
{
	//speeds and such
	mSpeed = CSettings::getSingleton().getFloat("playerSpeed");
	mRunMultiplier = CSettings::getSingleton().getFloat("playerRunMultiplier");
	mSensitivity = CSettings::getSingleton().getFloat("mouseSensitivity");
	mMaxHP = mCurrHP = CSettings::getSingleton().getFloat("playerMaxHP");
	mHeight = CSettings::getSingleton().getFloat("playerHeight");

	//base node
	this->mCameraNode =
		this->mSceneMgr->getRootSceneNode()->createChildSceneNode(rootName);
	this->mCameraNode->setPosition(0,0,0);

	//yaw
	this->mCameraYawNode =
		this->mCameraNode->createChildSceneNode(rootName + "Yaw");
	this->mCameraYawNode->setPosition(0,0,0);

	//pitch
	this->mCameraPitchNode =
		this->mCameraYawNode->createChildSceneNode(rootName + "Pitch");
	this->mCameraPitchNode->setPosition(0,0,0);

	//roll
	this->mCameraRollNode =
		this->mCameraPitchNode->createChildSceneNode(rootName + "Roll");
	this->mCameraRollNode->setPosition(0,0,0);

	//camera attachment
	mCamera = sm->createCamera(rootName + "Camera");
	this->mCameraRollNode->attachObject(this->mCamera);

	//settings
	mCamera->setNearClipDistance(0.05f);

	//bullet
	btTransform startTransform;
	startTransform.setIdentity ();
	startTransform.setOrigin (btVector3(0.0, 0.5*mHeight, 0.0));

	mGhostObject = new btPairCachingGhostObject();
	mGhostObject->setWorldTransform(startTransform);
	CPhysicsManager::getSingleton().getBroadphase()->
		getOverlappingPairCache()->setInternalGhostPairCallback(new btGhostPairCallback());

	btConvexShape *capsule = new btCapsuleShape(CSettings::getSingleton().getFloat("playerRadius"), mHeight);
	mGhostObject->setCollisionShape(capsule);
	mGhostObject->setCollisionFlags(btCollisionObject::CF_CHARACTER_OBJECT);
	IPR_ASSIGN_USER_POINTER(mGhostObject, this);

	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(mGhostObject, 
		MVT_PLAYER_CHARACTER, 
		MVT_STATIONARY | MVT_TURRET | MVT_PROJECTILE);
}

CPlayerCamera::~CPlayerCamera(void)
{
	//TODO: Destroy things!
	//TODO: Actually no, let the scene manager handle that
	
	//kill my ghost object
	mGhostObject->setCollisionShape(NULL);
	CPhysicsManager::getSingleton().getWorld()->removeCollisionObject(mGhostObject);
	delete mGhostObject;
	mGhostObject=NULL;
}

bool CPlayerCamera::handleMessage(MESSAGE_TYPE type, MESSAGE_ID id)
{
	if (id == MID_STOP_TIME) mXVelocity = mZVelocity = 0;
	if (!mTimeIsGoing) return true;

	if (type==MT_DOWN) msgDown(id);
	if (type==MT_UP) msgUp(id);

	return true;
}

bool CPlayerCamera::handleMouseMessage(MESSAGE_TYPE type, MESSAGE_ID id,
		const OIS::MouseEvent &evt)
{
	if (!mTimeIsGoing) return true;
	if (type == MT_NONE)
	{
	    this->yaw(Degree(-evt.state.X.rel * mSensitivity));
        this->pitch(Degree(-evt.state.Y.rel * mSensitivity));
	}
	return true;
}

bool CPlayerCamera::tick(float dt)
{
	if (!mTimeIsGoing) return true;
	Real moveBy = dt;
	if (mRunning)
		moveBy *= mRunMultiplier;

	move(Ogre::Vector3(mXVelocity*moveBy, 0, mZVelocity*moveBy));

	Real diff = this->mCameraNode->getPosition().y;
	this->mCameraNode->translate(Vector3(0,-diff + mHeight, 0), SceneNode::TS_PARENT);

	//update ghost object
	//btQuaternion q = BtOgre::Convert::toBullet(mCamera->getRealOrientation());
	btVector3 p = BtOgre::Convert::toBullet(mCamera->getRealPosition());
	p.setY(0.5*mHeight);
	mGhostObject->getWorldTransform().setOrigin(p);
	//mGhostObject->setWorldTransform(btTransform(q, p));

	return true;
}

void CPlayerCamera::msgDown(MESSAGE_ID id)
{
	switch (id){
	case MID_WALK_FORWARD:
		mZVelocity -= mSpeed;
		break;

	case MID_WALK_BACKWARD:
		mZVelocity += mSpeed;
		break;

	case MID_STRAFE_LEFT:
		mXVelocity -= mSpeed;
		break;

	case MID_STRAFE_RIGHT:
		mXVelocity += mSpeed;
		break;

	case MID_TOGGLE_RUN:
		mRunning = !mRunning;
		break;

	case MID_RUN:
		mRunning = true;
		break;
	default:
		break;
	}
}

void CPlayerCamera::msgUp(MESSAGE_ID id)
{
	switch (id){
	case MID_WALK_FORWARD:
		mZVelocity += mSpeed;
		break;

	case MID_WALK_BACKWARD:
		mZVelocity -= mSpeed;
		break;

	case MID_STRAFE_LEFT:
		mXVelocity += mSpeed;
		break;

	case MID_STRAFE_RIGHT:
		mXVelocity -= mSpeed;
		break;

	case MID_RUN:
		mRunning = false;
		break;
	default:
		break;
	}
}

void CPlayerCamera::Damage(float hp)
{
	IActor::Damage(hp);
	CPlayStateHelper::getSingleton().UpdateStats();
	if (this->IsAlive()) 
	{
		CSoundManager::getSingleton().PlayWav("../../resource/sounds/player/oof1.wav", mCamera->getRealPosition(), Vector3::ZERO);
	} 
	else 
	{
		CGameManager::getSingleton().pushState(new CDeadState());
	}
}

void CPlayerCamera::Collide(IPhysicsResponse *other, btPersistentManifold *contactManifold, int body)
{
	int numContacts = contactManifold->getNumContacts();
	btVector3 move(0,0,0);
	
	//move away by half the penetration distance of each point
	for (int i=0;i<numContacts;i++)
	{
		btManifoldPoint &c = contactManifold->getContactPoint(i);
		btVector3 n = 0.5*(c.m_positionWorldOnA-c.m_positionWorldOnB);
		if (body == 0)
			move -= n;
		else
			move += n;

	}
	move.setY(0);
	move *= 1.2;

	mCameraNode->translate(BtOgre::Convert::toOgre(move), Node::TS_PARENT);
	
	//update physics world transform
	Vector3 pos = mCameraNode->getPosition();
	btTransform currTrans = mGhostObject->getWorldTransform();
	currTrans.setOrigin(BtOgre::Convert::toBullet(mCameraNode->getPosition()));
	currTrans.setRotation(BtOgre::Convert::toBullet(mCameraNode->getOrientation()));
	mGhostObject->setWorldTransform(currTrans);
}

#endif

