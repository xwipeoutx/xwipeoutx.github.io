#pragma once

#include "IActor.h"
#include "IMessageHandler.h"

#include <Ogre.h>

class btCollisionObject;
class btCollisionShape;

class CZombieActor : public IActor
{
public:
	enum AI_STATE 
	{
		AI_SEEKING,
		AI_SWINGING,
		AI_COOLING,
		AI_DEAD
	};

	Ogre::SceneNode *zombieNode;
	btCollisionObject *ghostObject;
	AI_STATE state;

	Ogre::Real cooldown;

	void Collide(IPhysicsResponse *other, btPersistentManifold* contactManifold, int flipFlop);
};

class CZombieBehaviour : public IMessageHandler, public Ogre::Singleton<CZombieBehaviour>
{
public:
	CZombieBehaviour(Ogre::SceneManager *sm);
	virtual ~CZombieBehaviour(void);

	void addZombie(Ogre::SceneNode *zombie, Ogre::Entity *entity);
	bool tick(float dt);
	int getNumSpawned(){return mNumSpawned;}
	int getNumKills(){return mNumKills;}
	
	IMM_AUTO_SIZE;
protected:
	std::list<CZombieActor*>::iterator KillZombie(std::list<CZombieActor*>::iterator it);

	Ogre::SceneManager *mSceneMgr;
	std::list<CZombieActor*> *mZombies;
	
	btCollisionShape *mZombieShape;
	
	int mNumSpawned;
	int mNumKills;

	float mMaxHP;
	float mSpeed;
	float mWorth;

	float mCooldown;
	float mAttackSpeed;
	float mAttackRange2;
	float mAttackPower;

	float mHPIncrease1;
	float mHPIncrease2;
	float mHPIncreaseExp1;
	float mHPIncreaseExp2;
private:
};
