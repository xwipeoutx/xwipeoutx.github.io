#pragma once
#include "Ogre.h"

class CMapGrid : public Ogre::Singleton<CMapGrid>
{
public:
	
	enum MapCellContents {
		MCC_EMPTY,
		MCC_STATIONARY,
		MCC_WEAPON,
		MCC_ENEMY,
		MCC_OUT_OF_BOUNDS
	};
	
	CMapGrid(Ogre::Vector3 min, Ogre::Vector3 max);
	virtual ~CMapGrid(void);

	void InitMapContents();
	void PopulateFromScene(Ogre::SceneManager *mgr);

	void SetMapCellContents(int x, int y, MapCellContents m){mMapCells[x][y] = m;}
	void SetMapCellContents(const Ogre::Vector3 &v, MapCellContents m){int x,z; GridToXZ(v,x,z); mMapCells[x][z] = m;}
	MapCellContents GetMapCellContents(int x, int y){return mMapCells[x][y];}

	MapCellContents GetMapCellContents(const Ogre::Vector3 &v);

	void GridToXZ(const Ogre::Vector3 &v, int &x, int &z);
	Ogre::Vector3 XZtoGrid(int x, int z);

	Ogre::Vector3 GetCellCentre(const Ogre::Vector3 &v);
protected:
	MapCellContents **mMapCells;
	int mXMax;
	int mZMax;
	Ogre::Vector3 mDist;
	Ogre::Vector3 mMin;
	Ogre::Vector3 mMax;
};
