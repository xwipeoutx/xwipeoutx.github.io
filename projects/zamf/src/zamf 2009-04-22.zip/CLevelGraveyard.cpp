#include "CLevelGraveyard.h"

#include "CMessageBroadcaster.h"
#include "CSoundManager.h"

#include "CBulletBehaviour.h"
#include "CTurretBehaviour.h"
#include "CTurretSpawner.h"
#include "CBowlBehaviour.h"
#include "CMagnetBehaviour.h"
#include "CZombieBehaviour.h"
#include "CZombieSpawner.h"

#include "CPhysicsBehaviour.h"
#include "CPhysicsManager.h"

#include "CSettings.h"
#include "CBank.h"
#include "constants.h"

#include "CMapGrid.h"

#include <Ogre.h>

#include "BtOgreExtras.h"

using namespace Ogre;

CLevelGraveyard::CLevelGraveyard(Ogre::SceneManager *mgr)
: ILevel(mgr)
{
	LogManager::getSingleton().logMessage("Loading Graveyard...");
	PreloadObjects();
	LoadBehaviours();
	LoadSounds();
	CreateScene();
	CSoundManager::getSingleton().PlayLoop("../../resource/sounds/music/drumloop1.wav");
	LogManager::getSingleton().logMessage("Done Loading Graveyard...");
	(new CMapGrid(Vector3(-50, 0, -50),Vector3(50, 0, 50)))->PopulateFromScene(mSceneMgr);

	for (float i=-50; i<50;i+=1)
	{
		for (float j=-50; j<50;j+=1)
		{
			Vector3 pos(i, 0, j);
			if (CMapGrid::getSingleton().GetMapCellContents(pos) == CMapGrid::MCC_STATIONARY)
			{
				Ogre::String entName = "RandomBall"+Ogre::StringConverter::toString(i);
				entName += "x" + Ogre::StringConverter::toString(j);
				Entity *entity = mSceneMgr->createEntity(entName, SceneManager::PT_CUBE);
				entity->setQueryFlags(MVT_STATIONARY);
				entity->setCastShadows(false);
				SceneNode *mesh = mSceneMgr->getRootSceneNode()->createChildSceneNode(pos);
				mesh->scale(0.002*(Vector3(1,1,1)));
				mesh->attachObject(entity);
			}
		}
	}
}

CLevelGraveyard::~CLevelGraveyard(void)
{
	CSoundManager::getSingleton().ClearAllEverything();
	CPhysicsManager::getSingleton().destroyDebugger();

	CMessageBroadcaster::getSingleton().detach("BowlBehaviour");
	CMessageBroadcaster::getSingleton().detach("MagnetBehaviour");
	CMessageBroadcaster::getSingleton().detach("BulletBehaviour");
	CMessageBroadcaster::getSingleton().detach("TurretBehaviour");
	CMessageBroadcaster::getSingleton().detach("TurretSpawner");
	
	CMessageBroadcaster::getSingleton().detach("ZombieBehaviour");
	CMessageBroadcaster::getSingleton().detach("ZombieSpawner");
	
	CMessageBroadcaster::getSingleton().detach("LevelGraveyardPhysicsBehaviour");

	mTurretBehaviour = NULL;
	mZombieBehaviour = NULL;
	mTurretSpawner = NULL;
	mZombieSpawner = NULL;

	mSceneMgr->clearScene();
	delete CMapGrid::getSingletonPtr();
	
	btDynamicsWorld *world = CPhysicsManager::getSingleton().getWorld();
	//get rid of physics objects
	mGround->setCollisionShape(NULL);
	world->removeCollisionObject(mGround);
	delete mGroundShape;
	delete mGround;

	mWall1->setCollisionShape(NULL);
	world->removeCollisionObject(mWall1);
	delete mWallShape1;
	delete mWall1;

	mWall2->setCollisionShape(NULL);
	world->removeCollisionObject(mWall2);
	delete mWallShape2;
	delete mWall2;

	mWall3->setCollisionShape(NULL);
	world->removeCollisionObject(mWall3);
	delete mWallShape3;
	delete mWall3;

	mWall4->setCollisionShape(NULL);
	world->removeCollisionObject(mWall4);
	delete mWallShape4;
	delete mWall4;
}


void CLevelGraveyard::LoadBehaviours()
{
	LogManager::getSingleton().logMessage("Loading Behaviours...");
	mBulletBehaviour = new CBulletBehaviour(mSceneMgr);
	mMagnetBehaviour = new CMagnetBehaviour(mSceneMgr);
	mBowlBehaviour = new CBowlBehaviour(mSceneMgr, mMagnetBehaviour);
	mTurretBehaviour = new CTurretBehaviour(mSceneMgr, mBulletBehaviour);
	mTurretSpawner =  new CTurretSpawner(mSceneMgr, mTurretBehaviour, mBowlBehaviour, mMagnetBehaviour);
	mZombieBehaviour =  new CZombieBehaviour(mSceneMgr);
	mZombieSpawner =  new CZombieSpawner(mSceneMgr, mZombieBehaviour);
	mPhysicsBehaviour = new CPhysicsBehaviour();

	CMessageBroadcaster::getSingleton().attach(mBulletBehaviour, "BulletBehaviour");
	CMessageBroadcaster::getSingleton().attach(mTurretBehaviour, "TurretBehaviour");
	CMessageBroadcaster::getSingleton().attach(mTurretSpawner , "TurretSpawner");
	CMessageBroadcaster::getSingleton().attach(mMagnetBehaviour, "MagnetBehaviour");
	CMessageBroadcaster::getSingleton().attach(mBowlBehaviour, "BowlBehaviour");
	CMessageBroadcaster::getSingleton().attach(mZombieBehaviour, "ZombieBehaviour");
	CMessageBroadcaster::getSingleton().attach(mZombieSpawner , "ZombieSpawner");
	CMessageBroadcaster::getSingleton().attach(mPhysicsBehaviour , "LevelGraveyardPhysicsBehaviour");

	CBank::getSingleton().SetCash(CSettings::getSingleton().getFloat("bankInitialFunds"));
}

void CLevelGraveyard::PreloadObjects()
{
	LogManager::getSingleton().logMessage("Loading Objects...");
	MeshManager::getSingleton().load("zombie.mesh", ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME);
	MeshManager::getSingleton().load("turret.mesh", ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME);
	MeshManager::getSingleton().load("cube.1m.mesh", ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME);
	mSceneMgr->createEntity("PREFAB_SPHERE", SceneManager::PT_SPHERE);
	MaterialManager::getSingleton().load("ZAMF/Ground", ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME);
}

void CLevelGraveyard::CreateScene()
{
	LogManager::getSingleton().logMessage("Creating Scene...");
	//set up scene to be cool - shadows and all
	mSceneMgr->setAmbientLight(ColourValue(0.0, 0.0, 0.0));
	mSceneMgr->setShadowTechnique(SHADOWTYPE_STENCIL_ADDITIVE);

	Entity *ent = NULL;

	//Create the ground
	Plane plane(Vector3::UNIT_Y, 0);
	MeshManager::getSingleton().createPlane("ground",
		ResourceGroupManager::DEFAULT_RESOURCE_GROUP_NAME, plane,
		100, 100, 20, 20, true, 1, 1, 1, Vector3::UNIT_Z);
	ent = mSceneMgr->createEntity("GroundEntity", "ground");
	ent->setMaterialName("ZAMF/Ground");
	ent->setCastShadows(false);
	ent->setQueryFlags(MVT_STATIONARY);
	mSceneMgr->getRootSceneNode()->createChildSceneNode("GroundNode")->attachObject(ent);

	//Light it up eddy
	Light *light;
	light = mSceneMgr->createLight("MoonLight");
	light->setType(Light::LT_DIRECTIONAL);
	light->setDirection(1, -1, -0.5);
	light->setDiffuseColour(0.7, 0.7, 1.0);
	light->setSpecularColour(0.7, 0.7, 1.0);

	//skybox
	mSceneMgr->setSkyBox(true, "ZAMF/NightSky");

	//attach a physics debug drawer
	SceneNode *phyDebugNode = mSceneMgr->getRootSceneNode()->createChildSceneNode();
	CPhysicsManager::getSingleton().createDebugger(phyDebugNode);
	CPhysicsManager::getSingleton().getWorld()->setDebugDrawer(CPhysicsManager::getSingleton().getDebugDrawer());

	btTransform transform = btTransform::getIdentity();

	mGroundShape = new btStaticPlaneShape(btVector3(0,1,0),0);
	mGround = new btCollisionObject();
	mGround->setCollisionShape(mGroundShape);
	mGround->setWorldTransform(transform);
	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(mGround, MVT_STATIONARY);

	//and the Walls
	mWallShape1 = new btStaticPlaneShape(btVector3(-1,0,0),-50);
	mWall1 = new btCollisionObject();
	mWall1->setCollisionShape(mWallShape1);
	mWall1->setWorldTransform(transform);
	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(mWall1, MVT_STATIONARY);
	
	mWallShape2 = new btStaticPlaneShape(btVector3(1,0,0),-50);
	mWall2 = new btCollisionObject();
	mWall2->setCollisionShape(mWallShape2);
	mWall2->setWorldTransform(transform);
	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(mWall2, MVT_STATIONARY);
	
	mWallShape3 = new btStaticPlaneShape(btVector3(0,0,-1),-50);
	mWall3 = new btCollisionObject();
	mWall3->setCollisionShape(mWallShape3);
	mWall3->setWorldTransform(transform);
	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(mWall3, MVT_STATIONARY);
	
	mWallShape4 = new btStaticPlaneShape(btVector3(0,0,1),-50);
	mWall4 = new btCollisionObject();
	mWall4->setCollisionShape(mWallShape4);
	mWall4->setWorldTransform(transform);
	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(mWall4, MVT_STATIONARY);
}

void CLevelGraveyard::LoadSounds()
{
	CSoundManager::getSingleton().AddSound("../../resource/sounds/music/drumloop1.wav");
	CSoundManager::getSingleton().AddSound("../../resource/sounds/guns/turret_fire.wav");
	CSoundManager::getSingleton().AddSound("../../resource/sounds/zombie/attack1.wav");
	CSoundManager::getSingleton().AddSound("../../resource/sounds/zombie/hit1.wav");
	CSoundManager::getSingleton().AddSound("../../resource/sounds/player/death1.wav");
}