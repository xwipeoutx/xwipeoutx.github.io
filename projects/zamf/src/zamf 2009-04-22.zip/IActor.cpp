#include "IActor.h"

IActor::IActor(void)
{
}

IActor::~IActor(void)
{
}


void IActor::Damage(float hp)
{
	mCurrHP -= hp;
	if (mCurrHP < 0.0001)
	{
		mCurrHP = 0;
		mIsAlive = false;
	}

}

void IActor::Restore(float hp)
{
	if (mIsAlive)
	{
		mCurrHP += hp;
		if (mCurrHP > mMaxHP)
		{
			mCurrHP = mMaxHP;
		}
	}
}