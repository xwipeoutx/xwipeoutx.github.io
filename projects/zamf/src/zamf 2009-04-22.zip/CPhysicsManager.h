#pragma once
#include <Ogre.h>
#include "BtOgreExtras.h"
class IPhysicsResponse;

#include "btBulletCollisionCommon.h"
#include "btBulletDynamicsCommon.h"

class CPhysicsManager :	public Ogre::Singleton<CPhysicsManager>
{
public:
	CPhysicsManager(void);
	~CPhysicsManager(void);

	inline btDynamicsWorld *getWorld(){return mWorld;}
	inline btBroadphaseInterface *getBroadphase(){return mBroadphase;}
	inline btDispatcher *getDispatcher(){return mDispatcher;}
	inline btConstraintSolver *getSolver(){return mSolver;}
	inline btCollisionConfiguration *getCollisionConfiguration(){return mCollisionConfiguration;}

	void createDebugger(Ogre::SceneNode *node);
	inline BtOgre::DebugDrawer *getDebugDrawer(){return mDbgDraw;}
	void destroyDebugger();

	inline IPhysicsResponse *GetResponseFromPointer(btCollisionObject *obj)
	{
		void *ptr = obj ? obj->getUserPointer() : NULL;
		return ptr
			? Ogre::any_cast<IPhysicsResponse*>(* static_cast<Ogre::Any*>(ptr) )
			: NULL;
	}
protected:
	btDynamicsWorld *mWorld;
	btBroadphaseInterface *mBroadphase;
	btDispatcher *mDispatcher;
	btConstraintSolver *mSolver;

	btCollisionConfiguration *mCollisionConfiguration;

	BtOgre::DebugDrawer *mDbgDraw;
};
