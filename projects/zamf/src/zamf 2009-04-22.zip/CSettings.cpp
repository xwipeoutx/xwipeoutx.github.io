#include "CSettings.h"

using namespace Ogre;

template<> CSettings* Singleton<CSettings>::ms_Singleton = 0;
CSettings::CSettings(void)
{
	loadSettings();
}

CSettings::~CSettings(void)
{
}

void CSettings::loadSettings()
{
	//default values

/*
[float]
; Player
playerHeight=1.9
playerSpeed=10.0
playerRunMultiplier=10.0
playerMaxHP=100.0
playerStartYaw=0
playerStartPitch=0
mouseSensitivity=0.2

;bank
bankInitialFunds=10

; Zombie Behaviour
zombieSpeed=5.5
zombieWorth=2.0
zombieCooldown=1.0
zombieAttackSpeed=0.5
zombieAttackRange2=2.0
zombieAttackPower=10.0

; Zombie HitPoints
zombieMaxHP=100.0
zombieHPIncrease1=0.05
zombieHPIncrease2=0
zombieHPIncreaseExp1=1.01
zombieHPIncreaseExp2=1.0

; Turret
turretIdleSpeed=45
turretTargetingSpeed=360
turretCooldown=0.5
turretCost=10

; Bullet (aka nail)
bulletInitialSpeed=100
bulletMass=1.0
bulletFriction=1.0
bulletRestitution=0.1
bulletDeactivationTime=1.0
bulletCCDMotionThreshold=0.04

bulletDamage=20

;bowl - todo
bowlDamageMultiplier=5
bowlCost=5

;magnet - todo
magnetCost=20

[vector3]
playerStartPosition=0 0 0
*/

	//override
	Ogre::ConfigFile cfg;
	cfg.loadDirect("../../resource/settings.ini");
	{
	Ogre::ConfigFile::SettingsIterator it = cfg.getSettingsIterator("float");
	while (it.hasMoreElements())
	{
		mSettingsFloat[it.peekNextKey()] = StringConverter::parseReal( it.peekNextValue() );
		it.getNext();
	}
	}

	{
	Ogre::ConfigFile::SettingsIterator it = cfg.getSettingsIterator("vector3");
	while (it.hasMoreElements())
	{
		mSettingsVector3[it.peekNextKey()] = StringConverter::parseVector3( it.peekNextValue() );
		it.getNext();
	}
	}

}
