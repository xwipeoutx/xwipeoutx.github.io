#include "IAIBehaviour.h"

IAIBehaviour::IAIBehaviour(void)
{
}

IAIBehaviour::~IAIBehaviour(void)
{
}
