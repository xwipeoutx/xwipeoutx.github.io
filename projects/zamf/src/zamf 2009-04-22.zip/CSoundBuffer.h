#pragma once
#include "IMMObject.h"

#include "Ogre.h"

#include <AL/al.h>
#include <AL/alut.h>

class CSoundBuffer : public IMMObject
{
public:
	CSoundBuffer(Ogre::String filename);
	~CSoundBuffer(void);


	ALuint GetBuffer();

	std::string GetFilename();
	IMM_AUTO_SIZE;
protected:
	Ogre::String mFilename;

	ALuint mALBuffer;
};
