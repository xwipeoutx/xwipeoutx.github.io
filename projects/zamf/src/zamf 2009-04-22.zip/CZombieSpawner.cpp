#include "CZombieSpawner.h"

#include "CPlayerCamera.h"
#include "CZombieBehaviour.h"
#include "constants.h"

#include <Ogre.h>
using namespace Ogre;

CZombieSpawner::CZombieSpawner(Ogre::SceneManager *mgr, CZombieBehaviour *zombieBehaviour)
: mZombieCount(0), mSceneMgr(mgr), mZombieBehaviour(zombieBehaviour)
{
}

CZombieSpawner::~CZombieSpawner(void)
{
}

bool CZombieSpawner::tick(Ogre::Real dt)
{
	if (dt < 0.00001f) return true;
	if (!mTimeIsGoing) return true;

	bool spawnZombie = false;
	Real zombieChance=0.0f;

	int numKills = mZombieBehaviour->getNumKills();
	if (numKills >=  0) zombieChance = 0.5;
	if (numKills >=  5) zombieChance = 0.7;
	if (numKills >= 10) zombieChance = 1.0;
	if (numKills >= 20) zombieChance = 2;
	if (numKills >= 30) zombieChance = 4;
	if (numKills >= 40) zombieChance = 8;

	if (Ogre::Math::RangeRandom(0, 1) <= zombieChance*dt)
		spawnZombie = true;
	if (mZombieBehaviour->getNumSpawned() - numKills > 50) 
		spawnZombie = false;

	if (!spawnZombie)
		return true;

	
	//get random zombie position
	Vector3 playerPos = CPlayerCamera::getSingleton().getCamera()->getRealPosition();
	playerPos.y = 0;
	Vector3 rand(Ogre::Math::RangeRandom(-50, 50),0,Ogre::Math::RangeRandom(-50, 50));
	while(playerPos.squaredDistance(rand) < 100.0f)
	{
		rand = Vector3(Ogre::Math::RangeRandom(-50, 50),0,Ogre::Math::RangeRandom(-50, 50));
	}

	//spawn a zombie
	String zombieName = "Zombie" + StringConverter::toString(mZombieCount++);
	String zombieNodeName = "ZombieNode" + StringConverter::toString(mZombieCount);

	Entity *ent=NULL;
	ent = mSceneMgr->createEntity(zombieName, "zombie.mesh");
	ent->setQueryFlags(MVT_ENEMY);
	//ent->setCastShadows(true);
	SceneNode *zomb = mSceneMgr->getRootSceneNode()->createChildSceneNode(zombieNodeName);
	rand.y = ent->getBoundingBox().getHalfSize().y;
	zomb->setPosition(rand);
	//zomb->yaw(Degree(30));
	//mSceneMgr->getSceneNode(zombieNodeName)->scale(Vector3(0.05, 0.05, 0.05));
	zomb->attachObject(ent);
	//RenderOperation op;
	//ent->getRenderOperation(op);

	mZombieBehaviour->addZombie(zomb,ent);

	return true;
}