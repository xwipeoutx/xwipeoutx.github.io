#pragma once

#include <Ogre.h>

#include "IGameState.h"
#include "CPauseListener.h"

class CPauseState : public IGameState
{
public:
	CPauseState();

	void enter();
	void exit();

	void pause();
	void resume();

	inline virtual const Ogre::String getStateName(){return Ogre::String("Pause");}

	IMM_AUTO_SIZE;

protected:
	Ogre::Root *mRoot;
	Ogre::SceneManager *mSceneMgr;
	Ogre::Viewport *mViewport;
	Ogre::Camera *mCamera;

	CMMPointer< CPauseListener > mListener;
};
