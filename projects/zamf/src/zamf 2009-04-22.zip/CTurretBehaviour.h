#pragma once

#include "IMessageHandler.h"
#include "IPhysicsResponse.h"

#include <Ogre.h>
class CBulletBehaviour;
class btCollisionObject;
class btCollisionShape;

class CTurret : public IPhysicsResponse
{
public:
	btCollisionObject *mPhysObject;
	Ogre::SceneNode *mTurretNode;
	Ogre::SceneNode *mTargetNode;
	Ogre::Real mTargetInitialDistanceSquared;
	Ogre::Vector3 mPosition;
	bool mSearching;

	Ogre::SphereSceneQuery *mQuery;
	
	Ogre::Real mTimeUntilNextShot;

	void Collide(IPhysicsResponse *other, btPersistentManifold* contactManifold, int flipFlop){}
};

class CTurretBehaviour : public IMessageHandler, public Ogre::Node::Listener
{
public:
	CTurretBehaviour(Ogre::SceneManager *sm, CBulletBehaviour *bulletBehaviour);
	virtual ~CTurretBehaviour(void);

	void addTurret(Ogre::SceneNode *turret);
	void clearTurrets();

	bool tick(Ogre::Real dt);

	virtual void nodeDestroyed(const Ogre::Node *);

	IMM_AUTO_SIZE;
protected:
	Ogre::SceneManager *mSceneMgr;

	std::list<CTurret*> mTurrets;

	CMMPointer< CBulletBehaviour > mBulletBehaviour;

	float mIdleSpeed;
	float mTargetingSpeed;
	float mCooldown;
	float mRange;

	btCollisionShape *mTurretShape;
private:
};
