#include <Ogre.h>

#include "CGameManager.h"
#include "CSoundManager.h"
#include "CInputManager.h"
#include "IGameState.h"
#include "CMessageBroadcaster.h"
#include "CSettings.h"

#include "CGameListener.h"
#include "CPhysicsManager.h"

#include "CProfileSample.h"
#include "CProfilerLogHandler.h"

using namespace Ogre;

template<> CGameManager* Singleton<CGameManager>::ms_Singleton = 0;

CGameManager::CGameManager()
{
	mDying = false;
	mInputManager = 0;

	mGUIRenderer = 0;
	mGUISystem = 0;
	mMsgBroadcaster = 0;

	mRoot = 0;
	mRoot = new Root("plugins.cfg", "zamf.cfg", "zamf.log");

	Ogre::LogManager::getSingleton().logMessage("GameManager created");

	CProfilerLogHandler *profilerLogHandler = new CProfilerLogHandler();
	CProfileSample::outputHandler = profilerLogHandler;
}

CGameManager::~CGameManager()
{
	CProfileSample::Output();
	delete CProfileSample::outputHandler;

	if (CPhysicsManager::getSingletonPtr())
		delete CPhysicsManager::getSingletonPtr();

	if (CSettings::getSingletonPtr())
		delete CSettings::getSingletonPtr();


	if (mRoot)
		delete mRoot;

}

void CGameManager::start(IGameState* state)
{
	Ogre::LogManager::getSingleton().logMessage("GameManager started");

	//load the configuration, either by showing the window or reading the cfg file
	if (!configure())
		return;

	setupResources();
	setupCEGUI();
	setupPhysics();

	//Set up input
	mInputManager = new CInputManager(mRoot->getAutoCreatedWindow());
	mMsgBroadcaster = new CMessageBroadcaster(mInputManager);

	new CSoundManager();

	mRoot->addFrameListener(this);

	mMsgBroadcaster->attach(new CGameListener(mGUISystem), "GameListener");

	changeState(state);


	Ogre::LogManager::getSingleton().logMessage("=== ENTERING MAIN LOOP ===");
	{
	PROFILE_THIS("mRoot->startRendering()");
	mRoot->startRendering();
	}
	Ogre::LogManager::getSingleton().logMessage("=== AFTER MAIN LOOP ===");
	Ogre::String avgFPS = Ogre::StringConverter::toString(mRenderWindow->getAverageFPS());
	Ogre::String bestFPS = Ogre::StringConverter::toString(mRenderWindow->getBestFPS());
	Ogre::String worstFPS = Ogre::StringConverter::toString(mRenderWindow->getWorstFPS());
	Ogre::LogManager::getSingleton().logMessage("FPS: avg " + avgFPS + " best " + bestFPS + " worst " + worstFPS);
}

void CGameManager::stop()
{
	Ogre::LogManager::getSingleton().logMessage("GameManager stopping");


	Ogre::LogManager::getSingleton().logMessage("Detaching Listener");
	//clean up msg handling
	mMsgBroadcaster->detach("GameListener");


	Ogre::LogManager::getSingleton().logMessage("Cleaning up states");
	// clean up all the states
	while (!mStates.empty()) {
		mStates.back()->exit();
		mStates.back()->Release();
		mStates.pop_back();
	}


	Ogre::LogManager::getSingleton().logMessage("Deleting random stuff");
	if (mMsgBroadcaster)
		delete mMsgBroadcaster;

	if (mInputManager)
		delete mInputManager;

	if (CSoundManager::getSingletonPtr())
		delete CSoundManager::getSingletonPtr();

	Ogre::LogManager::getSingleton().logMessage("GameManager stopped");

}

void CGameManager::shutdown()
{
	mDying = true;
}

void CGameManager::changeState(IGameState *state)
{
	// cleanup the current state
	while ( !mStates.empty() ) {
		mStates.back()->exit();
		mStates.back()->Release();
		mStates.pop_back();
	}

	// end the program if state==NULL and mStates is empty
	if (mStates.empty() && state == NULL) {
		mMsgBroadcaster->inject(MT_NONE, MID_APP_QUIT);
	}

	// store and init the new state
	state->AddRef();
	mStates.push_back(state);
	mStates.back()->enter();

#ifdef DEBUG
	Ogre::String msg = "CGameManager: States are now: ";
	if (!mStates.empty())
	for (std::vector<IGameState*>::iterator it=mStates.begin(); it!=mStates.end(); ++it)
	{
		msg += "|";
		msg += typeid(**it).name();
		msg += "| ";
	}
	else
		msg += "EMPTY!";
	Ogre::LogManager::getSingleton().logMessage(msg);
#endif
}

void CGameManager::pushState(IGameState* state)
{
	// pause current state
	if ( !mStates.empty() ) {
		mStates.back()->pause();
	}

	// store and init the new state
	state->AddRef();
	mStates.push_back(state);
	mStates.back()->enter();

#ifdef DEBUG
	Ogre::String msg = "CGameManager: States are now: ";
	if (!mStates.empty())
	for (std::vector<IGameState*>::iterator it=mStates.begin(); it!=mStates.end(); ++it)
	{
		msg += "|";
		msg += typeid(**it).name();
		msg += "| ";
	}
	else
		msg += "EMPTY!";
	Ogre::LogManager::getSingleton().logMessage(msg);
#endif
}

void CGameManager::popState()
{
	// cleanup the current state
	if ( !mStates.empty() ) {
		mStates.back()->exit();
		mStates.back()->Release();
		mStates.pop_back();
	}

	// resume previous state
	if ( !mStates.empty() ) {
		mStates.back()->resume();
	}

#ifdef DEBUG
	Ogre::String msg = "CGameManager: States are now: ";
	if (!mStates.empty())
	for (std::vector<IGameState*>::iterator it=mStates.begin(); it!=mStates.end(); ++it)
	{
		msg += "|";
		msg += typeid(**it).name();
		msg += "| ";
	}
	else
		msg += "EMPTY!";
	Ogre::LogManager::getSingleton().logMessage(msg);
#endif
}

void CGameManager::setupResources(void)
{
	// load resource paths from config file
	ConfigFile cf;
	cf.load("resources.cfg");

	// go through all settings in the file
	ConfigFile::SectionIterator seci = cf.getSectionIterator();

	String secName, typeName, archName;
	while (seci.hasMoreElements())
	{
		secName = seci.peekNextKey();
		ConfigFile::SettingsMultiMap *settings = seci.getNext();
		ConfigFile::SettingsMultiMap::iterator i;
		for (i = settings->begin() ; i != settings->end() ; ++i)
		{
			typeName = i->first;
			archName = i->second;
			ResourceGroupManager::getSingleton().addResourceLocation(
				archName, typeName, secName);

		}
	}
	TextureManager::getSingleton().setDefaultNumMipmaps(5);
	ResourceGroupManager::getSingleton().initialiseAllResourceGroups();

}

bool CGameManager::configure(void)
{
	// load config settings from ogre.cfg
	if (!mRoot->restoreConfig())
	{
		// if there is no config file, show the configuration dialog
		if (!mRoot->showConfigDialog())
		{
			return false;
		}
	}

	//start up the settings singleton
	new CSettings();

	// initialise and create a default rendering window
	mRenderWindow = mRoot->initialise(true, "Zombies are Attacking My Fridge");

	return true;
}

void CGameManager::setupCEGUI(void)
{
	mGUIRenderer = new CEGUI::OgreCEGUIRenderer(mRenderWindow, Ogre::RENDER_QUEUE_OVERLAY, false, 3000);
	mGUISystem = new CEGUI::System(mGUIRenderer);

#ifdef DEBUG_VERBOSE
	CEGUI::Logger::getSingleton().setLoggingLevel(CEGUI::Insane);
#endif
	CEGUI::SchemeManager::getSingleton().loadScheme((CEGUI::utf8*)"TaharezLookSkin.scheme");

	mGUISystem->setDefaultMouseCursor((CEGUI::utf8*)"TaharezLook", (CEGUI::utf8*)"MouseArrow");
	mGUISystem->setDefaultFont((CEGUI::utf8*)"BlueHighway-12");

	CEGUI::WindowManager::getSingleton().loadWindowLayout((CEGUI::utf8*)"zamfmenu.layout");
}

bool CGameManager::frameEnded(const FrameEvent& evt)
{
	IMMObject::CollectGarbage();
	return !mDying;
}

CGameManager* CGameManager::getSingletonPtr(void)
{
	return ms_Singleton;
}

CGameManager& CGameManager::getSingleton(void)
{
	assert(ms_Singleton);
	return *ms_Singleton;
}

void CGameManager::setupStates()
{
}

void CGameManager::setupPhysics()
{
	new CPhysicsManager();
}
