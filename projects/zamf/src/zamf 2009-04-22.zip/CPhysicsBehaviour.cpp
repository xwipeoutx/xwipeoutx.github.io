#include "CPhysicsBehaviour.h"

#include "IPhysicsResponse.h"
#include "CPhysicsManager.h"
#include "BtOgreGP.h"

#include "CPlayStateHelper.h"
#include "CProfileSample.h"

#include "Ogre.h"
using namespace Ogre;

void tickCallback(btDynamicsWorld *world, btScalar timeStep)
{
	static_cast<CPhysicsBehaviour*>(world->getWorldUserInfo())->dispatchCollisions(world);
}

CPhysicsBehaviour::CPhysicsBehaviour(void)
: mDoDebug(false)
{
	CPhysicsManager::getSingleton().getWorld()->setInternalTickCallback(tickCallback);
}

CPhysicsBehaviour::~CPhysicsBehaviour(void)
{
}

bool CPhysicsBehaviour::tick(Ogre::Real dt)
{
	if (!mTimeIsGoing) return true;
	PROFILE_THIS("PhysicsTick");
	//check for any collisions
	btDynamicsWorld *phyWorld = CPhysicsManager::getSingleton().getWorld();

	phyWorld->stepSimulation(dt);

	phyWorld->debugDrawWorld();
	if (CPhysicsManager::getSingleton().getDebugDrawer())
		CPhysicsManager::getSingleton().getDebugDrawer()->step();

	return true;
}

bool CPhysicsBehaviour::handleMessage(MESSAGE_TYPE type, MESSAGE_ID id)
{
	if (id == MID_DBG_DRAW_PHYSICS_BOUNDS && type==MT_DOWN) {
		mDoDebug = true;
		CPhysicsManager::getSingleton().getDebugDrawer()->setDebugMode(1);
	} else if (id == MID_DBG_DRAW_PHYSICS_BOUNDS && type == MT_UP) {
		mDoDebug = false;
		CPhysicsManager::getSingleton().getDebugDrawer()->setDebugMode(0);
	}
	return true;
}

void CPhysicsBehaviour::dispatchCollisions(btDynamicsWorld *phyWorld) 
{
	static int flipflop=1;
	flipflop = 1-flipflop;

	PROFILE_THIS("PhysicsDispatchCollisions");
	btCollisionObject *obA = NULL, *obB = NULL;
	IPhysicsResponse *responseA = NULL, *responseB=NULL;

	std::list<IPhysicsResponse*> responses;

	int numManifolds = phyWorld->getDispatcher()->getNumManifolds();
	for (int i=0;i<numManifolds;++i)
	{
		btPersistentManifold* contactManifold = phyWorld->getDispatcher()->getManifoldByIndexInternal(i);
		
		int numContacts = contactManifold->getNumContacts();

		if (numContacts)
		{
			obA = static_cast<btCollisionObject*>(contactManifold->getBody0());
			obB = static_cast<btCollisionObject*>(contactManifold->getBody1());
			
			responseA = CPhysicsManager::getSingleton().GetResponseFromPointer(obA);
			responseB = CPhysicsManager::getSingleton().GetResponseFromPointer(obB);

			if (responseA)
				responseA->Collide(responseB, contactManifold, 0);
			if (responseB)
				responseB->Collide(responseA, contactManifold, 1);
		}
	}
}