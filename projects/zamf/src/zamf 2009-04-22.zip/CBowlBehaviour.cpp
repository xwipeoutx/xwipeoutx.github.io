#include "CBowlBehaviour.h"
#include "CProfileSample.h"
#include "CPhysicsManager.h"
#include "CMagnetBehaviour.h"
#include "IActor.h"

#include "CSettings.h"

#include "BtOgreGP.h"
#include "BtOgrePG.h"

#include <Ogre.h>
#include "constants.h"

using namespace Ogre;

CBowlBehaviour::CBowlBehaviour(SceneManager *mgr, CMagnetBehaviour *mb)
: mSceneMgr(mgr)
{

	mRadius = CSettings::getSingleton().getFloat("bowlRadius");
	mFriction = CSettings::getSingleton().getFloat("bowlFriction");
	mMass = CSettings::getSingleton().getFloat("bowlMass");
	mRestitution = CSettings::getSingleton().getFloat("bowlRestitution");
	mMagneticConstant = CSettings::getSingleton().getFloat("bowlMagneticConstant");
	mCCDMotionThreshold = CSettings::getSingleton().getFloat("bowlCCDMotionThreshold");
	mDeactivationTime = CSettings::getSingleton().getFloat("bowlDeactivationTime");
	
	mBowlShape = new btSphereShape(mRadius);
	mMagnetBehaviour = mb;
}

CBowlBehaviour::~CBowlBehaviour(void)
{
	for(std::list<CBowl*>::iterator it=mBowls.begin();it!=mBowls.end();++it)
	{
		CPhysicsManager::getSingleton().getWorld()->removeCollisionObject((*it)->mRigidBody);
		delete (*it)->mRigidBody->getUserPointer();
	}
	mBowls.clear();
}

bool CBowlBehaviour::tick(float dt)
{
	//attract to magnet
	std::list<CMagnet *> &magnets = mMagnetBehaviour->getMagnets();

	for(std::list<CBowl *>::iterator itb=mBowls.begin();itb!=mBowls.end();++itb)
	{
		Vector3 bowlPos = (*itb)->mNode->getPosition();
		for(std::list<CMagnet *>::iterator itm=magnets.begin();itm!=magnets.end();++itm)
		{
			if ((*itm)->mIsActive)
			{
				//get distance between
				Vector3 magnetPos = (*itm)->mNode->getPosition();
				Vector3 diff = magnetPos - bowlPos;
				Real dist2 = diff.squaredLength();
				diff *= mMass;// (mass)
				diff *= mMagneticConstant;
				btVector3 d = BtOgre::Convert::toBullet(diff) / dist2;
				d.setY(0);
				(*itb)->mRigidBody->applyCentralForce(d);
				(*itb)->mVel = (*itb)->mRigidBody->getLinearVelocity();
				(*itb)->mRigidBody->activate(true);
			}
		}
	}

	return true;
}

void CBowlBehaviour::addBowl(Ogre::SceneNode *bowlNode)
{
	CBowl *bowl = new CBowl();
	bowl->mNode = bowlNode;
	bowlNode->translate(0, 1, 0);

	//create bt Object (physics)
	btTransform transform( 
		BtOgre::Convert::toBullet(bowlNode->getOrientation()), 
		BtOgre::Convert::toBullet(bowlNode->getPosition()));
	btVector3 inertia;
	mBowlShape->calculateLocalInertia(mMass, inertia);

	btMotionState *motionState = new BtOgre::RigidBodyState(bowlNode);
	bowl->mRigidBody = new btRigidBody(mMass, motionState, mBowlShape, inertia);
	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(bowl->mRigidBody, 
		MVT_PROJECTILE, 
		MVT_PLAYER_CHARACTER | MVT_ENEMY | MVT_STATIONARY | MVT_TURRET | MVT_PROJECTILE);
	bowl->mRigidBody->setGravity(btVector3(0.0,-9.8,0.0));
	bowl->mRigidBody->setDeactivationTime(mDeactivationTime);

	bowl->mRigidBody->setFriction(mFriction);
	bowl->mRigidBody->setRestitution(mRestitution);
	bowl->mRigidBody->setCcdMotionThreshold(mRadius);
	IPR_ASSIGN_USER_POINTER(bowl->mRigidBody, bowl);
	mBowls.push_back( bowl );	
}

void CBowlBehaviour::clearBowls()
{
	mBowls.clear();
}

void CBowl::Collide(IPhysicsResponse *other, btPersistentManifold *contactManifold, int flipFlop)
{
	int numContacts = contactManifold->getNumContacts();
	IActor *actor = dynamic_cast<IActor*>(other);
	if (actor)
	{
		Real dmg = 0;
		for (int i=0;i<numContacts;i++)
		{
			dmg += contactManifold->getContactPoint(i).getAppliedImpulse();
		}
		dmg *= CSettings::getSingleton().getFloat("bowlDamageMultiplier");
		actor->Damage(dmg);
	}
}