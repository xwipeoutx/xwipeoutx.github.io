/*
#pragma once
#include "IMessageHandler.h"

class CGUImanager :	public IMessageHandler
{
public:
	CGUImanager(void);
	~CGUImanager(void);

protected:	
	CEGUI::OgreCEGUIRenderer *mGUIRenderer;
	CEGUI::System *mGUISystem;
};
*/