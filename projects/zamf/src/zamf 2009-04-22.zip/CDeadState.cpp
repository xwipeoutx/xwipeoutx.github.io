#include <Ogre.h>

#include "CDeadState.h"
#include "CBank.h"
#include "CZombieBehaviour.h"
#include "CPlayerCamera.h"
#include "CSoundManager.h"

using namespace Ogre;

CDeadState::CDeadState()
: mListener(NULL)
{

}

void CDeadState::enter()
{

	mRoot = Root::getSingletonPtr();

	mViewport = mRoot->getAutoCreatedWindow()->getViewport(0);

	CGameManager::getSingletonPtr()->getGUISystem().setGUISheet(
		CEGUI::WindowManager::getSingleton().getWindow("ZAMFDead")
	);

	mListener = new CDeadListener();
	CMessageBroadcaster::getSingleton().attach(mListener, "DeadListener");
	CMessageBroadcaster::getSingleton().inject(MT_NONE, MID_STOP_TIME);

	//CEGUI Message
	CEGUI::Window *win = CEGUI::WindowManager::getSingleton().getWindow("ZAMFDead/Stats");

	CBank *bank = CBank::getSingletonPtr();
	CZombieBehaviour *zb = CZombieBehaviour::getSingletonPtr();
	CPlayerCamera *p = CPlayerCamera::getSingletonPtr();
	String str;
	str += "Cash: $" + StringConverter::toString(bank->GetCash());
	str += "\n";
	str += "HP: " + StringConverter::toString(p->GetCurrentHP());
	str += "\n";
	str += "Kills: " + StringConverter::toString(zb->getNumKills());
	str += "\n";
	str += "Spawned: " + StringConverter::toString(zb->getNumSpawned());
	win->setText(str);

	CSoundManager::getSingleton().PlayWav("../../resource/sounds/player/death1.wav", 
	p->getCamera()->getRealPosition(),
	Vector3::ZERO);

}

void CDeadState::exit()
{
	CMessageBroadcaster::getSingleton().detach("DeadListener");
	mListener = NULL;
}

void CDeadState::pause()
{
	CMessageBroadcaster::getSingleton().attach(mListener, "PauseListener");
}

void CDeadState::resume()
{
	CMessageBroadcaster::getSingleton().detach("PauseListener");
}
