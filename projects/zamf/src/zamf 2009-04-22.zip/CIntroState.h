#pragma once
#include <Ogre.h>
#include <CEGUI/CEGUI.h>

#include "IGameState.h"

class CIntroListener;

class CIntroState : public IGameState
{
public:
	CIntroState();
	~CIntroState();

	void enter();
	void exit();

	void pause();
	void resume();

	inline virtual const Ogre::String getStateName(){return Ogre::String("Intro");}

	IMM_AUTO_SIZE;
protected:

	Ogre::SceneManager* mSceneMgr;
	Ogre::Root *mRoot;
	Ogre::Viewport* mViewport;
	Ogre::Camera* mCamera;

	CMMPointer<CIntroListener> mListener;

	bool mExitGame;
	
	CEGUI::Event::Connection mConnPlay;
	CEGUI::Event::Connection mConnQuit;

};

