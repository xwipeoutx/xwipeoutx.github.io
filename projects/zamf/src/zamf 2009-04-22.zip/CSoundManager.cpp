#include "CSoundManager.h"
#include "CPlayerCamera.h"
using namespace Ogre;

#define NUM_BUFFERS 1
#define NUM_SOURCES 2
#define NUM_ENVIRONMENTS 1

template<> CSoundManager* Singleton<CSoundManager>::ms_Singleton = 0;

CSoundManager::CSoundManager(void)
{
	alutInit(0, NULL);
}

CSoundManager::~CSoundManager(void)
{
	alutExit();
}

CMMPointer<CSoundBuffer> CSoundManager::AddSound(Ogre::String filename)
{
	//check if buffer already exists
	for (std::list< CMMPointer<CSoundBuffer> >::iterator it = mBuffers.begin(); it != mBuffers.end(); ++it)
	{
		if (((*it)->GetFilename()).compare( filename) == 0)
			return *it;
	}
	CMMPointer<CSoundBuffer> newBuffer = new CSoundBuffer(filename);

	mBuffers.push_back(newBuffer);
	return newBuffer;
}

CMMPointer<CSoundSource> CSoundManager::AddSource()
{
	CMMPointer<CSoundSource> newSource = new CSoundSource();
	mSources.push_back(newSource);
	return newSource;
}

CMMPointer<CSoundBuffer> CSoundManager::GetOrMakeBuffer(Ogre::String filename)
{
	CMMPointer<CSoundBuffer> buffer;

	//first we need to find the buffer corresponding to the sound given,
	// or alternatively - create a buffer for it.
	for (std::list< CMMPointer<CSoundBuffer> >::iterator it = mBuffers.begin(); it != mBuffers.end(); ++it)
	{
		if (((*it)->GetFilename()).compare( filename) == 0)
		{
			buffer = (*it);
			break;
		}
	}
	if (!buffer) buffer = this->AddSound(filename);
	return buffer;
}

CMMPointer<CSoundSource> CSoundManager::GetOrMakeSource()
{
	CMMPointer<CSoundSource> source;
	//next we need to find an available source, and play the buffer through that
	for (std::list< CMMPointer<CSoundSource> >::iterator it = mSources.begin(); it != mSources.end(); ++it)
	{
		if (!(*it)->GetCurrentlyPlaying())
		{
			//set the source for the sound
			source = (*it);
			break;
		}
	}

	if (!source) source = this->AddSource();

	return source;
}

void CSoundManager::PlayWav(Ogre::String filename, Ogre::Vector3 position, Ogre::Vector3 velocity)
{
	ResetPlayerPosition();

	CMMPointer<CSoundBuffer> buffer = GetOrMakeBuffer(filename);
	CMMPointer<CSoundSource> source = GetOrMakeSource();

	//make sure the sound is coming from the right spot
	source->SetPosition(position);
	source->SetVelocity(velocity);

	LogManager::getSingleton().logMessage("CSoundManager::PlayWav - playing " + filename);
	//ok play the sound now!
	source->Play(buffer);
}

void CSoundManager::PlayLoop(Ogre::String filename)
{
	CMMPointer<CSoundBuffer> buffer = GetOrMakeBuffer(filename);
	CMMPointer<CSoundSource> source = GetOrMakeSource();

	LogManager::getSingleton().logMessage("CSoundManager::PlayLoop - playing " + filename);
	source->SetLooping(true);
	source->Play(buffer);
}

void CSoundManager::ResetPlayerPosition()
{

	Vector3 x, y, z;
	Vector3 pos =  CPlayerCamera::getSingleton().getCamera()->getRealPosition();
	CPlayerCamera::getSingleton().getCamera()->getRealOrientation().ToAxes(x, y, z);

	float ori[6];
	ori[0] = -z.x;
	ori[1] = -z.y;
	ori[2] = -z.z;
	ori[3] = y.x;
	ori[4] = y.y;
	ori[5] = y.z;

	alListener3f(AL_POSITION, pos.x, pos.y, pos.z);
	alListener3f(AL_VELOCITY, 0.0f, 0.0f, 0.0f);
	alListenerfv(AL_ORIENTATION, ori);
}

void CSoundManager::ClearAllEverything()
{
	if (mSources.size())
	{
		for (std::list< CMMPointer<CSoundSource> >::iterator it = mSources.begin(); it != mSources.end(); ++it)
		{
			(*it)->Stop();
		}
		mSources.clear();
	}

	for (std::list< CMMPointer<CSoundBuffer> >::iterator it = mBuffers.begin(); it != mBuffers.end(); ++it)
	{

	}
	mBuffers.clear();
}
