#pragma once

class IDamager
{
public:
	IDamager(void);
	virtual ~IDamager(void);
};
