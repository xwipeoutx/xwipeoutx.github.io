#include "CPlayListener.h"

#include "CIntroState.h"
#include "CPauseState.h"
#include "CBank.h"
#include "CProfileSample.h"

#include <Ogre.h>

CPlayListener::CPlayListener(void)
{
}

CPlayListener::~CPlayListener(void)
{
}

bool CPlayListener::handleMessage(MESSAGE_TYPE type, MESSAGE_ID id)
{
	if (type == MT_DOWN)
	{
		switch (id)
		{
		case MID_MENU:
			CGameManager::getSingleton().changeState(new CIntroState());
			break;

		case MID_PAUSE:
			CGameManager::getSingleton().pushState(new CPauseState());
			break;

		case MID_TOGGLE_CONSOLE:
			CEGUI::WindowManager::getSingleton().getWindow("ZAMFHUD/DebugMessage")->
				setVisible(!(CEGUI::WindowManager::getSingleton().getWindow("ZAMFHUD/DebugMessage")->isVisible()));
			break;

		case MID_DBG_CLEAR_PROFILE:
			CProfileSample::ResetAll();
			break;

		case MID_DBG_DRAW_PHYSICS_BOUNDS:
			CBank::getSingleton().Deposit(100);
			break;
		}
	}

	return true;
}

bool CPlayListener::tick(float dt)
{
	static float fps = 0;
	float newFPS = Ogre::Root::getSingleton().getAutoCreatedWindow()->getLastFPS();
	if (newFPS != fps)
	{
		CEGUI::Window *win = CEGUI::WindowManager::getSingleton().getWindow("ZAMFHUD/StatsMessage");
		fps = newFPS;
		win->setText(Ogre::StringConverter::toString(fps) + "FPS");
	}
	return true;
}