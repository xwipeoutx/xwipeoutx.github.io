#include "CProfilerLogHandler.h"
#include <Ogre.h>

using namespace Ogre;

void CProfilerLogHandler::BeginOutput()
{
	LogManager::getSingleton().logMessage("          Min :        Avg :        Max :       Time :       # : Profile Name");
	LogManager::getSingleton().logMessage("-----------------------------------------------------------------------------");
}

void CProfilerLogHandler::EndOutput(float totalTime)
{
	LogManager::getSingleton().logMessage("-----------------------------------------------------------------------------");
}

void CProfilerLogHandler::Sample(float fMin, float fAvg, float fMax, float tAvg,
	int callCount, std::string name, int parentCount)
{

	String out;
	
	out += StringConverter::toString(fMin, 4, 13);
	out += StringConverter::toString(fAvg, 4, 13);
	out += StringConverter::toString(fMax, 4, 13);
	out += StringConverter::toString(tAvg, 4, 13);
	out += StringConverter::toString(callCount, 10);
	out += "   ";
	

	/*
	char namebuf[256], indentedName[256];
	char avg[16], min[16], max[16], time[16], num[16];
	
	sprintf(avg, "%5.3f   ", fAvg);
	sprintf(min, "%5.3f   ", fMin);
	sprintf(max, "%5.3f   ", fMax);
	sprintf(time, "%5.3f   ", tAvg);
	sprintf(num, "%3d   ", callCount);

	out += (avg);
	out += (min);
	out += (max);
	out += (time);
	out += (num);
	*/

	for (int i=0;i<parentCount;++i) {
		out += " ";
	}
	out += name;
	LogManager::getSingleton().logMessage(out);
}