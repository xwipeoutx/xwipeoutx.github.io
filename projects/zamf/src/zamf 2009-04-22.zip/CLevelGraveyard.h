#pragma once
#include "ILevel.h"
#include "CMMPointer.h"

#include "CPhysicsManager.h"

class CBulletBehaviour;
class CTurretBehaviour;
class CTurretSpawner;
class CBowlBehaviour;
class CMagnetBehaviour;

class CZombieBehaviour;
class CZombieSpawner;

class CPhysicsBehaviour;


namespace Ogre{
	class SceneManager;
};

class CLevelGraveyard : public ILevel
{
public:
	CLevelGraveyard(Ogre::SceneManager *mgr);
	virtual ~CLevelGraveyard(void);

protected:

	void LoadBehaviours();
	void PreloadObjects();
	void CreateScene();
	void LoadSounds();

	CMMPointer< CBulletBehaviour > mBulletBehaviour;
	CMMPointer< CBowlBehaviour > mBowlBehaviour;
	CMMPointer< CMagnetBehaviour > mMagnetBehaviour;
	CMMPointer< CTurretBehaviour > mTurretBehaviour;
	CMMPointer< CTurretSpawner > mTurretSpawner;
	
	CMMPointer< CZombieBehaviour > mZombieBehaviour;
	CMMPointer< CZombieSpawner > mZombieSpawner;

	CMMPointer< CPhysicsBehaviour > mPhysicsBehaviour;

	btCollisionObject *mGround, *mWall1, *mWall2, *mWall3, *mWall4;
	btCollisionShape *mGroundShape, *mWallShape1, *mWallShape2, *mWallShape3, *mWallShape4;


};
