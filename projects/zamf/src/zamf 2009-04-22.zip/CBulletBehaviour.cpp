#include "CBulletBehaviour.h"
#include "CPhysicsManager.h"
#include "CSettings.h"
#include "CSoundManager.h"
#include "IActor.h"

#include "constants.h"
#include "BtOgreGP.h"
#include "BtOgrePG.h"

#include "CPlayStateHelper.h"
#include "CProfileSample.h"

#include <Ogre.h>
#include <CEGUI/CEGUI.h>

using namespace Ogre;

CBulletBehaviour::CBulletBehaviour(SceneManager *mgr)
: mSceneMgr(mgr), mNumBullets(0), mNumPooledBullets(0), mNumBulletsSpawned(0),
	mNumBulletsDestroyed(0), mNumBulletsMissed(0)
{
	mBulletPool = new std::list<CBullet*>();
	mBullets = new std::list<CBullet*>();

	//mBulletShape = new btSphereShape(0.04);
	mBulletShape = new btBoxShape(btVector3(0.02, 0.02, 0.2));

	mInitialSpeed = CSettings::getSingleton().getFloat("bulletInitialSpeed");
	mMass = CSettings::getSingleton().getFloat("bulletMass");
	mFriction = CSettings::getSingleton().getFloat("bulletFriction");
	mRestitution = CSettings::getSingleton().getFloat("bulletRestitution");
	mDeactivationTime = CSettings::getSingleton().getFloat("bulletDeactivationTime");
	mCCDMotionThreshold = CSettings::getSingleton().getFloat("bulletCCDMotionThreshold");
}

CBulletBehaviour::~CBulletBehaviour(void)
{
	//TODO: destroy the lists
	for(std::list<CBullet*>::iterator it=mBullets->begin();it!=mBullets->end();++it)
	{
		CBullet *b = *it;

		CPhysicsManager::getSingleton().getWorld()->removeRigidBody((btRigidBody*)b->mPhysObject);
		delete ((btRigidBody*)b->mPhysObject)->getMotionState();
		delete b->mPhysObject->getUserPointer();
		b->mPhysObject->setUserPointer(NULL);
		delete b->mPhysObject;
		b->mPhysObject = NULL;
	}
	mBullets->clear();
	mBulletPool->clear();
}

bool CBulletBehaviour::tick(Real dt)
{
	if (dt < 0.0001) return true;
	if (!mTimeIsGoing) return true;
	PROFILE_THIS("CBulletBehaviour::tick");

	for(std::list<CBullet*>::iterator it=mBullets->begin();it!=mBullets->end();++it)
	{
		CBullet *b = *it;

		if (b->mBulletNode->getPosition().squaredLength() > 14000 ||
			b->mPhysObject->getLinearVelocity().length2() < 0.1) 
		{
			++mNumBulletsMissed;
			b->mDying = true;
		}
		if (b->mDying && (!b->mPhysObject->isActive() || dt > 0.01)) {
			it = DrownBullet(it);
			if (it == mBullets->end()) 
				break;
		}
	}
	return true;
}

std::list<CBullet*>::iterator CBulletBehaviour::DrownBullet(std::list<CBullet*>::iterator it) 
{
	++mNumBulletsDestroyed;

	CBullet *b = *it;
	//move it to the pool, take it out of here
	mNumPooledBullets++;
	if (b->mBulletNode->getName().length())
		b->mBulletNode->setVisible(false);

	CPhysicsManager::getSingleton().getWorld()->removeRigidBody((btRigidBody*)b->mPhysObject);
	delete ((btRigidBody*)b->mPhysObject)->getMotionState();
	b->mPhysObject->setUserPointer(NULL);
	delete b->mPhysObject;
	b->mPhysObject = NULL;

	mBulletPool->push_back(*it);
	return mBullets->erase(it);
}

void CBulletBehaviour::fireBullet(Vector3 origin, Vector3 direction, Real range)
{
	PROFILE_THIS("CBulletBehaviour::fireBullet");
	++mNumBulletsSpawned;


	CBullet *b;
	if (mNumPooledBullets > 0)
	{
		//use pooled bullet
		b = mBulletPool->front();
		mBulletPool->pop_front();
		--mNumPooledBullets;

		//Set bullet params for the pooled bullet
		b->mBulletNode->setVisible(true);
		b->mBulletNode->setPosition(origin);
	}
	else
	{
		//create bullet from scratch
		b = new CBullet();
		String name = "Bullet" + StringConverter::toString(mNumBullets++);
		String nodeName = "BulletNode" + StringConverter::toString(mNumBullets);

		//Entity *ent = mSceneMgr->createEntity(name, SceneManager::PT_SPHERE);
		Entity *ent = mSceneMgr->createEntity(name, SceneManager::PT_CUBE);
		ent->setQueryFlags(MVT_PROJECTILE);

		SceneNode *node = mSceneMgr->getRootSceneNode()->createChildSceneNode(nodeName, origin);
		node->attachObject(ent);
		node->scale(Vector3(0.0002, 0.0002, 0.002));
		//node->setUserAny(Any(b));

		b->mBulletNode = node;
	}

	b->mBulletNode->setOrientation(Vector3::UNIT_Z.getRotationTo(direction));

	//create bt Object (physics)
	btTransform transform( 
		BtOgre::Convert::toBullet(b->mBulletNode->getOrientation()), 
		BtOgre::Convert::toBullet(b->mBulletNode->getPosition()));
	btScalar mass = mMass; //mass of a nail is about 1g
	btVector3 inertia;
	mBulletShape->calculateLocalInertia(mass, inertia);

	btMotionState *motionState = new BtOgre::RigidBodyState(b->mBulletNode);
	b->mPhysObject = new btRigidBody(mass, motionState, mBulletShape, inertia);
	IPR_ASSIGN_USER_POINTER(b->mPhysObject, b);
	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(b->mPhysObject, 
		MVT_PROJECTILE, 
		MVT_PLAYER_CHARACTER|MVT_ENEMY|MVT_STATIONARY);
	
	btVector3 dir = BtOgre::Convert::toBullet( direction );
	dir *= mInitialSpeed; //nail speed is like 100m/s
	dir.setY(dir.y() + 2);

	b->mPhysObject->setGravity(btVector3(0.0,-9.8,0.0));
	b->mPhysObject->setLinearVelocity(dir);
	b->mPhysObject->setFriction(mFriction);
	b->mPhysObject->setRestitution(mRestitution);
	b->mPhysObject->setCcdMotionThreshold(mCCDMotionThreshold);
	b->mPhysObject->setDeactivationTime(mDeactivationTime);

	b->mDirection = direction;
	b->mRange = range;
	b->mDying = false;

	mBullets->push_back(b);
}

void CBullet::Collide(IPhysicsResponse *other, btPersistentManifold* contactManifold, int flipFlop)
{
	if (!mDying)
	{
		mDying = true;

		//collide with any actor
		IActor *actor = dynamic_cast<IActor*>(other);
		if (actor)
		{
			actor->Damage(CSettings::getSingleton().getFloat("bulletDamage"));
		}

		//play a sound on hit
		CSoundManager::getSingleton().PlayWav("../../resource/sounds/guns/nail_ting.wav", mBulletNode->getPosition(), Ogre::Vector3::ZERO);
	}
}