#pragma once

#include "Ogre.h"
#include "CMMPointer.h"

#include "CSoundBuffer.h"
#include "CSoundSource.h"

#include <list>

class CSoundManager : public Ogre::Singleton<CSoundManager>
{
public:
	CSoundManager(void);
	~CSoundManager(void);

	void ResetPlayerPosition();

	CMMPointer<CSoundBuffer> AddSound(Ogre::String filename);
	void PlayWav(std::string filename, Ogre::Vector3 position, Ogre::Vector3 velocity);
	void PlayLoop(std::string filename);
	
	CMMPointer<CSoundSource> AddSource();

	void ClearAllEverything();
protected:

	CMMPointer<CSoundSource> GetOrMakeSource();
	CMMPointer<CSoundBuffer> GetOrMakeBuffer(Ogre::String filename);

	std::list< CMMPointer<CSoundBuffer> > mBuffers; //TODO: Make a std::map instead!!
	std::list< CMMPointer<CSoundSource> > mSources;


};
