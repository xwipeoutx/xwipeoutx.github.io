#pragma once

#include "IPhysicsResponse.h"
#include "IMessageHandler.h"
#include "LinearMath/btVector3.h"
#include "CMagnetBehaviour.h"

#include "IPhysicsResponse.h"

#include <Ogre.h>

//class CMagnetBehaviour;
class btRigidBody;
class btCollisionShape;

class CBowl : public IPhysicsResponse
{
public:
	btRigidBody *mRigidBody;
	Ogre::SceneNode *mNode;
	btVector3 mVel;

	void Collide(IPhysicsResponse *other, btPersistentManifold* contactManifold, int flipFlop);
};

class CBowlBehaviour : public IMessageHandler
{
public:
	CBowlBehaviour(Ogre::SceneManager *sm, CMagnetBehaviour *mb);
	virtual ~CBowlBehaviour(void);

	void addBowl(Ogre::SceneNode *bowl);
	void clearBowls();

	bool tick(Ogre::Real dt);
	IMM_AUTO_SIZE;
protected:
	Ogre::SceneManager *mSceneMgr;

	std::list<CBowl*> mBowls;
	CMagnetBehaviour *mMagnetBehaviour;

	btCollisionShape *mBowlShape;

	Ogre::Real mMass;
	Ogre::Real mFriction;
	Ogre::Real mRestitution;
	Ogre::Real mMagneticConstant;
	Ogre::Real mCCDMotionThreshold;
	Ogre::Real mRadius;
	Ogre::Real mDeactivationTime;
private:
};