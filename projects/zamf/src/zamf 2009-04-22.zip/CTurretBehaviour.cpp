#include "CTurretBehaviour.h"
#include "CBulletBehaviour.h"

#include "CPlayStateHelper.h"
#include "CZombieBehaviour.h"
#include "CSettings.h"
#include "CSoundManager.h"
#include "CPhysicsManager.h"

#include "CProfileSample.h"

#include <Ogre.h>
#include "constants.h"

using namespace Ogre;

CTurretBehaviour::CTurretBehaviour(SceneManager *mgr, CBulletBehaviour *bulletBehaviour)
: mSceneMgr(mgr), mBulletBehaviour(bulletBehaviour)
{

	mIdleSpeed = CSettings::getSingleton().getFloat("turretIdleSpeed");
	mTargetingSpeed = CSettings::getSingleton().getFloat("turretTargetingSpeed");
	mCooldown = CSettings::getSingleton().getFloat("turretCooldown");
	mRange = CSettings::getSingleton().getFloat("turretRange");

	mTurretShape = new btBoxShape(btVector3(0.50, 0.50, 0.50));
}

CTurretBehaviour::~CTurretBehaviour(void)
{
	for(std::list<CTurret*>::iterator it=mTurrets.begin();it!=mTurrets.end();++it)
	{
		CPhysicsManager::getSingleton().getWorld()->removeCollisionObject((*it)->mPhysObject);
		delete (*it)->mPhysObject->getUserPointer();
	}
	mTurrets.clear();
}

bool CTurretBehaviour::tick(float dt)
{
	if (dt < 0.0001) return true;
	if (!mTimeIsGoing) return true;
	PROFILE_THIS("CTurretBehaviour::tick");



	for (std::list<CTurret*>::iterator it = mTurrets.begin(); it != mTurrets.end(); ++it)
	{
		CTurret *turret = *it;

#ifdef FIRE_RANDOM_THING
//FIRE
turret->turretNode->yaw(Degree(-dt * 45));
if (turret->timeUntilNextShot > 0)
	(*it)->timeUntilNextShot -= dt;
else
{
	Vector3 pos = turret->position;
	pos.y += 0.79f;
	mBulletBehaviour->fireBullet(pos, Vector3(0,0,1));
	(*it)->timeUntilNextShot = 1.0f;
}
continue;
#endif

		//find a target
		if (turret->mSearching)
		{
			PROFILE_THIS("CTurretBehaviour - Searching");

			SceneQueryResult &res = turret->mQuery->execute();
			//find a target
			if (res.movables.begin() != res.movables.end())
			{
				turret->mTargetInitialDistanceSquared = 100000.0f;
				turret->mSearching = false;
				SceneNode *curr;
				std::list<MovableObject*>::iterator itm;
				for(itm=res.movables.begin(); itm!=res.movables.end(); ++itm)
				{
					curr = (*itm)->getParentSceneNode();
					if (turret->mPosition.squaredDistance(curr->getPosition())  < turret->mTargetInitialDistanceSquared)
					{
						turret->mTargetNode = curr;
						turret->mTargetInitialDistanceSquared = turret->mPosition.squaredDistance(curr->getPosition());
					}
				}
				if (turret->mTargetInitialDistanceSquared < 10000)
					turret->mTargetInitialDistanceSquared = 10000;

				turret->mTargetNode->setListener(this);
			}
			else
			{
				//move speed: 45 degrees per second
				turret->mTurretNode->yaw(Degree(-dt * mIdleSpeed));
			}
		}
		else
		{
			PROFILE_THIS("Turret Face Target");
			//get heading of turret and relation to zombie
			Vector3 targetPos = turret->mTargetNode->getPosition();
			Vector3 diff = targetPos - turret->mPosition;
			diff.normalise();
			//negated, because the turret is facing backwards...
			Radian desiredAngle = Ogre::Math::ATan2(-diff.x, -diff.z);
			Degree difference = desiredAngle - turret->mTurretNode->getOrientation().getYaw();

			//make sure we're dealing with sane angles
			if (Degree(difference) < Degree(180)) difference += Degree(360);
			if (Degree(difference) > Degree(180)) difference -= Degree(360);

			Degree rotateBy =  Math::Clamp<Degree>(difference, Degree(-dt*mTargetingSpeed), Degree(dt*mTargetingSpeed));

			turret->mTurretNode->yaw(rotateBy);

			//FIRE
			if (turret->mTimeUntilNextShot > 0)
				(*it)->mTimeUntilNextShot -= dt;
			else
			{
				if (difference < Degree(5) && difference > Degree(-5))
				{
					CSoundManager::getSingleton().PlayWav("../../resource/sounds/guns/turret_fire.wav", turret->mPosition, Vector3::ZERO);
					diff.y = 0;
					Vector3 pos = turret->mPosition;
					pos.y += 0.79f;
					mBulletBehaviour->fireBullet(pos, diff);
					(*it)->mTimeUntilNextShot = mCooldown;
				}
			}
		}
	}
	return true;
}

void CTurretBehaviour::addTurret(Ogre::SceneNode *turretNode)
{
	CTurret *turret = new CTurret();
	turret->mTurretNode = turretNode;
	turret->mPosition = turretNode->getPosition();

	Sphere sphere(turret->mPosition, mRange);
	turret->mQuery = mSceneMgr->createSphereQuery(sphere);
	turret->mQuery->setQueryMask(MVT_ENEMY);

	turret->mSearching = true;
	turret->mTimeUntilNextShot = 0.0f;

	//create bt Object (physics)
	btTransform transform( 
		BtOgre::Convert::toBullet(turretNode->getOrientation()), 
		BtOgre::Convert::toBullet(Vector3(0,0.5,0)+turretNode->getPosition()));
	turret->mPhysObject = new btCollisionObject();
	turret->mPhysObject->setWorldTransform(transform);
	turret->mPhysObject->setCollisionShape(mTurretShape);
	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(turret->mPhysObject, MVT_TURRET, MVT_PLAYER_CHARACTER|MVT_ENEMY|MVT_STATIONARY|MVT_PROJECTILE);
	IPR_ASSIGN_USER_POINTER(turret->mPhysObject, turret);
	//collObj->setUserPointer(new Any(static_cast<IPhysicsResponse*>(ptr)))

	mTurrets.push_back( turret );
}

void CTurretBehaviour::clearTurrets()
{
	mTurrets.clear();
}

void CTurretBehaviour::nodeDestroyed(const Ogre::Node *node)
{
	//let's go!
	for (std::list<CTurret*>::iterator it = mTurrets.begin(); it != mTurrets.end(); ++it)
	{
		if (!(*it)->mSearching)
		if ((*it)->mTargetNode->getName() == node->getName())
		{
			(*it)->mSearching = true;
			(*it)->mTargetNode = NULL;
		}
	}
}