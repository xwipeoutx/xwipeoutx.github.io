#include "CZombieBehaviour.h"
#include "CPhysicsManager.h"
#include "constants.h"
#include "CBank.h"

#include "CSoundManager.h"
#include "CGameManager.h"
#include "CDeadState.h"
#include "CPlayStateHelper.h"
#include "CProfileSample.h"
#include "CPlayerCamera.h"
#include "CSettings.h"

#include "BtOgreGP.h"
#include "BulletCollision/CollisionDispatch/btGhostObject.h"

#include <Ogre.h>
#include <CEGUI/CEGUI.h>

using namespace Ogre;

template<> CZombieBehaviour* Singleton<CZombieBehaviour>::ms_Singleton = 0;

CZombieBehaviour::CZombieBehaviour(SceneManager *mgr)
: mSceneMgr(mgr), mZombieShape(0), mNumSpawned(0), mNumKills(0)
{
	mZombies = new std::list<CZombieActor*>();
	
	mSpeed = CSettings::getSingleton().getFloat("zombieSpeed");
	mWorth = CSettings::getSingleton().getFloat("zombieWorth");
		
	mCooldown = CSettings::getSingleton().getFloat("zombieCooldown");
	mAttackPower = CSettings::getSingleton().getFloat("zombieAttackPower");
	mAttackSpeed = CSettings::getSingleton().getFloat("zombieAttackSpeed");
	mAttackRange2 = CSettings::getSingleton().getFloat("zombieAttackRange2");

	mMaxHP = CSettings::getSingleton().getFloat("zombieMaxHP");
	mHPIncrease1 = CSettings::getSingleton().getFloat("zombieHPIncrease1");
	mHPIncrease2 = CSettings::getSingleton().getFloat("zombieHPIncrease2");
	mHPIncreaseExp1 = CSettings::getSingleton().getFloat("zombieHPIncreaseExp1");
	mHPIncreaseExp2 = CSettings::getSingleton().getFloat("zombieHPIncreaseExp2");
}

CZombieBehaviour::~CZombieBehaviour(void)
{
	//TODO: Kill mZombies AI thing
	for(std::list<CZombieActor*>::iterator it=mZombies->begin();it!=mZombies->end();++it)
	{
		(*it)->ghostObject->setUserPointer(NULL);
		CPhysicsManager::getSingleton().getWorld()->removeCollisionObject((*it)->ghostObject);
		delete (*it)->ghostObject;
	}
	mZombies->clear();
	delete mZombies;
}

bool CZombieBehaviour::tick(float dt)
{
	if (dt < 0.0001) return true;
	if (!mTimeIsGoing) return true;
	PROFILE_THIS("CZombieBehaviour::tick");

	Vector3 playerPos = mSceneMgr->getSceneNode("PlayerCamera")->getPosition();

	for(std::list<CZombieActor*>::iterator it=mZombies->begin();it!=mZombies->end();++it)
	{
		//temporarily just move the zombie around
		SceneNode *zomb = (*it)->zombieNode;
		Vector3 zombiePos = zomb->getPosition();
		if ((*it)->IsAlive())
		{
			if ((*it)->state == CZombieActor::AI_SEEKING || (*it)->state == CZombieActor::AI_COOLING)
			{
				//head towards the player
				//get heading of turret and relation to zombie
				Vector3 zombiePos = zomb->getPosition();
				Vector3 diff = zombiePos - playerPos;
				//negated, because the zombie is facing backwards...
				Radian desiredAngle = Ogre::Math::ATan2(diff.x, diff.z); 
				Degree difference = desiredAngle - zomb->getOrientation().getYaw();

				//make sure we're dealing with sane angles
				if (Degree(difference) < Degree(180)) difference += Degree(360);
				if (Degree(difference) > Degree(180)) difference -= Degree(360);

				Degree rotateBy =  Math::Clamp<Degree>(difference, Degree(-dt*360), Degree(dt*360));

				zomb->yaw(rotateBy);

				//now move towards player
				Real moved = dt*mSpeed;
				zomb->translate(Vector3(0,0,moved), Node::TS_LOCAL);

				//update physics world transform
				btTransform currTrans = (*it)->ghostObject->getWorldTransform();
				currTrans.setOrigin(BtOgre::Convert::toBullet(zombiePos));
				currTrans.setRotation(BtOgre::Convert::toBullet(zomb->getOrientation()));
				(*it)->ghostObject->setWorldTransform(currTrans);
				zombiePos = zomb->getPosition();

				if ((*it)->state == CZombieActor::AI_SEEKING && (*it)->cooldown <= 0.0001 && mAttackRange2 > zombiePos.squaredDistance(playerPos))
				{
					CSoundManager::getSingleton().PlayWav("../../resource/sounds/zombie/attack1.wav", zombiePos, Vector3::ZERO);
					(*it)->state = CZombieActor::AI_SWINGING;
					(*it)->cooldown = mAttackSpeed;
				}
			}

			if ((*it)->state == CZombieActor::AI_SWINGING)
			{
				if ((*it)->cooldown < 0.0001)
				{
					//do damage
					(*it)->state = CZombieActor::AI_COOLING;
					(*it)->cooldown = mCooldown;
					if(mAttackRange2 > zombiePos.squaredDistance(playerPos))
					{
						CSoundManager::getSingleton().PlayWav("../../resource/sounds/zombie/hit1.wav", zombiePos, Vector3::ZERO);
						CPlayerCamera::getSingletonPtr()->Damage(mAttackPower);
					}
				}
			}

			if ((*it)->state == CZombieActor::AI_COOLING)
			{
				if ((*it)->cooldown < 0.0001)
					(*it)->state = CZombieActor::AI_SEEKING;
			}

			if ((*it)->state == CZombieActor::AI_COOLING || (*it)->state == CZombieActor::AI_SWINGING)
				(*it)->cooldown -= dt;

		}
		else 
		{
			//kill the zombie
			it = KillZombie(it);
			CBank::getSingleton().Deposit(mWorth);
			CPlayStateHelper::getSingleton().UpdateStats();
			if (it == mZombies->end())
				break;
		}
	}
	return true;
}

std::list<CZombieActor*>::iterator CZombieBehaviour::KillZombie(std::list<CZombieActor*>::iterator it)
{
	mNumKills++;
	CZombieActor *z = *it;
	
	CPhysicsManager::getSingleton().getWorld()->removeCollisionObject(z->ghostObject);
	delete z->ghostObject;
	z->ghostObject = NULL;
	z->zombieNode->setUserAny(Any(NULL));
	mSceneMgr->destroySceneNode(z->zombieNode);
	z->zombieNode = NULL;

	return mZombies->erase(it);
}

void CZombieBehaviour::addZombie(Ogre::SceneNode *zombie, Ogre::Entity *entity)
{
	CZombieActor *z=new CZombieActor();
	z->state = CZombieActor::AI_SEEKING;
	z->zombieNode = zombie;

	//if kills are greater than 40, than linearly increase maximum health
	float maxHP = 
		0.33333*mMaxHP *
		(	1 + 
			3*mNumSpawned * mHPIncrease1 +
			3*mNumSpawned * mNumSpawned * mHPIncrease2 + 
			Ogre::Math::Pow(mHPIncreaseExp1, mNumSpawned) + 
			Ogre::Math::Pow(mHPIncreaseExp2, mNumSpawned*mNumSpawned)
		);
	z->SetHP(maxHP);

	CPlayStateHelper::getSingleton().AddDebugMsg("Zombie Spawned: " + StringConverter::toString(z->GetMaxHP()));

	//create bt Object (physics)
	z->ghostObject = new btPairCachingGhostObject();
	z->ghostObject->setWorldTransform(btTransform(
		BtOgre::Convert::toBullet(zombie->getOrientation()), 
		btVector3(0,1,0) + BtOgre::Convert::toBullet(zombie->getPosition())));
	
    //Create the zombie shape.
	if (!mZombieShape)
	{
		BtOgre::StaticMeshToShapeConverter *zombConverter = 
			new BtOgre::StaticMeshToShapeConverter(entity);
		//mZombieShape = new btSphereShape(2.0);
		//mZombieShape = zombConverter->createBox();
		//mZombieShape = zombConverter->createSphere();		
		const Ogre::Vector3 sz = zombConverter->getSize();
		mZombieShape = new btCylinderShapeX(BtOgre::Convert::toBullet(sz * 0.5));

		//mZombieShape = zombConverter->createCylinder();
		//mZombieShape = zombConverter->createConvex();
		//mZombieShape = zombConverter->createTrimesh();
		delete zombConverter;
	}

	z->ghostObject->setCollisionShape(mZombieShape);
	IPR_ASSIGN_USER_POINTER(z->ghostObject, z);
	z->cooldown = 0;
	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(z->ghostObject, MVT_ENEMY, MVT_STATIONARY|MVT_PROJECTILE|MVT_ENEMY|MVT_TURRET);
	z->ghostObject->setCollisionFlags(z->ghostObject->getCollisionFlags() | btCollisionObject::CF_CUSTOM_MATERIAL_CALLBACK);

	mZombies->push_back(z);
	mNumSpawned++;
	CPlayStateHelper::getSingleton().UpdateStats();
}

void CZombieActor::Collide(IPhysicsResponse *other, btPersistentManifold *contactManifold, int body)
{
	int numContacts = contactManifold->getNumContacts();
	btVector3 move(0,0,0);
	
	//move away by half the penetration distance of each point
	for (int i=0;i<numContacts;i++)
	{
		btManifoldPoint &c = contactManifold->getContactPoint(i);
		btVector3 n = 0.5*(c.m_positionWorldOnA-c.m_positionWorldOnB);
		if (body == 0)
			move -= n;
		else
			move += n;

	}
	move.setY(0);

	Ogre::SceneNode *zomb = this->zombieNode;
	zomb->translate(BtOgre::Convert::toOgre(move), Node::TS_PARENT);
	
	//update physics world transform
	Vector3 pos = zomb->getPosition();
	btTransform currTrans = this->ghostObject->getWorldTransform();
	currTrans.setOrigin(BtOgre::Convert::toBullet(zomb->getPosition()));
	currTrans.setRotation(BtOgre::Convert::toBullet(zomb->getOrientation()));
	this->ghostObject->setWorldTransform(currTrans);
}