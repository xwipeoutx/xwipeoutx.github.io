#include <Ogre.h>

#include "CPauseState.h"

using namespace Ogre;

CPauseState::CPauseState()
: mListener(NULL)
{

}

void CPauseState::enter()
{
	mRoot = Root::getSingletonPtr();

	mViewport = mRoot->getAutoCreatedWindow()->getViewport(0);

	CGameManager::getSingletonPtr()->getGUISystem().setGUISheet(
		CEGUI::WindowManager::getSingleton().getWindow("ZAMFPause")
	);

	mListener = new CPauseListener();
	CMessageBroadcaster::getSingleton().attach(mListener, "PauseListener");
	CMessageBroadcaster::getSingleton().inject(MT_NONE, MID_STOP_TIME);
}

void CPauseState::exit()
{
	CMessageBroadcaster::getSingleton().detach("PauseListener");
	CMessageBroadcaster::getSingleton().inject(MT_NONE, MID_RESTART_TIME);
	mListener = NULL;
}

void CPauseState::pause()
{
	CMessageBroadcaster::getSingleton().attach(mListener, "PauseListener");
}

void CPauseState::resume()
{
	CMessageBroadcaster::getSingleton().detach("PauseListener");
}
