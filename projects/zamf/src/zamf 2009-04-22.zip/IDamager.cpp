#include "IDamager.h"

IDamager::IDamager(void)
{
}

IDamager::~IDamager(void)
{
}
