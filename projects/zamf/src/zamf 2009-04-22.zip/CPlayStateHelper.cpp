#include "CPlayStateHelper.h"

#include "CBank.h"
#include "CZombieBehaviour.h"
#include "CPlayerCamera.h"

#include <CEGUI/CEGUI.h>
using namespace Ogre;

template<> CPlayStateHelper* Singleton<CPlayStateHelper>::ms_Singleton = 0;
CPlayStateHelper::CPlayStateHelper(void)
{
}

CPlayStateHelper::~CPlayStateHelper(void)
{
}


void CPlayStateHelper::AddDebugMsg(const Ogre::String &msg)
{
	CEGUI::Window *win = CEGUI::WindowManager::getSingleton().getWindow("ZAMFHUD/DebugMessage");
	win->setText(win->getText() + "\n" + msg);
}

void CPlayStateHelper::UpdateStats() {
	CEGUI::Window *win = CEGUI::WindowManager::getSingleton().getWindow("ZAMFHUD/Scoreboard");

	CBank *bank = CBank::getSingletonPtr();
	CZombieBehaviour *zb = CZombieBehaviour::getSingletonPtr();
	CPlayerCamera *p = CPlayerCamera::getSingletonPtr();
	String str;
	str += "Cash: $" + StringConverter::toString(bank->GetCash());
	str += "\n";
	str += "HP: " + StringConverter::toString(p->GetCurrentHP());
	str += "\n";
	str += "Kills: " + StringConverter::toString(zb->getNumKills());
	str += "\n";
	str += "Undead: " + StringConverter::toString(zb->getNumSpawned() - zb->getNumKills());

	win->setText(str);
}