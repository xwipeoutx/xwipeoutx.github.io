#include "CMapGrid.h"
#include "CPlayerCamera.h"
#include "constants.h"

#include "CProfileSample.h"

using namespace Ogre;

template<> CMapGrid* Singleton<CMapGrid>::ms_Singleton = 0;
CMapGrid::CMapGrid(Vector3 min, Vector3 max)
: mXMax(199), mZMax(199), mMin(min), mMax(max)
{
	mDist = (mMax-mMin)/Vector3(mXMax+1, 1, mZMax+1);
	mMapCells = new MapCellContents*[mXMax];
	for (int i=0; i<mXMax; i++)
	{
		mMapCells[i] = new MapCellContents[mZMax];
	}

	InitMapContents();
}

CMapGrid::~CMapGrid(void)
{
}

void CMapGrid::InitMapContents()
{
	//empty the grid
	for (int i=0;i<mXMax;i++)
		for (int j=0;j<mZMax;j++)
			mMapCells[i][j] = MCC_EMPTY;

	//make a couple of walls for the heck of it
	//for (int i=30; i<50; i++)
	//	mMapCells[i][30] = MCC_STATIONARY;
	//for (int i=30; i<50; i++)
	//	mMapCells[30][i] = MCC_STATIONARY;
	//for (int i=30; i<50; i++)
	//	mMapCells[i][50] = MCC_STATIONARY;
	//for (int i=30; i<50; i++)
		//mMapCells[50][i] = MCC_STATIONARY;
}

void CMapGrid::PopulateFromScene(SceneManager *mgr)
{
	PROFILE_THIS("Populate from scene");
	return;
	mgr->_updateSceneGraph(CPlayerCamera::getSingleton().getCamera());

	Vector3 d = 0.5 * mDist;
	Vector3 currPos = mMin-d;
	currPos.y = 100;
	RaySceneQuery *query = mgr->createRayQuery(Ray());
	for (int i=0;i<mXMax;i++)
	{
		for (int j=0;j<mZMax;j++)
		{
			currPos.z += mDist.z;
			Ray ray(currPos, -Vector3::UNIT_Y);
			query->setRay(ray);
			query->setQueryMask(MVT_STATIONARY);
			RaySceneQueryResult &result = query->execute();
			RaySceneQueryResult::iterator it;
			for (it=result.begin(); it!=result.end(); ++it)
			{
				if (it->movable)
				if (it->movable->getName().compare( "GroundEntity") != 0)
				{
					mMapCells[i][j] = MCC_STATIONARY;
				}
			}
		}
		currPos.x += mDist.x;
		currPos.z = mMin.z - d.z;
	}
	mgr->destroyQuery(query);
}

CMapGrid::MapCellContents CMapGrid::GetMapCellContents(const Ogre::Vector3 &v)
{
	if (v.x < mMin.x || v.x > mMax.x || v.z < mMin.z || v.z > mMax.z)
		return MCC_OUT_OF_BOUNDS;

	int x, z;
	GridToXZ(v, x, z);

	return mMapCells[x][z];
}

void CMapGrid::GridToXZ(const Ogre::Vector3 &v, int &x, int &z)
{
	x = mXMax * (v.x-mMin.x)/(mMax.x - mMin.x);
	z = mZMax * (float)(v.z-mMin.z)/(mMax.z - mMin.z);
}

Vector3 CMapGrid::XZtoGrid(int x, int z)
{
	Vector3 v(
		(int)(mMin.x + x*(mMax.x - mMin.x)/mXMax) + mDist.x,
		0,
		(int)(mMin.z + z*(mMax.z - mMin.z)/mZMax) + mDist.z
	);
	return v;
}

Ogre::Vector3 CMapGrid::GetCellCentre(const Ogre::Vector3 &v)
{
	int x, z;
	GridToXZ(v, x, z);
	return XZtoGrid(x, z);
}