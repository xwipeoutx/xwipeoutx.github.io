#include "ILevel.h"
#include "CPlayerCamera.h"
#include "constants.h"
#include "CSettings.h"

#include <Ogre.h>

using namespace Ogre;

ILevel::ILevel(SceneManager *mgr)
: mSceneMgr(mgr)
{
	//Camera / position / camera control
	mCamera = new CPlayerCamera(mSceneMgr, "PlayerCamera");
	mCamera->setPosition(CSettings::getSingleton().getVector3("playerStartPosition"));
	mCamera->pitch(Degree(CSettings::getSingleton().getFloat("playerStartPitch")));
	mCamera->yaw(Degree(CSettings::getSingleton().getFloat("playerStartYaw")));
	mCamera->getCamera()->setQueryFlags(MVT_PLAYER_CHARACTER);
	mViewport = Root::getSingleton().getAutoCreatedWindow()->addViewport(mCamera->getCamera());
	mViewport->setBackgroundColour(ColourValue(0.0, 0.0, 0.0));
	CMessageBroadcaster::getSingletonPtr()->attach(mCamera, "PlayerCamera");
}

ILevel::~ILevel(void)
{
	CMessageBroadcaster::getSingletonPtr()->detach("PlayerCamera");
	mSceneMgr->clearScene();
	mSceneMgr->destroyAllCameras();
	Root::getSingleton().getAutoCreatedWindow()->removeAllViewports();
}
