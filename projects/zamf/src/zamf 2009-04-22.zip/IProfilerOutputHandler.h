
#ifndef _I_PROFILER_OUTPUT_HANDLER_H_INC
#define _I_PROFILER_OUTPUT_HANDLER_H_INC
#include <string>

class IProfilerOutputHandler
{
public:
	virtual void BeginOutput() = 0;
	virtual void EndOutput(float totalTime) = 0;
	virtual void Sample(float fMin, float fAvg, float fMax, float tAvg,
		int callCount, const std::string name, int parentCount) = 0;
};
#endif
