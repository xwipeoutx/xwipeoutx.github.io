#pragma once

#include "IPhysicsResponse.h"

class IActor : public IPhysicsResponse
{
public:
	IActor(void);
	virtual ~IActor(void);

	virtual void Damage(float hp);
	void Restore(float hp);

	void SetHP(float hp){mMaxHP=mCurrHP=hp;}

	float GetMaxHP(){return mMaxHP;}
	float GetCurrentHP(){return mCurrHP;}
	bool IsAlive(){return mIsAlive;}

	virtual void Collide(IPhysicsResponse *other, btPersistentManifold* contactManifold, int flipFlop)=0;
protected:
	float mMaxHP;
	float mCurrHP;
	bool mIsAlive;
};
