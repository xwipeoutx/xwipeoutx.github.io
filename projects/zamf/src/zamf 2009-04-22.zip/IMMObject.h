#pragma once

#include <list>

class IMMObject
{
private:
	static std::list<IMMObject *> liveObjects;
	static std::list<IMMObject *> deadObjects;
	long refCount;
	
protected:
	IMMObject(void);
	virtual ~IMMObject(void);
	
	
public:
#ifdef DEBUG
	void AddRef();
#else
	inline void AddRef()
	{ 
		++refCount; 
	}
#endif
	
	void Release();
	static void CollectGarbage();
	static void CollectRemainingObjects(bool bEmitWarnings=false);
	virtual unsigned long sizeofobj()=0;
	
};

//define macro to make things easier on derived classes
#define IMM_AUTO_SIZE unsigned long sizeofobj(){return sizeof(*this);}