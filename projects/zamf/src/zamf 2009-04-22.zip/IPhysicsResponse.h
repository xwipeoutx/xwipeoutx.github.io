#pragma once

#define IPR_ASSIGN_USER_POINTER(collObj, ptr) collObj->setUserPointer(new Any(static_cast<IPhysicsResponse*>(ptr)))
class btPersistentManifold;

class IPhysicsResponse
{
public:
	IPhysicsResponse(void){}
	virtual ~IPhysicsResponse(void){}

	virtual void Collide(IPhysicsResponse *other, btPersistentManifold* contactManifold, int flipFlop)=0;
};
