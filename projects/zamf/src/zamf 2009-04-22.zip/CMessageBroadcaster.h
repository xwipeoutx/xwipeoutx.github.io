#pragma once

#include <Ogre.h>
#include "OIS/OIS.h"

#include "CMMPointer.h"

class IMessageHandler;
class CInputManager;

//enum
enum MESSAGE_ID {
	MID_NONE,

	//standard movement
	MID_WALK_FORWARD,
	MID_WALK_BACKWARD,
	MID_STRAFE_LEFT,
	MID_STRAFE_RIGHT,

	//movement modifiers
	MID_RUN,
	MID_TOGGLE_RUN,

	//actions
	MID_SHOOT,

	//weapon selects
	MID_WEAPON_TURRET,
	MID_WEAPON_MAGNET,
	MID_WEAPON_BOWL,

	//other commands
	MID_PAUSE,
	MID_MENU,

	//menu commands
	MID_MENU_CONFIRM,
	MID_MENU_CANCEL,

	//mouse buttons (generally for CEGUI)
	MID_LMB,
	MID_RMB,
	MID_MMB,

	//system commands
	MID_APP_QUIT,
	MID_STOP_TIME,
	MID_RESTART_TIME,

	//debug commands
	MID_DBG_DRAW_PHYSICS_BOUNDS,
	MID_TOGGLE_CONSOLE,
	MID_DBG_PRINT_PROFILE,
	MID_DBG_CLEAR_PROFILE
};

enum MESSAGE_TYPE {
	MT_NONE,
	MT_DOWN,
	MT_UP,
	MT_CLICK
};

class CMessageBroadcaster :	public Ogre::Singleton<CMessageBroadcaster>, 
	public OIS::KeyListener, public OIS::MouseListener,
	public Ogre::FrameListener
{
public:

	CMessageBroadcaster(CInputManager *inputManager);
	~CMessageBroadcaster(void);

	//keyboard events
	bool keyClicked(const OIS::KeyEvent &e);
	bool keyPressed(const OIS::KeyEvent &e);
	bool keyReleased(const OIS::KeyEvent &e);

	//mouse events
	bool mouseMoved(const OIS::MouseEvent &e);
	bool mousePressed(const OIS::MouseEvent &e, OIS::MouseButtonID button);
	bool mouseReleased(const OIS::MouseEvent &e, OIS::MouseButtonID button);

	//frame listener
	bool frameStarted(const Ogre::FrameEvent &evt);

	void attach(IMessageHandler *messageHandler, const Ogre::String &instanceName);
	void detach(const Ogre::String &instanceName);

	void inject(MESSAGE_TYPE type, MESSAGE_ID id);

protected:
	void dispatch(MESSAGE_TYPE type, MESSAGE_ID id);
	void dispatch(MESSAGE_TYPE type, const OIS::KeyEvent &evt);
	void dispatchMouse(MESSAGE_TYPE type, MESSAGE_ID id, const OIS::MouseEvent &evt);

	MESSAGE_ID keyToMessageId(const OIS::KeyCode &key);

	MESSAGE_ID mbToMessageId(const OIS::MouseButtonID &id);

	void refreshMessageHandlerList();

	bool mTimeIsGoing;
private:
	std::map<Ogre::String, CMMPointer<IMessageHandler> > mMessageHandlers;
	std::map<Ogre::String, CMMPointer<IMessageHandler> >::iterator itMessageHandler;

	std::map<Ogre::String, CMMPointer<IMessageHandler> > mNewMessageHandlers;
	std::list<Ogre::String> mDeletedMessageHandlers;

	Ogre::Timer mTimer;
};
