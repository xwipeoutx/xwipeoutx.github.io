#pragma once
#include "IMessageHandler.h"

class CPlayListener : public IMessageHandler
{
public:
	CPlayListener(void);
	~CPlayListener(void);

	bool handleMessage(MESSAGE_TYPE type, MESSAGE_ID id);

	bool tick(float dt);

	IMM_AUTO_SIZE;
};
