#include "ILevel.h"
#include "CPlayerCamera.h"
#include "constants.h"

#include <Ogre.h>

using namespace Ogre;

ILevel::ILevel(SceneManager *mgr)
: mSceneMgr(mgr)
{
	//Camera / position / camera control
	mCamera = new CPlayerCamera(mSceneMgr, "PlayerCamera");
	mCamera->setPosition(0, 1.7f, 0);
	mCamera->pitch(Degree(-30));
	mCamera->yaw(Degree(-45));
	mCamera->getCamera()->setQueryFlags(MVT_PLAYER_CHARACTER);
	mViewport = Root::getSingleton().getAutoCreatedWindow()->addViewport(mCamera->getCamera());
	mViewport->setBackgroundColour(ColourValue(0.0, 0.0, 0.0));
	CMessageBroadcaster::getSingletonPtr()->attach(mCamera, "PlayerCamera");
}

ILevel::~ILevel(void)
{
	CMessageBroadcaster::getSingletonPtr()->detach("PlayerCamera");
	mSceneMgr->clearScene();
	mSceneMgr->destroyAllCameras();
	Root::getSingleton().getAutoCreatedWindow()->removeAllViewports();
}
