#include "CZombiePhysicsResponse.h"

#include "CBulletPhysicsResponse.h"
#include "CPlayStateHelper.h"


#include "btOgreGP.h"

#include <Ogre.h>

using namespace Ogre;

CZombiePhysicsResponse::CZombiePhysicsResponse(CZombieBehaviour::ZombieAI *zAI)
: mZombieAI(zAI)
{
}

CZombiePhysicsResponse::~CZombiePhysicsResponse(void)
{
	mZombieAI = NULL;
}

void CZombiePhysicsResponse::Collide(IPhysicsResponse *other)
{
	CBulletPhysicsResponse* bullet = dynamic_cast<CBulletPhysicsResponse*>(other);
	if (other != NULL) {
		Real dmg = 20;
		//Real dmg = 0.003 * bullet->GetBulletBehaviour()->physObject->getLinearVelocity().length2();
		mZombieAI->remainingHealth -= dmg;
	}
}