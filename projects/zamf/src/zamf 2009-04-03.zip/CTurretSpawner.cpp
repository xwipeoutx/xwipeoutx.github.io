#include "CTurretSpawner.h"
#include "CTurretBehaviour.h"

#include "CPlayerCamera.h"

#include "CBank.h"
#include "CPlayStateHelper.h"
#include "constants.h"

#include <Ogre.h>
using namespace Ogre;

CTurretSpawner::CTurretSpawner(SceneManager *mgr, CTurretBehaviour *turretBehaviour)
: mSceneMgr(mgr), mTurretCount(0), mTurretBehaviour(turretBehaviour)
{
}

CTurretSpawner::~CTurretSpawner(void)
{
	mTurretBehaviour = NULL;
	mSceneMgr = NULL;
}

bool CTurretSpawner::handleMouseMessage(MESSAGE_TYPE type, MESSAGE_ID id, const OIS::MouseEvent &evt)
{
	if (!mTimeIsGoing) return true;
	if (type == MT_DOWN && id == MID_SHOOT && CBank::getSingleton().GetCash() >= 10.0)
	{
		//spawn a turret
		String turretName = "Turret" + StringConverter::toString(mTurretCount++);
		String turretNodeName = "TurretNode" + StringConverter::toString(mTurretCount);

		//find position of intersection, middle of the screen
		Ray ray = mSceneMgr->getCamera("PlayerCameraCamera")->getCameraToViewportRay(0.5, 0.5);
		AxisAlignedBox a = mSceneMgr->getSceneNode("GroundNode")
			->getAttachedObject("GroundEntity")->getBoundingBox();

		std::pair<bool, Real> intp = ray.intersects(a);
		if (intp.first)
		{
			CBank::getSingleton().Withdraw(10);
			CPlayStateHelper::getSingleton().UpdateStats();
			Vector3 intpoint = ray.getPoint(intp.second);
			Entity *ent=NULL;
			ent = mSceneMgr->createEntity(turretName, "turret.mesh");
			ent->setCastShadows(false);
			ent->setQueryFlags(MVT_TURRET);
			mSceneMgr->getRootSceneNode()->createChildSceneNode(turretNodeName,intpoint)->attachObject(ent);
			mTurretBehaviour->addTurret(mSceneMgr->getSceneNode(turretNodeName));
/*
			MaterialPtr mat = ent->getSubEntity(0)->getMaterial();
			ColourValue c = ColourValue(0.5, 0.5, 0.5, 0.5);
			mat->setAmbient(c);
			mat->setDiffuse(c);
			mat->setSpecular(c);

			

			ent->setMaterial(mat);
*/
		}
	}

	return true;
}
