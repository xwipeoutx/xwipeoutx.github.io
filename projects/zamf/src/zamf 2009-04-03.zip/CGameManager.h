#pragma once

#include <vector>
#include <Ogre.h>
#include <OIS/OIS.h>
#include <CEGUI/CEGUI.h>
#include <OgreCEGUIRenderer.h>

#include "IMessageHandler.h"

class IGameState;
class CMessageBroadcaster;
class CInputManager;

class CGameManager : public Ogre::FrameListener, public Ogre::Singleton<CGameManager>
{
public:
	CGameManager();
	~CGameManager();
	void start(IGameState* state);
	void stop();

	void shutdown();

	void changeState(IGameState* state);
	void pushState(IGameState* state);
	void popState();

	static CGameManager& getSingleton(void);
	static CGameManager* getSingletonPtr(void);

	inline CEGUI::OgreCEGUIRenderer *getGUIRenderer(void){ return mGUIRenderer; }
	inline CEGUI::System &getGUISystem(void){ return *mGUISystem; }

	IMM_AUTO_SIZE;
protected:
	Ogre::Root* mRoot;
	Ogre::RenderWindow* mRenderWindow;
	CInputManager* mInputManager;

	CEGUI::OgreCEGUIRenderer *mGUIRenderer;
	CEGUI::System *mGUISystem;
	
	bool mDying;

	void setupStates(void);
	void setupResources(void);
	bool configure(void);
	void setupCEGUI(void);
	void setupPhysics(void);

	//OGRE frame events
	//bool frameStarted(const Ogre::FrameEvent& evt);
	bool frameEnded(const Ogre::FrameEvent& evt);
private:
	std::vector<IGameState*> mStates;
	CMessageBroadcaster *mMsgBroadcaster;
};
