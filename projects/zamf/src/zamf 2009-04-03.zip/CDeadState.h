#pragma once

#include <Ogre.h>

#include "IGameState.h"
#include "CDeadListener.h"

class CDeadState : public IGameState
{
public:
	CDeadState();

	void enter();
	void exit();

	void pause();
	void resume();

	inline virtual const Ogre::String getStateName(){return Ogre::String("Dead");}

	IMM_AUTO_SIZE;

protected:
	Ogre::Root *mRoot;
	Ogre::SceneManager *mSceneMgr;
	Ogre::Viewport *mViewport;
	Ogre::Camera *mCamera;

	CMMPointer< CDeadListener > mListener;
};
