#pragma once
#include "IPhysicsResponse.h"
#include "CBulletBehaviour.h"

class CBulletPhysicsResponse : public IPhysicsResponse
{
public:
	CBulletPhysicsResponse(CBulletBehaviour::BulletBehaviour *bb);
	virtual ~CBulletPhysicsResponse(void);

	void Collide(IPhysicsResponse *other);

	CBulletBehaviour::BulletBehaviour *GetBulletBehaviour(){return mBulletBehaviour;}

	IMM_AUTO_SIZE;
protected:
	CBulletBehaviour::BulletBehaviour *mBulletBehaviour;
};
