#pragma once

#include "IMessageHandler.h"

#include <Ogre.h>
class CBulletBehaviour;

class CTurretBehaviour : public IMessageHandler, public Ogre::Node::Listener
{
public:
	CTurretBehaviour(Ogre::SceneManager *sm, CBulletBehaviour *bulletBehaviour);
	virtual ~CTurretBehaviour(void);

	void addTurret(Ogre::SceneNode *turret);
	void clearTurrets();

	bool tick(Ogre::Real dt);

	virtual void nodeDestroyed(const Ogre::Node *);

	IMM_AUTO_SIZE;
protected:
	Ogre::SceneManager *mSceneMgr;

	//assumption: turrets will not move
	struct TurretAI
	{
		Ogre::SceneNode *turretNode;
		Ogre::SceneNode *targetNode;
		Ogre::Real targetInitialDistanceSquared;
		Ogre::Vector3 position;
		bool searching;

		Ogre::SphereSceneQuery *query;
		
		Ogre::Real timeUntilNextShot;
	};

	std::list<TurretAI> mTurrets;

	CMMPointer< CBulletBehaviour > mBulletBehaviour;

private:
};
