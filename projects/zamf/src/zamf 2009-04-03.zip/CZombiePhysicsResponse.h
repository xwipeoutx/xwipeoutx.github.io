#pragma once
#include "IPhysicsResponse.h"
#include "CZombieBehaviour.h"

class CZombiePhysicsResponse : public IPhysicsResponse
{
public:
	CZombiePhysicsResponse(CZombieBehaviour::ZombieAI *zAI);
	virtual ~CZombiePhysicsResponse(void);

	void Collide(IPhysicsResponse *other);

	IMM_AUTO_SIZE;
protected:
	CZombieBehaviour::ZombieAI *mZombieAI;
};
