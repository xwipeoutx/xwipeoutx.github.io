#include "CZombieBehaviour.h"
#include "CPhysicsManager.h"
#include "constants.h"
#include "CZombiePhysicsResponse.h"
#include "CBank.h"

#include "CGameManager.h"
#include "CDeadState.h"
#include "CPlayStateHelper.h"
#include "CProfileSample.h"
#include "CPlayerCamera.h"

#include "btOgreGP.h"
#include "BulletCollision/CollisionDispatch/btGhostObject.h"

#include <Ogre.h>
#include <CEGUI/CEGUI.h>

using namespace Ogre;

template<> CZombieBehaviour* Singleton<CZombieBehaviour>::ms_Singleton = 0;

CZombieBehaviour::CZombieBehaviour(SceneManager *mgr)
: mSceneMgr(mgr), mZombieShape(0), mNumSpawned(0), mNumKills(0)
{
	mZombies = new std::list<ZombieAI*>();
}

CZombieBehaviour::~CZombieBehaviour(void)
{
	//TODO: Kill mZombies AI thing
	for(std::list<ZombieAI*>::iterator it=mZombies->begin();it!=mZombies->end();++it)
	{
		CPhysicsManager::getSingleton().getWorld()->removeCollisionObject((*it)->ghostObject);
		(*it)->physResponse = NULL;
	}
	mZombies->clear();
	delete mZombies;
}

bool CZombieBehaviour::tick(float dt)
{
	if (dt < 0.0001) return true;
	if (!mTimeIsGoing) return true;
	PROFILE_THIS("CZombieBehaviour::tick");
	for(std::list<ZombieAI*>::iterator it=mZombies->begin();it!=mZombies->end();++it)
	{
		//temporarily just move the zombie around
		SceneNode *zomb = (*it)->zombieNode;
		if ((*it)->remainingHealth > 0.00001)
		{
			//head towards the player
			//get heading of turret and relation to zombie
			Vector3 playerPos = mSceneMgr->getSceneNode("PlayerCamera")->getPosition();
			Vector3 zombiePos = zomb->getPosition();
			Vector3 diff = zombiePos - playerPos;
			//negated, because the zombie is facing backwards...
			Radian desiredAngle = Ogre::Math::ATan2(diff.x, diff.z); 
			Degree difference = desiredAngle - zomb->getOrientation().getYaw();

			//make sure we're dealing with sane angles
			if (Degree(difference) < Degree(180)) difference += Degree(360);
			if (Degree(difference) > Degree(180)) difference -= Degree(360);

			Degree rotateBy =  Math::Clamp<Degree>(difference, Degree(-dt*360), Degree(dt*360));

			zomb->yaw(rotateBy);

			//now move towards player
			zomb->translate(Vector3(0,0,-dt*1.5), Node::TS_LOCAL);

			//update physics world transform
			Vector3 pos = zomb->getPosition();
			btTransform currTrans = (*it)->ghostObject->getWorldTransform();
			currTrans.setOrigin(BtOgre::Convert::toBullet(zomb->getPosition()));
			currTrans.setRotation(BtOgre::Convert::toBullet(zomb->getOrientation()));
			(*it)->ghostObject->setWorldTransform(currTrans);

			//check distance from player
			if ((*it)->cooldown <= 0 && 5 > pos.squaredDistance(playerPos)) {
				(*it)->cooldown = 1;
				CPlayerCamera::getSingletonPtr()->TakeDmg(10);
				CPlayStateHelper::getSingleton().UpdateStats();
				if (1 || CPlayerCamera::getSingletonPtr()->GetCurrHP() <= 0) {
					CGameManager::getSingleton().pushState(new CDeadState());
				}
			}
			(*it)->cooldown -= dt;

		} else {
			//kill the zombie
			it = KillZombie(it);
			CBank::getSingleton().Deposit(2);
			CPlayStateHelper::getSingleton().UpdateStats();
			if (it == mZombies->end())
				break;
		}
	}
	return true;
}

std::list<CZombieBehaviour::ZombieAI*>::iterator CZombieBehaviour::KillZombie(std::list<CZombieBehaviour::ZombieAI*>::iterator it)
{
	mNumKills++;
	ZombieAI *z = *it;
	
	CPhysicsManager::getSingleton().getWorld()->removeCollisionObject(z->ghostObject);
	delete z->ghostObject;
	z->ghostObject = NULL;
	z->physResponse = NULL;
	z->zombieNode->setUserAny(Any(NULL));
	mSceneMgr->destroySceneNode(z->zombieNode);
	z->zombieNode = NULL;

	return mZombies->erase(it);
}

void CZombieBehaviour::addZombie(Ogre::SceneNode *zombie, Ogre::Entity *entity)
{
	ZombieAI *z=new ZombieAI();
	z->zombieNode = zombie;
	z->maxHealth = z->remainingHealth = 100.0f;

	//create bt Object (physics)
	z->ghostObject = new btPairCachingGhostObject();
	z->ghostObject->setWorldTransform(btTransform(
		BtOgre::Convert::toBullet(zombie->getOrientation()), 
		btVector3(0,1,0) + BtOgre::Convert::toBullet(zombie->getPosition())));
	
    //Create the ground shape.
	if (!mZombieShape)
	{
		BtOgre::StaticMeshToShapeConverter *zombConverter = 
			new BtOgre::StaticMeshToShapeConverter(entity);
		//mZombieShape = new btSphereShape(2.0);
		//mZombieShape = zombConverter->createSphere();
		mZombieShape = zombConverter->createConvex();
		//mZombieShape = zombConverter->createTrimesh();
		delete zombConverter;
	}

	z->ghostObject->setCollisionShape(mZombieShape);
	z->physResponse = new CZombiePhysicsResponse(z);
	z->ghostObject->setUserPointer((void*)z->physResponse);
	z->cooldown = 0;
	CPhysicsManager::getSingleton().getWorld()->addCollisionObject(z->ghostObject, MVT_ENEMY, MVT_PROJECTILE);
	
	mZombies->push_back(z);
	mNumSpawned++;
	CPlayStateHelper::getSingleton().UpdateStats();
}
