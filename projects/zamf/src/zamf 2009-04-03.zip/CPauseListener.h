#pragma once
#include "IMessageHandler.h"

class CPauseListener : public IMessageHandler
{
public:
	CPauseListener(void);
	~CPauseListener(void);

	bool handleMessage(MESSAGE_TYPE type, MESSAGE_ID id);

	IMM_AUTO_SIZE;
};
