/*
#include "CGUImanager.h"

CGUImanager::CGUImanager(void)
{
}

CGUImanager::~CGUImanager(void)
{
}
*/