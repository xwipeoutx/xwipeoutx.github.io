#pragma once
#include <Ogre.h>

class CPlayStateHelper : public Ogre::Singleton<CPlayStateHelper>
{
public:
	CPlayStateHelper(void);
	~CPlayStateHelper(void);

	void AddDebugMsg(const Ogre::String &msg);

	void UpdateStats();
};
