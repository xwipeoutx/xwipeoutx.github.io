#include "CBulletPhysicsResponse.h"

#include "CZombiePhysicsResponse.h"
#include "CPlayStateHelper.h"

CBulletPhysicsResponse::CBulletPhysicsResponse(CBulletBehaviour::BulletBehaviour *bb)
: mBulletBehaviour(bb)
{
}

CBulletPhysicsResponse::~CBulletPhysicsResponse(void)
{
	mBulletBehaviour = NULL;
}

void CBulletPhysicsResponse::Collide(IPhysicsResponse *other)
{
	if (dynamic_cast<CZombiePhysicsResponse*>(other) != NULL && !mBulletBehaviour->dying) {
		mBulletBehaviour->dying = true;
	}
}