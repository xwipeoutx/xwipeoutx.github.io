#include "IPhysicsResponse.h"

IPhysicsResponse::IPhysicsResponse(void)
{
}

IPhysicsResponse::~IPhysicsResponse(void)
{
}
