#pragma once

#include "IMessageHandler.h"

#include <Ogre.h>

class CZombiePhysicsResponse;

class btPairCachingGhostObject;
class btCollisionShape;

class CZombieBehaviour : public IMessageHandler, public Ogre::Singleton<CZombieBehaviour>
{
public:
	CZombieBehaviour(Ogre::SceneManager *sm);
	virtual ~CZombieBehaviour(void);

	void addZombie(Ogre::SceneNode *zombie, Ogre::Entity *entity);

	bool tick(float dt);

	IMM_AUTO_SIZE;

	struct ZombieAI
	{
		Ogre::SceneNode *zombieNode;
		btPairCachingGhostObject *ghostObject;
		Ogre::Real maxHealth;
		Ogre::Real remainingHealth;

		Ogre::Real cooldown;

		CMMPointer<CZombiePhysicsResponse> physResponse;
	};

	int getNumSpawned(){return mNumSpawned;}
	int getNumKills(){return mNumKills;}
protected:
	std::list<CZombieBehaviour::ZombieAI*>::iterator CZombieBehaviour::KillZombie(std::list<CZombieBehaviour::ZombieAI*>::iterator it);

	Ogre::SceneManager *mSceneMgr;
	std::list<ZombieAI*> *mZombies;
	
	btCollisionShape *mZombieShape;
	
	int mNumSpawned;
	int mNumKills;

private:
};
