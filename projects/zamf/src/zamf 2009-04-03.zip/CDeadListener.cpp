#include "CDeadListener.h"

#include "CInputManager.h"
#include "CIntroState.h"
#include "CPlayerCamera.h"

using namespace Ogre;

CDeadListener::CDeadListener(void)
: mMoving(true), mTimeElapsed(0)
{
	Vector3 dest(0,100,0);
	Vector3 src = CPlayerCamera::getSingleton().getCameraNode()->getPosition();

	mDv = dest-src;

	CPlayerCamera *p = CPlayerCamera::getSingletonPtr();
	mOrientSrc = p->getCamera()->getRealOrientation();
/*
	p->yaw(-mOrientSrc.getYaw());
	p->pitch(-mOrientSrc.getPitch());
	p->roll(-mOrientSrc.getRoll());
	p->getCamera()->setOrientation(mOrientSrc);
*/	
	Vector3 face = mOrientSrc * -Vector3::UNIT_Z;
	src = Vector3(0,-1,0);

	face.normalise();
	src.normalise();
	mOrientDest = face.getRotationTo(src);
}

CDeadListener::~CDeadListener(void)
{
}

bool CDeadListener::handleMessage(MESSAGE_TYPE type, MESSAGE_ID id)
{
	if (type == MT_DOWN)
	{
		switch (id)
		{
		case MID_MENU:
			mMoving = false;
			CGameManager::getSingleton().changeState(new CIntroState());
			break;
		}
	}

	return true;
}

bool CDeadListener::tick(float dt)
{
	if (mMoving) 
	{
		float d = dt*0.25;
		mTimeElapsed += d;

		CPlayerCamera *p = CPlayerCamera::getSingletonPtr();
		Vector3 newPos = p->getCameraNode()->getPosition() + mDv*d;
		p->setPosition(newPos);

		Quaternion delta = Quaternion::Slerp(mTimeElapsed, mOrientSrc, mOrientDest, true);

		p->getCamera()->setOrientation(delta);
		//p->getCamera()->rotate(delta);
		
		//p->getCamera()->setOrientation(mOrientDest);

		if (mTimeElapsed > 1)
			mMoving = false;
	}
	return true;
}