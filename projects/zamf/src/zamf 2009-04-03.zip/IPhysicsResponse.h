#pragma once
#include "IMMObject.h"

class IPhysicsResponse : public IMMObject
{
public:
	IPhysicsResponse(void){}
	virtual ~IPhysicsResponse(void){}

	virtual void Collide(IPhysicsResponse *other)=0;
};
