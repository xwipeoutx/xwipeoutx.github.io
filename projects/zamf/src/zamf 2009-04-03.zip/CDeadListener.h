#pragma once
#include "IMessageHandler.h"

class CDeadListener : public IMessageHandler
{
public:
	CDeadListener(void);
	~CDeadListener(void);

	bool handleMessage(MESSAGE_TYPE type, MESSAGE_ID id);
	bool tick(float dt);

	IMM_AUTO_SIZE;

protected:
	Ogre::Vector3 mDv;
	bool mMoving;
	Ogre::Real mTimeElapsed;

	Ogre::Quaternion mOrientSrc;
	Ogre::Quaternion mOrientDest;

};
